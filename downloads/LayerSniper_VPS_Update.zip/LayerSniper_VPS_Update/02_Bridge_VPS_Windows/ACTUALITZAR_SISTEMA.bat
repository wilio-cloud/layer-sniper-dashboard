@echo off
chcp 65001 >nul
title Layer Sniper Pro - Actualitzador Automatic des del Portal
color 0B
echo ============================================================================
echo   LAYER SNIPER PRO - ACTUALITZADOR D'1 CLIC (CONSERVA EL TEU SECRET TOKEN)
echo ============================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update_vps_client.ps1"
echo.
pause
