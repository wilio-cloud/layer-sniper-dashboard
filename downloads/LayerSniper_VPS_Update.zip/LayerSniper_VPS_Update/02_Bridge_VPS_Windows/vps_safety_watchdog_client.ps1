# ==============================================================================
# Layer Sniper Pro — Windows VPS Health & Auto-Recovery Watchdog (Client Edition)
#   1. Verifica que el Bridge ATI local respongui a /health (port de bridge_config.json).
#      Si s'ha tancat per un reinici nocturn de Windows, l'aixeca sol.
#   2. En mode pre-obertura (-RequireNinjaTraderOpen, 08:45 NY Dl-Dv), comprova que
#      NinjaTrader.exe estigui actiu i avisa al teu canal privat si està configurat.
# ==============================================================================
param(
    [string]$ConfigPath = "C:\LayerSniper\bridge_config.json",
    [switch]$RequireNinjaTraderOpen
)

$ErrorActionPreference = "SilentlyContinue"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$bridgePort = 8090
$bridgeSecret = ""
$railwayIngestUrl = ""
$privateDiscordUrl = ""

if (Test-Path $ConfigPath) {
    try {
        $cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json
        if ($cfg.port) { $bridgePort = [int]$cfg.port }
        if ($cfg.webhook_secret) { $bridgeSecret = [string]$cfg.webhook_secret }
        if ($cfg.railway_ingest_url) { $railwayIngestUrl = [string]$cfg.railway_ingest_url }
        if ($cfg.private_discord_webhook_url) { $privateDiscordUrl = [string]$cfg.private_discord_webhook_url }
    } catch {}
}

function Send-ClientWatchdogAlert {
    param(
        [string]$Title,
        [string]$Message,
        [string]$Color = "warning"
    )
    if (-not [string]::IsNullOrWhiteSpace($railwayIngestUrl)) {
        $payload = @{
            secret     = $bridgeSecret
            event_type = "watchdog"
            title      = $Title
            message    = $Message
            color      = $Color
            fields     = @{
                "VPS"  = $env:COMPUTERNAME
                "Port" = "$bridgePort"
            }
        } | ConvertTo-Json -Depth 5
        try {
            Invoke-RestMethod -Uri $railwayIngestUrl -Method Post -ContentType "application/json; charset=utf-8" `
                -Headers @{ "X-Bridge-Secret" = $bridgeSecret } -Body ([System.Text.Encoding]::UTF8.GetBytes($payload)) -TimeoutSec 10 | Out-Null
        } catch {}
    } elseif (-not [string]::IsNullOrWhiteSpace($privateDiscordUrl)) {
        $hexColor = if ($Color -eq "danger") { 15680580 } elseif ($Color -eq "green") { 1096065 } else { 16096779 }
        $discordBody = @{
            username = "Layer Sniper Pro [FLEET SAFETY PRIVAT]"
            embeds   = @(
                @{
                    title       = "Fleet Safety Privat | $Title"
                    description = $Message
                    color       = $hexColor
                }
            )
        } | ConvertTo-Json -Depth 6
        try {
            Invoke-RestMethod -Uri $privateDiscordUrl -Method Post -ContentType "application/json; charset=utf-8" `
                -Body ([System.Text.Encoding]::UTF8.GetBytes($discordBody)) -TimeoutSec 10 | Out-Null
        } catch {}
    }
}

$bridgeHealthy = $false
try {
    $resp = Invoke-RestMethod -Uri "http://127.0.0.1:$bridgePort/health" -TimeoutSec 4
    if ($resp -and $resp.status -eq "healthy") { $bridgeHealthy = $true }
} catch {}

if (-not $bridgeHealthy) {
    $desktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::DesktopDirectory)
    $batLauncher = Join-Path $desktopPath "Iniciar LayerSniper Bridge.bat"
    if (Test-Path $batLauncher) {
        Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$batLauncher`"" -WorkingDirectory "C:\LayerSniper"
    }
    Start-Sleep -Seconds 5
    $recovered = $false
    try {
        $resp2 = Invoke-RestMethod -Uri "http://127.0.0.1:$bridgePort/health" -TimeoutSec 4
        if ($resp2 -and $resp2.status -eq "healthy") { $recovered = $true }
    } catch {}

    if ($recovered) {
        Send-ClientWatchdogAlert -Title "Bridge ATI Auto-Recuperat al VPS" `
            -Message "El Bridge ATI del port **$bridgePort** estava tancat i s'ha rellancat automaticament." -Color "green"
    } else {
        Send-ClientWatchdogAlert -Title "ALERTA VPS: Bridge ATI Caigut" `
            -Message "El Bridge ATI del port **$bridgePort** no respon. Obre 'Iniciar LayerSniper Bridge.bat' al VPS." -Color "danger"
    }
}

if ($RequireNinjaTraderOpen.IsPresent) {
    $nt8Proc = Get-Process -Name "NinjaTrader" -ErrorAction SilentlyContinue
    if (-not $nt8Proc) {
        Send-ClientWatchdogAlert -Title "ALERTA PRE-OBERTURA: NinjaTrader 8 TANCAT!" `
            -Message "NinjaTrader.exe NO esta obert al VPS abans de la sessio de Nova York (09:30 NY)." -Color "danger"
    }
}
