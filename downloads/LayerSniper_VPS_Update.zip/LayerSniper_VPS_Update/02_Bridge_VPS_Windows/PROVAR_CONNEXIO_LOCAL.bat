@echo off
chcp 65001 >nul
title Layer Sniper Pro - Diagnostic Local del Bridge i NinjaTrader 8
color 0A
echo ============================================================================
echo   DIAGNOSTIC DE CONNEXIO LOCAL - LAYER SNIPER PRO BRIDGE
echo ============================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$cfgFile = if (Test-Path 'C:\LayerSniper\bridge_config.json') { 'C:\LayerSniper\bridge_config.json' } else { Join-Path '%~dp0' 'bridge_config.json' }; " ^
  "if (-not (Test-Path $cfgFile)) { Write-Host '[ERROR] Encara no s''ha executat INSTALAR_BRIDGE_VPS.bat.' -ForegroundColor Red; exit 1 }; " ^
  "$cfg = Get-Content $cfgFile -Raw | ConvertFrom-Json; " ^
  "$port = $cfg.port; $sec = $cfg.webhook_secret; " ^
  "Write-Host ('Comprovant Bridge a http://127.0.0.1:' + $port + '/health ...') -ForegroundColor Cyan; " ^
  "try { " ^
  "  $res = Invoke-RestMethod -Uri ('http://127.0.0.1:' + $port + '/health?secret=' + $sec) -TimeoutSec 4; " ^
  "  Write-Host '[OK] Bridge actiu i responent correctament!' -ForegroundColor Green; " ^
  "  $res | ConvertTo-Json -Depth 4 | Write-Host; " ^
  "  Write-Host ''; " ^
  "  $ans = Read-Host 'Vols enviar una ordre de PROVA (1 MNQ Buy + 30p TP/SL) al compte de simulacio Sim101? (S/N) [N]'; " ^
  "  if ($ans -match '^[sSyY]') { " ^
  "    $body = @{ secret = $sec; strategy = 'Diagnostic_Test_Sim101'; action = 'Buy'; order_type = 'Market'; symbol = 'MNQ1!'; price = 25000.0; tp_points = 30.0; sl_points = 30.0; qty = 1; account = 'Sim101' } | ConvertTo-Json; " ^
  "    $ord = Invoke-RestMethod -Method Post -Uri ('http://127.0.0.1:' + $port + '/webhook') -ContentType 'application/json' -Body $body; " ^
  "    Write-Host '[OK] Ordre de prova escrita a NinjaTrader 8 (Sim101)!' -ForegroundColor Green; " ^
  "    $ord | ConvertTo-Json -Depth 4 | Write-Host " ^
  "  } " ^
  "} catch { Write-Host ('[ERROR] El Bridge no respon al port ' + $port + ': ' + $_.Exception.Message) -ForegroundColor Red }"
echo.
pause
