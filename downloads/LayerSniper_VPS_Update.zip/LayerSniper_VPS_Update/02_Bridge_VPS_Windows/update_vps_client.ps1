# ==============================================================================
# Layer Sniper Pro — Actualitzador d'1 Clic per a VPS Windows / PC Local
# Descarrega la darrera versió del Bridge i del Kit NinjaTrader 8 des del Portal
# central (GitHub Pages o Servidor Privat), MANTENINT 100% INTACTE el
# `bridge_config.json` (webhook_secret i port) perquè NO calgui tornar a
# configurar les alertes de TradingView.
# ==============================================================================
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$defaultPortalUrl = "https://wilio-cloud.github.io/layer-sniper-dashboard"
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$workDir = if (Test-Path "C:\LayerSniper\bridge_config.json") { "C:\LayerSniper" } else { $scriptRoot }
$cfgPath = Join-Path $workDir "bridge_config.json"
$verPath = Join-Path $workDir "VERSION.json"

$localVer = "Desconeguda"
if (Test-Path $verPath) {
    try {
        $vObj = Get-Content $verPath -Raw | ConvertFrom-Json
        if ($vObj.version) { $localVer = $vObj.version }
    } catch {}
}

$cfg = @{}
if (Test-Path $cfgPath) {
    try {
        $loaded = Get-Content $cfgPath -Raw | ConvertFrom-Json
        foreach ($prop in $loaded.PSObject.Properties) {
            $cfg[$prop.Name] = $prop.Value
        }
    } catch {}
}

Write-Host "Carpeta d'instal·lacio detectada : $workDir" -ForegroundColor Cyan
Write-Host "Versio local instal·lada         : $localVer" -ForegroundColor Yellow
Write-Host ""

$portalUrl = [string]$cfg["portal_url"]
if ([string]::IsNullOrWhiteSpace($portalUrl)) {
    $inp = Read-Host "Prem ENTER per usar el Dashboard oficial [$defaultPortalUrl] o enganxa una altra URL"
    if ([string]::IsNullOrWhiteSpace($inp)) {
        $portalUrl = $defaultPortalUrl
    } else {
        $portalUrl = $inp
    }
}
$portalUrl = $portalUrl.Trim().TrimEnd("/")
if ($portalUrl.EndsWith("/portal_instalacio.html")) {
    $portalUrl = $portalUrl.Substring(0, $portalUrl.Length - 23)
} elseif ($portalUrl.EndsWith("/portal")) {
    $portalUrl = $portalUrl.Substring(0, $portalUrl.Length - 7)
}

Write-Host ""
Write-Host "[1/3] Comprovant ultima versio disponible..." -ForegroundColor Cyan

$remoteMeta = $null
$downloadZipUrl = ""
$headers = @{}

# 1. Provar primer canal estatic directe (ex: GitHub Pages downloads/VERSION.json sense contrasenya)
try {
    $cacheBust = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $remoteMeta = Invoke-RestMethod -Uri "$portalUrl/downloads/VERSION.json?t=$cacheBust" -TimeoutSec 10
    if ($remoteMeta -and $remoteMeta.version) {
        $downloadZipUrl = "$portalUrl/downloads/LayerSniper_VPS_Update.zip?t=$cacheBust"
    }
} catch {
    $remoteMeta = $null
}

# 2. Si no es canal estatic, connectar al Portal autenticant amb Usuari i Contrasenya
if (-not $remoteMeta) {
    $portalUser = [string]$cfg["portal_user"]
    if ([string]::IsNullOrWhiteSpace($portalUser)) {
        $portalUser = Read-Host "Usuari del Portal"
    }
    $secPass = Read-Host "Contrasenya del Portal" -AsSecureString
    $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($secPass)
    $plainPass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
    [System.Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)

    $pair = "${portalUser}:${plainPass}"
    $basicToken = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pair))
    $headers = @{ Authorization = "Basic $basicToken" }

    try {
        $remoteMeta = Invoke-RestMethod -Uri "$portalUrl/portal/api/version" -Headers $headers -TimeoutSec 10
        $downloadZipUrl = "$portalUrl/portal/download/vps-bridge.zip"
        $cfg["portal_user"] = $portalUser
    } catch {
        Write-Host "[ERROR] No s'ha pogut connectar o autenticar amb $portalUrl" -ForegroundColor Red
        Write-Host "Detall: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

$remoteVer = $remoteMeta.version
Write-Host "  -> Versio disponible: v$remoteVer (Actualitzat: $($remoteMeta.updated_at))" -ForegroundColor Green

# Desar portal_url (sense desar mai contrasenyes) a bridge_config.json
$cfg["portal_url"] = $portalUrl
$cfg | ConvertTo-Json -Depth 5 | Set-Content -Path $cfgPath -Encoding UTF8

$tmpZip = Join-Path $env:TEMP "layersniper_vps_update.zip"
$tmpExt = Join-Path $env:TEMP "layersniper_vps_update_extracted"
if (Test-Path $tmpZip) { Remove-Item $tmpZip -Force }
if (Test-Path $tmpExt) { Remove-Item $tmpExt -Recurse -Force }

Write-Host "[2/3] Descarregant paquet d'actualitzacio (v$remoteVer)..." -ForegroundColor Cyan
if ($headers.Count -gt 0) {
    Invoke-WebRequest -Uri $downloadZipUrl -Headers $headers -OutFile $tmpZip -UseBasicParsing -TimeoutSec 30
} else {
    Invoke-WebRequest -Uri $downloadZipUrl -OutFile $tmpZip -UseBasicParsing -TimeoutSec 30
}
Expand-Archive -Path $tmpZip -DestinationPath $tmpExt -Force

Write-Host "[3/3] Aplicant actualitzacio sense tocar bridge_config.json..." -ForegroundColor Cyan
$bridgeSrc = Get-ChildItem -Path $tmpExt -Filter "layersniper_nt8_bridge.py" -Recurse | Select-Object -First 1
if (-not $bridgeSrc) {
    Write-Host "[ERROR] Paquet d'actualitzacio invalid." -ForegroundColor Red
    exit 1
}
$updRoot = $bridgeSrc.DirectoryName

foreach ($fn in @("layersniper_nt8_bridge.py", "INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat", "PROVAR_CONNEXIO_LOCAL.bat", "ACTUALITZAR_SISTEMA.bat", "update_vps_client.ps1")) {
    $s = Join-Path $updRoot $fn
    if (Test-Path $s) {
        Copy-Item -Path $s -Destination (Join-Path $workDir $fn) -Force
    }
}

$verSrc = Get-ChildItem -Path $tmpExt -Filter "VERSION.json" -Recurse | Select-Object -First 1
if ($verSrc) {
    Copy-Item -Path $verSrc.FullName -Destination $verPath -Force
}

$nt8Installer = Get-ChildItem -Path $tmpExt -Filter "install_nt8_kit_offline.ps1" -Recurse | Select-Object -First 1
if ($nt8Installer) {
    Write-Host "  -> Actualitzant plantilles ATM i AddOns C# a NinjaTrader 8..." -ForegroundColor Cyan
    & $nt8Installer.FullName
}

Remove-Item $tmpZip -Force -ErrorAction SilentlyContinue
Remove-Item $tmpExt -Recurse -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  ACTUALITZAT AMB EXIT A LA VERSIO v$remoteVer!" -ForegroundColor Green
Write-Host "  - El teu Webhook Secret Token i port a bridge_config.json s'han mantingut intactes." -ForegroundColor White
Write-Host "  - Si tens la finestra del Bridge oberta, tanca-la i torna a obrir 'Iniciar LayerSniper Bridge.bat'." -ForegroundColor Yellow
Write-Host "  - Si s'ha actualitzat l'AddOn C#, prem F5 un cop dins NinjaScript Editor." -ForegroundColor Yellow
Write-Host "============================================================================" -ForegroundColor Green
