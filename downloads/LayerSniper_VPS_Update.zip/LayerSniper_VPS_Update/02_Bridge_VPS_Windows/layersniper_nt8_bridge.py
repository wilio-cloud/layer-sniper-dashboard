#!/usr/bin/env python3
"""
Layer Sniper Pro — NinjaTrader 8 ATI Webhook Bridge (Replikanto Leader Edition)
===============================================================================
Receptor lleuger de Webhooks (100% Python Standard Library, Zero-Dependencies)
per a Windows Server / ChartVPS.

Modes d'ús suportats:
  1) Mode Directe des de TradingView (Port 80 HTTP + Filtre d'IPs oficials TV)
  2) Mode Directe HTTPS via Cloudflare Tunnel (Port 8090 local <- HTTPS 443)
  3) Mode Complet Pro connectat a Servidor Railway (Port 8090)

Funcions clau:
  - PLACE amb Brackets OCO (+30p TP Limit / -30p SL StopMarket per defecte)
  - CHANGE automàtic per moure l'Stop Loss a Breakeven (+0.50p sobre fill real)
    llegint el preu real d'execució a Documents\\NinjaTrader 8\\outgoing\\
  - CANCELALLORDERS i CLOSEPOSITION per a tall de sessió o Kill-Switch
  - Blindatge Compliance (HTTP 403) que impedeix tocar Sim102 o comptes manuals
"""

import os
import sys
import math
import json
import time
import shutil
import secrets
import logging
import argparse
import datetime
import tempfile
import ipaddress
import urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from typing import Dict, Any, Optional, Iterable, Set, Tuple, List

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CONFIG_PATH = os.path.join(SCRIPT_DIR, "bridge_config.json")
LOG_FILE_PATH = os.environ.get("BRIDGE_LOG_PATH") or os.path.join(SCRIPT_DIR, "vps_bridge.log")

_log_handlers = [logging.StreamHandler(sys.stdout)]
if not os.environ.get("PYTEST_CURRENT_TEST"):
    _log_handlers.append(logging.FileHandler(LOG_FILE_PATH, encoding="utf-8"))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] (LayerSniper-NT8-Bridge) %(message)s",
    handlers=_log_handlers
)
logger = logging.getLogger("LayerSniperBridge")

DEFAULT_PORT = 8090
DEFAULT_ACCOUNT = "Sim101"
DEFAULT_ALLOWED_ACCOUNTS = "Sim101,Sim103"
DEFAULT_SYMBOL_BASE = "MNQ"

# Adreces IPv4 estàtiques oficials des d'on TradingView envia tots els Webhooks
TRADINGVIEW_WEBHOOK_IPS: Tuple[str, ...] = (
    "52.89.214.238",
    "34.212.75.30",
    "54.218.53.128",
    "52.32.178.7",
)

# Blindatge Compliance: cap ordre automàtica ATI pot apuntar mai a Sim102 ni a
# comptes d'empreses que exigeixen clic manual humà.
PROHIBITED_MANUAL_ACCOUNT_PATTERNS: Tuple[str, ...] = (
    "PAAPEX",
    "APEX",
    "SIM102",
    "MANUAL",
    "TPT",
    "TAKEPROFIT",
    "PHIDIAS",
    "LEGENDS",
    "TRADEIFY",
    "ALPHA",
    "TOPSTEP",
)

ATM_TEMPLATES_SPEC: List[Tuple[str, int]] = [
    ("LS_50K_10MNQ_30TP_30SL", 10),
    ("LS_50K_5MNQ_30TP_30SL", 5),
    ("LS_50K_3MNQ_30TP_30SL", 3),
    ("LS_150K_30MNQ_30TP_30SL", 30),
]


def is_bot_account_compliant(
    account_name: Optional[str],
    allowed_accounts: Optional[Set[str]] = None
) -> Tuple[bool, Optional[str]]:
    """Verifica amb doble cadenat (Denylist manual + Allowlist Bot) que el compte destí és apte per a ATI."""
    acct_clean = str(account_name or "").strip()
    if not acct_clean:
        return False, "EMPTY_ACCOUNT_NAME"

    acct_upper = acct_clean.upper()
    for forbidden in PROHIBITED_MANUAL_ACCOUNT_PATTERNS:
        if forbidden in acct_upper:
            return False, f"PROHIBITED_MANUAL_FIRM_OR_LEADER:{forbidden}"

    if allowed_accounts is not None:
        normalized_allow = {a.strip().lower() for a in allowed_accounts if a and a.strip()}
        if acct_clean.lower() not in normalized_allow:
            return False, f"ACCOUNT_NOT_IN_BOT_ALLOWLIST:{acct_clean}"

    return True, None


def is_client_ip_allowed(
    client_ip: str,
    restrict_to_tv_ips: bool = False,
    extra_allowed_ips: Optional[Iterable[str]] = None
) -> bool:
    """
    Valida l'adreça IP d'origen quan el filtre d'IPs de TradingView està activat (Mode Directe Port 80).
    Permet sempre connexions locals (loopback / LAN privada), les 4 IPs oficials de TradingView
    i qualsevol IP addicional autoritzada explícitament (ex: el servidor Railway propi).
    """
    if not restrict_to_tv_ips:
        return True

    raw = str(client_ip or "").strip()
    if not raw:
        return False

    # Netejar prefix IPv4-mapped IPv6 (ex: ::ffff:52.89.214.238)
    if raw.startswith("::ffff:"):
        raw = raw[7:]

    allowed_exact = set(TRADINGVIEW_WEBHOOK_IPS)
    if extra_allowed_ips:
        allowed_exact.update(ip.strip() for ip in extra_allowed_ips if ip and ip.strip())

    if raw in allowed_exact:
        return True

    try:
        ip_obj = ipaddress.ip_address(raw)
        if ip_obj.is_loopback or ip_obj.is_private:
            return True
    except ValueError:
        return False

    return False


def get_default_nt8_incoming_path() -> str:
    """Detecta automàticament la carpeta incoming de NinjaTrader 8 a Windows (incloent OneDrive)."""
    user_profile = os.environ.get("USERPROFILE", os.path.expanduser("~"))
    candidates = [
        os.path.join(user_profile, "Documents", "NinjaTrader 8", "incoming"),
        os.path.join(user_profile, "Documentos", "NinjaTrader 8", "incoming"),
        os.path.join(user_profile, "OneDrive", "Documents", "NinjaTrader 8", "incoming"),
        os.path.join(user_profile, "OneDrive", "Documentos", "NinjaTrader 8", "incoming"),
    ]
    for cand in candidates:
        parent = os.path.dirname(cand)
        if os.path.isdir(parent):
            return cand
    return candidates[0]


def _build_atm_template_xml(template_name: str, qty: int, tp_ticks: int = 120, sl_ticks: int = 120) -> str:
    return f"""<?xml version="1.0" encoding="utf-8"?>
<NinjaTrader>
  <AtmStrategy xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <IsVisible>true</IsVisible>
    <AreLinesConfigurable>true</AreLinesConfigurable>
    <IsStopsConfigurable>true</IsStopsConfigurable>
    <CalculationMode>Ticks</CalculationMode>
    <ChaseLimit>0</ChaseLimit>
    <DefaultQuantity>{qty}</DefaultQuantity>
    <EntryMode>0</EntryMode>
    <IsChase>false</IsChase>
    <IsChaseIfTouched>false</IsChaseIfTouched>
    <IsTargetChase>false</IsTargetChase>
    <ReverseAtStop>false</ReverseAtStop>
    <ReverseAtTarget>false</ReverseAtTarget>
    <ShadowStrategy />
    <ShadowTemplate />
    <Brackets>
      <Bracket>
        <Quantity>{qty}</Quantity>
        <StopLoss>{sl_ticks}</StopLoss>
        <StopStrategy>
          <AutoBreakEvenPlus>0</AutoBreakEvenPlus>
          <AutoBreakEvenProfitTrigger>0</AutoBreakEvenProfitTrigger>
          <AutoTrailSteps />
          <IsSimStopEnabled>false</IsSimStopEnabled>
          <VolumeTrigger>0</VolumeTrigger>
          <Template />
        </StopStrategy>
        <Target>{tp_ticks}</Target>
      </Bracket>
    </Brackets>
    <Template>{template_name}</Template>
    <TimeInForce>Day</TimeInForce>
  </AtmStrategy>
</NinjaTrader>
"""


def ensure_local_nt8_kit_installed(incoming_dir: str) -> Dict[str, Any]:
    """
    Garanteix de forma 100% offline que les 4 plantilles ATM XML i els AddOns C# locals
    estiguin copiats a la carpeta de NinjaTrader 8 de l'usuari.
    """
    nt8_root = os.path.dirname(os.path.abspath(incoming_dir.rstrip("\\/")))
    atm_dir = os.path.join(nt8_root, "templates", "AtmStrategy")
    ind_dir = os.path.join(nt8_root, "bin", "Custom", "Indicators")
    addons_dir = os.path.join(nt8_root, "bin", "Custom", "AddOns")

    installed_atm: List[str] = []
    copied_cs: List[str] = []
    errors: List[str] = []

    try:
        os.makedirs(atm_dir, exist_ok=True)
        for tpl_name, qty in ATM_TEMPLATES_SPEC:
            tpl_file = os.path.join(atm_dir, f"{tpl_name}.xml")
            if not os.path.isfile(tpl_file):
                with open(tpl_file, "w", encoding="utf-8") as f:
                    f.write(_build_atm_template_xml(tpl_name, qty))
            installed_atm.append(f"{tpl_name}.xml")
    except Exception as e:
        errors.append(f"ATM_INSTALL_ERROR: {e}")

    local_kit_roots = [
        os.path.join(SCRIPT_DIR, "nt8_kit"),
        os.path.join(os.path.dirname(SCRIPT_DIR), "01_Kit_NinjaTrader8_i_Replikanto"),
    ]
    for kit_root in local_kit_roots:
        if not os.path.isdir(kit_root):
            continue
        try:
            src_addon = os.path.join(kit_root, "bin", "Custom", "AddOns", "LayerSniperChartTraderAddOn.cs")
            src_ind = os.path.join(kit_root, "bin", "Custom", "Indicators", "LayerSniperManualBEButton.cs")
            if os.path.isfile(src_addon):
                os.makedirs(addons_dir, exist_ok=True)
                dst_addon = os.path.join(addons_dir, "LayerSniperChartTraderAddOn.cs")
                if not os.path.isfile(dst_addon):
                    shutil.copyfile(src_addon, dst_addon)
                copied_cs.append("LayerSniperChartTraderAddOn.cs")
            if os.path.isfile(src_ind):
                os.makedirs(ind_dir, exist_ok=True)
                dst_ind = os.path.join(ind_dir, "LayerSniperManualBEButton.cs")
                if not os.path.isfile(dst_ind):
                    shutil.copyfile(src_ind, dst_ind)
                copied_cs.append("LayerSniperManualBEButton.cs")
            if copied_cs:
                break
        except Exception as e:
            errors.append(f"CS_COPY_ERROR: {e}")

    return {
        "nt8_root": nt8_root,
        "atm_templates": installed_atm,
        "csharp_files": copied_cs,
        "errors": errors,
    }


def resolve_nt8_symbol(raw_symbol: str) -> str:
    """Tradueix qualsevol símbol (MNQ1!, MNQZ6, MNQ) al format natiu de NinjaTrader 8 (ex: 'MNQ 12-26')."""
    clean = str(raw_symbol or "").upper().replace("!", "").strip()
    if " " in clean:
        return clean

    base = "MNQ"
    if "NQ" in clean and "MNQ" not in clean:
        base = "NQ"
    elif "ES" in clean and "MES" not in clean:
        base = "ES"
    elif "MES" in clean:
        base = "MES"

    now = datetime.datetime.now()
    year = now.year
    month = now.month
    day = now.day

    quarters = [3, 6, 9, 12]
    target_q = None
    target_y = year
    for q in quarters:
        if month < q:
            target_q = q
            break
        elif month == q:
            if day < 12:
                target_q = q
            break

    if target_q is None:
        target_q = 3
        target_y = year + 1

    return f"{base} {target_q:02d}-{str(target_y)[-2:]}"


def round_to_tick(price: float, tick_size: float = 0.25) -> float:
    """Arrodoneix un preu al tick vàlid més proper de l'instrument (0.25 per a MNQ/NQ/MES/ES)."""
    if tick_size <= 0:
        return round(float(price), 2)
    ticks = math.floor((float(price) / tick_size) + 0.5 + 1e-9)
    return round(ticks * tick_size, 4)


def _read_shared_file_lines(filepath: str, max_tail_bytes: int = 524288) -> List[str]:
    """Llegeix de forma segura un fitxer d'estat obert per NinjaTrader 8 sense bloquejar-lo."""
    try:
        size = os.path.getsize(filepath)
        with open(filepath, "rb") as bf:
            if size > max_tail_bytes:
                bf.seek(size - max_tail_bytes)
            raw = bf.read()
        return raw.decode("utf-8", errors="ignore").splitlines()
    except PermissionError:
        tmp_fd, tmp_path = tempfile.mkstemp(prefix="nt8_log_", suffix=".txt")
        os.close(tmp_fd)
        try:
            shutil.copyfile(filepath, tmp_path)
            with open(tmp_path, "r", encoding="utf-8", errors="ignore") as tf:
                return tf.read().splitlines()
        finally:
            try:
                os.remove(tmp_path)
            except Exception:
                pass


class NT8OrderWriter:
    """Gestiona l'escriptura d'instruccions ATI (PLACE, CHANGE, CANCEL, CLOSEPOSITION) amb blindatge Compliance."""

    def __init__(
        self,
        incoming_dir: str,
        default_account: str = DEFAULT_ACCOUNT,
        allowed_accounts: Optional[Iterable[str]] = None,
        outgoing_dir: Optional[str] = None
    ):
        self.incoming_dir = incoming_dir
        nt8_root = os.path.dirname(os.path.abspath(self.incoming_dir.rstrip("\\/")))
        self.outgoing_dir = outgoing_dir or os.path.join(nt8_root, "outgoing")
        self.default_account = str(default_account or DEFAULT_ACCOUNT).strip()

        if allowed_accounts is None:
            env_allowed = [a.strip() for a in str(DEFAULT_ALLOWED_ACCOUNTS).split(",") if a.strip()]
            base_allowed = set(env_allowed) | {self.default_account}
        else:
            base_allowed = {str(a).strip() for a in allowed_accounts if str(a).strip()} | {self.default_account}

        ok_def, reason_def = is_bot_account_compliant(self.default_account, allowed_accounts=None)
        if not ok_def:
            raise ValueError(
                f"ERROR COMPLIANCE CRITIC: default_account='{self.default_account}' no es permès per a ATI ({reason_def})."
            )
        for cand in list(base_allowed):
            ok_c, reason_c = is_bot_account_compliant(cand, allowed_accounts=None)
            if not ok_c:
                raise ValueError(
                    f"ERROR COMPLIANCE CRITIC: Compte prohibit dins allowed_accounts='{cand}' ({reason_c})."
                )

        self.allowed_accounts: Set[str] = {a.lower() for a in base_allowed}
        os.makedirs(self.incoming_dir, exist_ok=True)
        self.active_orders_by_account: Dict[str, Dict[str, Any]] = {}
        self.last_active_order: Optional[Dict[str, Any]] = None
        self._order_seq: int = 0
        logger.info(f"Carpeta ATI Incoming activa: {self.incoming_dir}")
        logger.info(f"Blindatge Compliance ATI actiu. Lider per defecte={self.default_account} | Allowlist={sorted(self.allowed_accounts)}")

    def resolve_target_account(self, payload: Dict[str, Any]) -> str:
        explicit = payload.get("account")
        if explicit is not None and str(explicit).strip():
            return str(explicit).strip()
        return self.default_account

    def validate_account(self, account: Optional[str]) -> Tuple[bool, str, Optional[str]]:
        acct = str(account or self.default_account).strip()
        ok, reason = is_bot_account_compliant(acct, self.allowed_accounts)
        if not ok:
            logger.critical(f"BLINDATGE COMPLIANCE ATI: Bloquejat intent d'ordre automatica al compte '{acct}' ({reason}).")
        return ok, acct, reason

    def place_order(
        self,
        action: str,
        symbol: str,
        qty: int,
        limit_price: float = 0.0,
        account: Optional[str] = None,
        strategy_name: str = "JJ_Layer_Sniper_10AM_ComboElite",
        order_type: str = "MARKET",
        tp_points: Optional[float] = None,
        sl_points: Optional[float] = None,
        ref_price: Optional[float] = None
    ) -> Dict[str, Any]:
        ok_acct, acct, acct_err = self.validate_account(account)
        if not ok_acct:
            return {
                "ok": False,
                "error": "COMPLIANCE_BLOCKED_MANUAL_ONLY_ACCOUNT",
                "account": acct,
                "reason": acct_err,
            }

        action_clean = action.upper()
        order_type_clean = order_type.upper() if order_type else "MARKET"
        nt8_symbol = resolve_nt8_symbol(symbol)
        self._order_seq += 1
        ts_ms = int(time.time() * 1000)
        order_id = f"LS_{acct}_{ts_ms}_{self._order_seq}"
        filename = f"oif_{ts_ms}_{self._order_seq}_{acct}_{action_clean}.txt"
        filepath = os.path.join(self.incoming_dir, filename)

        px_str = f"{limit_price:.2f}" if order_type_clean == "LIMIT" else ""
        cmd = f"PLACE;{acct};{nt8_symbol};{action_clean};{qty};{order_type_clean};{px_str};;DAY;;{order_id};;\n"

        base_px = ref_price if ref_price is not None else limit_price
        sl_order_id = f"SL_{order_id}"
        tp_order_id = f"TP_{order_id}"
        oco_id = f"OCO_{order_id}"
        tp_px = None
        sl_px = None

        if tp_points and sl_points and base_px:
            exit_action = "SELL" if action_clean == "BUY" else "BUY"
            tp_px = round(round_to_tick(base_px + tp_points if action_clean == "BUY" else base_px - tp_points, 0.25), 2)
            sl_px = round(round_to_tick(base_px - sl_points if action_clean == "BUY" else base_px + sl_points, 0.25), 2)
            cmd += f"PLACE;{acct};{nt8_symbol};{exit_action};{qty};LIMIT;{tp_px:.2f};;DAY;{oco_id};{tp_order_id};;\n"
            cmd += f"PLACE;{acct};{nt8_symbol};{exit_action};{qty};STOPMARKET;;{sl_px:.2f};DAY;{oco_id};{sl_order_id};;\n"

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(cmd)
            order_info = {
                "order_id": order_id,
                "sl_order_id": sl_order_id,
                "tp_order_id": tp_order_id,
                "oco_id": oco_id,
                "account": acct,
                "nt8_symbol": nt8_symbol,
                "action": action_clean,
                "qty": qty,
                "entry_price": base_px,
                "tp_price": tp_px,
                "sl_price": sl_px,
                "strategy": strategy_name,
            }
            self.active_orders_by_account[acct.lower()] = order_info
            self.last_active_order = order_info
            logger.info(f"Ordre ATI [{acct}] escrita a {filename}:\n{cmd.strip()}")
            return {"ok": True, "account": acct, "order_id": order_id, "sl_order_id": sl_order_id, "file": filename}
        except Exception as e:
            logger.error(f"Error escrivint fitxer ATI: {e}")
            return {"ok": False, "error": str(e)}

    def _read_actual_entry_fill(self, target_order: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Llegeix `outgoing\\<Account>_<OrderId>.txt` per obtenir el preu real d'execució amb slippage exacte."""
        acct = str(target_order.get("account") or "").strip()
        order_id = str(target_order.get("order_id") or "").strip()
        if not acct or not order_id or not os.path.isdir(self.outgoing_dir):
            return None

        expected_fn = f"{acct}_{order_id}.txt"
        candidate_fp = os.path.join(self.outgoing_dir, expected_fn)
        if not os.path.isfile(candidate_fp):
            try:
                expected_low = expected_fn.lower()
                matched_fn = next(
                    (fn for fn in os.listdir(self.outgoing_dir) if fn.lower() == expected_low),
                    None,
                )
                if not matched_fn:
                    return None
                candidate_fp = os.path.join(self.outgoing_dir, matched_fn)
            except Exception:
                return None

        try:
            lines = _read_shared_file_lines(candidate_fp, max_tail_bytes=16384)
            last_line = next((ln.strip() for ln in reversed(lines) if ln.strip()), "")
            if not last_line:
                return None
            parts = [p.strip() for p in last_line.split(";")]
            if len(parts) < 3:
                return None
            state = parts[0].upper()
            filled_qty = int(float(parts[1].replace(",", ".")))
            avg_fill_price = float(parts[2].replace(",", "."))
            if state in ("FILLED", "PARTFILLED", "PARTIALLYFILLED") and filled_qty > 0 and avg_fill_price > 0:
                return {
                    "state": state,
                    "filled_qty": filled_qty,
                    "avg_fill_price": avg_fill_price,
                    "file": os.path.basename(candidate_fp),
                }
        except Exception as e:
            logger.debug(f"Info llegint fill ATI outgoing ({candidate_fp}): {e}")
        return None

    def move_to_breakeven(
        self,
        be_price: Optional[float] = None,
        entry_price: Optional[float] = None,
        account: Optional[str] = None,
        symbol: Optional[str] = None,
        be_offset_points: Optional[float] = None,
        direction: Optional[str] = None
    ) -> Dict[str, Any]:
        if account is not None and str(account).strip():
            ok_acct, acct, acct_err = self.validate_account(account)
            if not ok_acct:
                return {
                    "ok": False,
                    "error": "COMPLIANCE_BLOCKED_MANUAL_ONLY_ACCOUNT",
                    "account": acct,
                    "reason": acct_err,
                }
            target_order = self.active_orders_by_account.get(acct.lower())
        else:
            target_order = self.last_active_order
            raw_acct = target_order.get("account") if target_order else self.default_account
            ok_acct, acct, acct_err = self.validate_account(raw_acct)
            if not ok_acct:
                return {
                    "ok": False,
                    "error": "COMPLIANCE_BLOCKED_MANUAL_ONLY_ACCOUNT",
                    "account": acct,
                    "reason": acct_err,
                }

        if not target_order:
            logger.warning(f"move_to_breakeven [{acct}]: No hi ha cap ordre activa registrada.")
            return {"ok": False, "error": "NO_ACTIVE_ORDER_TRACKED", "account": acct}

        nt8_symbol = resolve_nt8_symbol(symbol) if symbol else target_order.get("nt8_symbol", resolve_nt8_symbol("MNQ"))
        qty = int(target_order.get("qty", 10))
        sl_order_id = target_order.get("sl_order_id")

        order_action = str(target_order.get("action") or "").upper()
        if order_action in ("BUY", "SELL"):
            is_buy = (order_action == "BUY")
        else:
            dir_clean = str(direction or "LONG").strip().upper()
            is_buy = dir_clean in ("LONG", "BUY")

        raw_ref_entry = entry_price if entry_price is not None else target_order.get("entry_price")
        ref_entry_px = float(raw_ref_entry) if raw_ref_entry is not None and float(raw_ref_entry) > 0 else None

        signed_delta: Optional[float] = None
        is_structural_shield = False
        if be_price is not None and ref_entry_px is not None:
            signed_delta = (float(be_price) - ref_entry_px) if is_buy else (ref_entry_px - float(be_price))
            if signed_delta < -1e-6:
                is_structural_shield = True

        actual_fill = self._read_actual_entry_fill(target_order)
        actual_fill_px: Optional[float] = None
        resolved_offset: Optional[float] = None
        be_source = "WEBHOOK_FALLBACK"

        if actual_fill:
            actual_fill_px = float(actual_fill["avg_fill_price"])
            target_order["actual_fill_price"] = actual_fill_px
            if actual_fill["state"] == "FILLED" and int(actual_fill["filled_qty"]) > 0:
                qty = int(actual_fill["filled_qty"])

        if is_structural_shield and be_price is not None:
            target_be = round_to_tick(float(be_price), 0.25)
            be_source = "STRUCTURAL_SHIELD_LEVEL"
        elif actual_fill_px is not None:
            if be_offset_points is not None:
                resolved_offset = abs(float(be_offset_points))
            elif signed_delta is not None:
                resolved_offset = max(0.0, signed_delta)
            else:
                resolved_offset = 0.50
            raw_be = (actual_fill_px + resolved_offset) if is_buy else (actual_fill_px - resolved_offset)
            target_be = round_to_tick(raw_be, 0.25)
            be_source = "NT8_OUTGOING_ACTUAL_FILL"
        elif be_price is not None:
            target_be = round_to_tick(float(be_price), 0.25)
            be_source = "WEBHOOK_BE_PRICE"
        elif ref_entry_px is not None:
            resolved_offset = abs(float(be_offset_points)) if be_offset_points is not None else 0.50
            raw_be = (ref_entry_px + resolved_offset) if is_buy else (ref_entry_px - resolved_offset)
            target_be = round_to_tick(raw_be, 0.25)
            be_source = "THEORETICAL_ENTRY_FALLBACK"
        else:
            target_be = None

        if target_be is None or not sl_order_id:
            return {"ok": False, "error": "MISSING_BE_PRICE_OR_SL_ID", "account": acct}

        self._order_seq += 1
        ts_ms = int(time.time() * 1000)
        filename = f"oif_be_{ts_ms}_{self._order_seq}_{acct}.txt"
        filepath = os.path.join(self.incoming_dir, filename)
        cmd = f"CHANGE;{acct};{nt8_symbol};;{qty};STOPMARKET;;{float(target_be):.2f};DAY;;{sl_order_id};;\n"

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(cmd)
            target_order["sl_price"] = round(float(target_be), 2)
            logger.info(f"Ordre ATI CHANGE [{acct}] (Breakeven @ {float(target_be):.2f} | Font={be_source}) -> {filename}")
            return {
                "ok": True,
                "account": acct,
                "sl_order_id": sl_order_id,
                "be_price": round(float(target_be), 2),
                "actual_fill_price": actual_fill_px,
                "be_offset_points": resolved_offset,
                "be_source": be_source,
                "file": filename,
            }
        except Exception as e:
            logger.error(f"Error escrivint CHANGE ATI per a Breakeven: {e}")
            return {"ok": False, "error": str(e)}

    def cancel_all(self, account: Optional[str] = None) -> bool:
        ok_acct, acct, _ = self.validate_account(account)
        if not ok_acct:
            return False
        self._order_seq += 1
        filename = f"oif_cancel_{int(time.time() * 1000)}_{self._order_seq}_{acct}.txt"
        filepath = os.path.join(self.incoming_dir, filename)
        cmd = f"CANCELALLORDERS;{acct};;;;;;;;;;;\n"
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(cmd)
            logger.info(f"Ordre ATI CANCELALLORDERS [{acct}] enviada -> {filename}")
            return True
        except Exception as e:
            logger.error(f"Error escrivint cancel·lacio ATI: {e}")
            return False

    def cancel_order(self, order_id: str, account: Optional[str] = None) -> bool:
        ok_acct, acct, _ = self.validate_account(account)
        if not ok_acct:
            return False
        self._order_seq += 1
        filename = f"oif_cancel_{int(time.time() * 1000)}_{self._order_seq}_{acct}.txt"
        filepath = os.path.join(self.incoming_dir, filename)
        cmd = f"CANCEL;{acct};;;;;;;;;{order_id};;\n"
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(cmd)
            logger.info(f"Ordre ATI CANCEL ID {order_id} [{acct}] enviada -> {filename}")
            return True
        except Exception as e:
            logger.error(f"Error escrivint cancel·lacio ATI: {e}")
            return False

    def flatten(self, account: Optional[str] = None) -> bool:
        ok_acct, acct, _ = self.validate_account(account)
        if not ok_acct:
            return False
        self._order_seq += 1
        filename = f"oif_flatten_{int(time.time() * 1000)}_{self._order_seq}_{acct}.txt"
        filepath = os.path.join(self.incoming_dir, filename)
        cmd = f"CLOSEPOSITION;{acct};;;;;;;;;;;\n"
        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(cmd)
            self.active_orders_by_account.pop(acct.lower(), None)
            if self.last_active_order and str(self.last_active_order.get("account", "")).lower() == acct.lower():
                remaining = list(self.active_orders_by_account.values())
                self.last_active_order = remaining[-1] if remaining else None
            logger.info(f"Ordre ATI CLOSEPOSITION [{acct}] enviada -> {filename}")
            return True
        except Exception as e:
            logger.error(f"Error escrivint flatten ATI: {e}")
            return False


executed_counts_today_nt8: Dict[str, Dict[str, int]] = {}


class BridgeHTTPRequestHandler(BaseHTTPRequestHandler):
    writer: Optional[NT8OrderWriter] = None
    expected_secret: str = ""
    restrict_to_tv_ips: bool = False
    extra_allowed_ips: Set[str] = set()
    max_daily_multi_trades: int = 6

    def log_message(self, format_str: str, *args: Any):
        logger.debug("%s - %s", self.client_address[0], format_str % args)

    def _send_json(self, status_code: int, data: Dict[str, Any]):
        body_bytes = json.dumps(data).encode("utf-8")
        self.send_response(status_code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body_bytes)))
        self.end_headers()
        self.wfile.write(body_bytes)

    def _check_ip_allowlist(self) -> bool:
        client_ip = self.client_address[0] if self.client_address else ""
        if not is_client_ip_allowed(client_ip, self.restrict_to_tv_ips, self.extra_allowed_ips):
            logger.warning(f"Bloquejada peticio des d'IP no autoritzada: {client_ip}")
            self._send_json(403, {"error": "IP_NOT_ALLOWED", "ip": client_ip})
            return False
        return True

    def _extract_request_secret(self) -> str:
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        if "secret" in qs and qs["secret"]:
            return str(qs["secret"][0])
        header_sec = self.headers.get("X-Bridge-Secret")
        if header_sec:
            return str(header_sec).strip()
        auth_hdr = self.headers.get("Authorization", "")
        if auth_hdr.lower().startswith("bearer "):
            return auth_hdr[7:].strip()
        return ""

    def _is_authorized(self, candidate: Optional[str] = None) -> bool:
        if not self.expected_secret:
            return False
        provided = str(candidate if candidate is not None else self._extract_request_secret())
        if not provided:
            return False
        valid_secrets = [s.strip() for s in str(self.expected_secret).split(",") if s.strip()]
        return any(secrets.compare_digest(provided.encode("utf-8"), vs.encode("utf-8")) for vs in valid_secrets)

    def do_GET(self):
        if not self._check_ip_allowlist():
            return

        parsed_path = urllib.parse.urlparse(self.path).path
        if parsed_path == "/health":
            today_key = datetime.datetime.now().strftime("%Y-%m-%d")
            resp_data: Dict[str, Any] = {
                "status": "healthy",
                "service": "Layer Sniper Pro - NinjaTrader 8 ATI Bridge",
                "default_account": self.writer.default_account if self.writer else None,
                "allowed_bot_accounts": sorted(self.writer.allowed_accounts) if self.writer else [],
                "manual_blocked_account": "Sim102",
                "compliance_lock": "STRICT_BOT_ISOLATION_ACTIVE",
                "restrict_to_tradingview_ips": self.restrict_to_tv_ips,
                "active_nt8_symbol": resolve_nt8_symbol("MNQ"),
                "executed_counts_today": executed_counts_today_nt8.get(today_key, {}),
            }
            if self._is_authorized() and self.writer:
                resp_data["incoming_dir"] = self.writer.incoming_dir
                resp_data["active_orders_by_account"] = self.writer.active_orders_by_account
            self._send_json(200, resp_data)
            return

        if parsed_path in ("/logs", "/files"):
            if not self._is_authorized():
                self._send_json(401, {"error": "UNAUTHORIZED"})
                return
            if parsed_path == "/logs":
                if os.path.exists(LOG_FILE_PATH):
                    lines = _read_shared_file_lines(LOG_FILE_PATH, max_tail_bytes=65536)[-150:]
                    payload_txt = "\n".join(lines).encode("utf-8")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/plain; charset=utf-8")
                    self.send_header("Content-Length", str(len(payload_txt)))
                    self.end_headers()
                    self.wfile.write(payload_txt)
                else:
                    self._send_json(200, {"logs": "Encara no hi ha registres a vps_bridge.log"})
                return
            if parsed_path == "/files":
                inc_dir = self.writer.incoming_dir if self.writer else get_default_nt8_incoming_path()
                files = os.listdir(inc_dir) if os.path.exists(inc_dir) else []
                self._send_json(200, {"incoming_dir": inc_dir, "files": files})
                return

        self._send_json(404, {"error": "NOT_FOUND"})

    def do_POST(self):
        if not self._check_ip_allowlist():
            return

        parsed_path = urllib.parse.urlparse(self.path).path
        if parsed_path not in ("/", "/webhook", "/api/webhook/tradingview"):
            self._send_json(404, {"error": "NOT_FOUND"})
            return

        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len).decode("utf-8", errors="ignore")

        try:
            payload = json.loads(body)
        except Exception:
            self._send_json(400, {"error": "INVALID_JSON"})
            return

        secret = payload.get("secret")
        if not self._is_authorized(str(secret or "")):
            self._send_json(401, {"error": "UNAUTHORIZED"})
            return

        if self.writer is None:
            self._send_json(500, {"error": "BRIDGE_WRITER_NOT_INITIALIZED"})
            return

        target_acct = self.writer.resolve_target_account(payload)
        ok_acct, resolved_acct, acct_reason = self.writer.validate_account(target_acct)
        if not ok_acct:
            self._send_json(403, {
                "error": "COMPLIANCE_BLOCKED_MANUAL_ONLY_ACCOUNT",
                "account": resolved_acct,
                "reason": acct_reason,
                "message": "Acces ATI automatic bloquejat per proteccio Compliance Prop Firm.",
            })
            return

        action_raw = str(payload.get("action", "Buy")).strip()
        action_lower = action_raw.lower()

        if action_lower in ("cancel", "cancel_all"):
            order_id = payload.get("order_id")
            ok = (
                self.writer.cancel_order(order_id=str(order_id), account=resolved_acct)
                if order_id
                else self.writer.cancel_all(account=resolved_acct)
            )
            self._send_json(200, {"status": "CANCELLED", "account": resolved_acct, "success": ok})
            return

        if action_lower in ("flatten", "close", "close_all"):
            ok_c = self.writer.cancel_all(account=resolved_acct)
            ok_f = self.writer.flatten(account=resolved_acct)
            self._send_json(200, {"status": "FLATTENED", "account": resolved_acct, "success": ok_c and ok_f})
            return

        if action_lower == "exit":
            self._send_json(200, {"status": "EXIT_IGNORED_MANAGED_BY_NT8", "account": resolved_acct})
            return

        if action_lower in ("breakeven", "be", "move_to_be"):
            be_px = payload.get("be_price")
            ent_px = payload.get("entry_price")
            be_off = payload.get("be_offset_points")
            res = self.writer.move_to_breakeven(
                be_price=float(be_px) if be_px is not None else None,
                entry_price=float(ent_px) if ent_px is not None else None,
                account=resolved_acct,
                symbol=payload.get("symbol"),
                be_offset_points=float(be_off) if be_off is not None else None,
                direction=payload.get("direction"),
            )
            status_code = 200 if res.get("ok") else 400
            status_label = "BREAKEVEN_APPLIED_NT8" if res.get("ok") else "BREAKEVEN_FAILED_NT8"
            self._send_json(status_code, {"status": status_label, "account": resolved_acct, "details": res})
            return

        if action_lower not in ("buy", "sell"):
            self._send_json(400, {"error": "INVALID_ACTION", "action": action_raw})
            return

        order_type = str(payload.get("order_type", "Market")).upper()
        raw_symbol = str(payload.get("symbol", DEFAULT_SYMBOL_BASE)).strip()
        strategy = str(payload.get("strategy", "JJ_Layer_Sniper_10AM_ComboElite")).strip()
        clean_strat = strategy.lower()
        qty = int(payload["qty"]) if payload.get("qty") is not None else 10

        today_key = datetime.datetime.now().strftime("%Y-%m-%d")
        for k in list(executed_counts_today_nt8.keys()):
            if k < today_key:
                del executed_counts_today_nt8[k]
        executed_counts_today_nt8.setdefault(today_key, {})

        cur_count = executed_counts_today_nt8[today_key].get(clean_strat, 0)
        is_single_only = ("bloca" in clean_strat or "bloc_a" in clean_strat or "sniper_930" in clean_strat or "obertura" in clean_strat)
        max_allowed = 1 if is_single_only else self.max_daily_multi_trades
        if cur_count >= max_allowed:
            self._send_json(429, {
                "error": "STRATEGY_ALREADY_EXECUTED_TODAY",
                "account": resolved_acct,
                "strategy": strategy,
                "date": today_key,
            })
            return

        price = float(payload["price"]) if "price" in payload and payload.get("price") is not None else None
        tp_points = float(payload["tp_points"]) if "tp_points" in payload and payload.get("tp_points") is not None else None
        sl_points = float(payload["sl_points"]) if "sl_points" in payload and payload.get("sl_points") is not None else None

        if order_type == "LIMIT" and price is None:
            self._send_json(400, {"error": "INVALID_PRICE"})
            return

        res = self.writer.place_order(
            action=action_raw,
            symbol=raw_symbol,
            qty=qty,
            limit_price=price if price is not None else 0.0,
            account=resolved_acct,
            strategy_name=strategy,
            order_type=order_type,
            tp_points=tp_points,
            sl_points=sl_points,
            ref_price=price,
        )

        if res.get("ok"):
            executed_counts_today_nt8[today_key][clean_strat] = cur_count + 1
            self._send_json(200, {
                "status": "ORDER_PLACED",
                "account": resolved_acct,
                "action": action_raw,
                "symbol": resolve_nt8_symbol(raw_symbol),
                "qty": qty,
                "order_type": order_type,
                "price": price,
                "tp_points": tp_points,
                "sl_points": sl_points,
                "strategy": strategy,
                "order_id": res.get("order_id"),
                "sl_order_id": res.get("sl_order_id"),
            })
        else:
            self._send_json(500, {"error": "ATI_WRITE_FAILED", "account": resolved_acct, "details": res})


def load_or_init_bridge_config(config_path: str = DEFAULT_CONFIG_PATH) -> Dict[str, Any]:
    """Llegeix `bridge_config.json` si existeix o genera una configuració segura amb token aleatori únic."""
    if os.path.isfile(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and data.get("webhook_secret"):
                return data
        except Exception as e:
            logger.warning(f"No s'ha pogut llegir {config_path}: {e}")

    generated_secret = "ls_" + secrets.token_hex(12)
    cfg = {
        "port": int(os.environ.get("BRIDGE_PORT", DEFAULT_PORT)),
        "webhook_secret": os.environ.get("BRIDGE_SECRET") or os.environ.get("WEBHOOK_SECRET") or generated_secret,
        "default_account": os.environ.get("BRIDGE_DEFAULT_ACCOUNT", DEFAULT_ACCOUNT),
        "allowed_accounts": os.environ.get("BRIDGE_ALLOWED_ACCOUNTS", DEFAULT_ALLOWED_ACCOUNTS),
        "restrict_to_tradingview_ips": os.environ.get("BRIDGE_RESTRICT_TV_IPS", "false").lower() in ("true", "1", "yes"),
        "extra_allowed_ips": [],
    }
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
        logger.info(f"Fitxer {config_path} inicialitzat amb un nou token secret unic.")
    except Exception as e:
        logger.warning(f"No s'ha pogut desar {config_path}: {e}")
    return cfg


def run_bridge(
    port: int = DEFAULT_PORT,
    secret: str = "",
    account: str = DEFAULT_ACCOUNT,
    incoming_dir: Optional[str] = None,
    allowed_accounts: str = DEFAULT_ALLOWED_ACCOUNTS,
    restrict_to_tv_ips: bool = False,
    extra_allowed_ips: Optional[Iterable[str]] = None,
    config_path: str = DEFAULT_CONFIG_PATH,
):
    cfg = load_or_init_bridge_config(config_path) if not secret else {}
    effective_secret = secret or str(cfg.get("webhook_secret", "")).strip()
    if not effective_secret:
        effective_secret = "ls_" + secrets.token_hex(12)

    inc_dir = incoming_dir or get_default_nt8_incoming_path()
    parsed_allowed = [a.strip() for a in str(allowed_accounts or account).split(",") if a.strip()]
    if account.strip().lower() not in {x.lower() for x in parsed_allowed}:
        parsed_allowed.append(account.strip())

    writer = NT8OrderWriter(
        incoming_dir=inc_dir,
        default_account=account,
        allowed_accounts=parsed_allowed,
    )

    ensure_local_nt8_kit_installed(inc_dir)

    today_key = datetime.datetime.now().strftime("%Y-%m-%d")
    if os.path.exists(LOG_FILE_PATH):
        try:
            recovered = 0
            for ln in _read_shared_file_lines(LOG_FILE_PATH, max_tail_bytes=262144):
                if ln.startswith(today_key) and f"Ordre ATI [{account}] escrita a" in ln:
                    recovered += 1
            if recovered > 0:
                executed_counts_today_nt8.setdefault(today_key, {})
                executed_counts_today_nt8[today_key]["jj_layer_sniper_10am_comboelite"] = recovered
                logger.info(f"Comptador d'ordres d'avui ({today_key}) recuperat del log: {recovered}")
        except Exception:
            pass

    BridgeHTTPRequestHandler.writer = writer
    BridgeHTTPRequestHandler.expected_secret = effective_secret
    BridgeHTTPRequestHandler.restrict_to_tv_ips = restrict_to_tv_ips
    BridgeHTTPRequestHandler.extra_allowed_ips = set(extra_allowed_ips or cfg.get("extra_allowed_ips") or [])

    httpd = ThreadingHTTPServer(("0.0.0.0", port), BridgeHTTPRequestHandler)
    logger.info(f"Layer Sniper Pro NT8 Bridge escoltant a http://0.0.0.0:{port}/webhook")
    logger.info(f"Lider Bot actiu: {account} | Allowlist: {sorted(writer.allowed_accounts)} | Manual bloquejat: Sim102")
    logger.info(f"Filtre estricte d'IPs oficials de TradingView: {'ACTIU' if restrict_to_tv_ips else 'DESACTIVAT'}")
    logger.info(f"Contracte trimestral resolt avui: {resolve_nt8_symbol('MNQ')}")

    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.server_close()


if __name__ == "__main__":
    base_cfg = load_or_init_bridge_config(DEFAULT_CONFIG_PATH)
    parser = argparse.ArgumentParser(description="Layer Sniper Pro - NinjaTrader 8 ATI Webhook Bridge")
    parser.add_argument("--port", type=int, default=int(base_cfg.get("port", DEFAULT_PORT)), help="Port HTTP (80 Directe TV / 8090 Tunel o Railway)")
    parser.add_argument("--secret", type=str, default=str(base_cfg.get("webhook_secret", "")), help="Token secret del Webhook")
    parser.add_argument("--account", type=str, default=str(base_cfg.get("default_account", DEFAULT_ACCOUNT)), help="Compte lider Bot ATI (Sim101)")
    parser.add_argument("--allowed-accounts", type=str, default=str(base_cfg.get("allowed_accounts", DEFAULT_ALLOWED_ACCOUNTS)), help="Comptes Bot permesos separats per comes")
    parser.add_argument("--incoming", type=str, default=None, help="Ruta personalitzada de la carpeta incoming de NT8")
    parser.add_argument("--restrict-tv-ips", dest="restrict_tv_ips", action="store_true", default=bool(base_cfg.get("restrict_to_tradingview_ips", False)), help="Acceptar nomes les 4 IPs oficials de TradingView + LAN/localhost")
    parser.add_argument("--no-restrict-tv-ips", dest="restrict_tv_ips", action="store_false", help="Permetre connexions d'altres origen (ex: Servidor Railway propi)")
    parser.add_argument("--allow-ips", type=str, default="", help="IPs extra permeses separades per comes")
    args = parser.parse_args()

    extra_ips = [ip.strip() for ip in args.allow_ips.split(",") if ip.strip()]
    run_bridge(
        port=args.port,
        secret=args.secret,
        account=args.account,
        incoming_dir=args.incoming,
        allowed_accounts=args.allowed_accounts,
        restrict_to_tv_ips=args.restrict_tv_ips,
        extra_allowed_ips=extra_ips,
    )
