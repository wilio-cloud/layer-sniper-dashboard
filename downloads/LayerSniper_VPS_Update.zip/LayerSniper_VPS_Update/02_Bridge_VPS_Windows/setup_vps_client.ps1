# ==============================================================================
# Layer Sniper Pro — Assistent d'Instal·lació VPS Windows (100% Autònom)
# Suporta:
#   [1] Mode Directe des de TradingView (Port 80 + Firewall 4 IPs TradingView)
#   [2] Mode Directe via Túnel HTTPS Cloudflare (Port 443 -> localhost:8090)
#   [3] Mode Complet Pro connectat a Servidor Railway (Port 8090)
# ==============================================================================
$ErrorActionPreference = "Stop"
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkgRoot = Split-Path -Parent $scriptRoot
$workDir = "C:\LayerSniper"

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host "   LAYER SNIPER PRO - CONFIGURACIO AUTOMATICA DE VPS WINDOWS + NT8         " -ForegroundColor Yellow
Write-Host "============================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Selecciona com vols connectar els Webhooks de TradingView:" -ForegroundColor White
Write-Host "  [1] MODE DIRECTE PORT 80 (Recomanat sense Railway: TradingView -> IP del VPS)" -ForegroundColor Green
Write-Host "  [2] MODE DIRECTE TUNEL HTTPS CLOUDFLARE (Port 443 -> localhost:8090, sense obrir ports)" -ForegroundColor Cyan
Write-Host "  [3] MODE SERVIDOR RAILWAY PRO (TradingView -> Railway -> VPS Port 8090)" -ForegroundColor Yellow
Write-Host ""
$modeChoice = Read-Host "Escriu 1, 2 o 3 [Per defecte: 1]"
if ([string]::IsNullOrWhiteSpace($modeChoice)) { $modeChoice = "1" }

# 1. Crear carpeta C:\LayerSniper
if (-not (Test-Path $workDir)) {
    New-Item -ItemType Directory -Path $workDir -Force | Out-Null
}

# 2. Verificar o instal·lar Python 3.11
Write-Host ""
Write-Host "[1/5] Verificant Python 3..." -ForegroundColor Cyan
$pyCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $pyCmd) {
    Write-Host "Descarregant Python 3.11.9 oficial (instal·lacio silenciosa)..." -ForegroundColor Yellow
    $pyInstaller = "$env:TEMP\python-3.11.9-amd64.exe"
    Invoke-WebRequest -Uri "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe" -OutFile $pyInstaller -UseBasicParsing
    Start-Process -FilePath $pyInstaller -ArgumentList "/quiet InstallAllUsers=1 PrependPath=1" -Wait
    Remove-Item $pyInstaller -Force -ErrorAction SilentlyContinue
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
}
$pyVer = (& python --version 2>&1)
Write-Host "  [OK] Python actiu: $pyVer" -ForegroundColor Green

# 3. Instal·lar el Kit NinjaTrader 8 localment (Plantilles ATM + AddOn BE +2t)
Write-Host "[2/5] Instal·lant Plantilles ATM i AddOn C# a NinjaTrader 8..." -ForegroundColor Cyan
$kitInstaller = Join-Path $pkgRoot "01_Kit_NinjaTrader8_i_Replikanto\install_nt8_kit_offline.ps1"
if (Test-Path $kitInstaller) {
    & $kitInstaller
}
$nt8KitBackup = Join-Path $workDir "nt8_kit"
$srcKitDir = Join-Path $pkgRoot "01_Kit_NinjaTrader8_i_Replikanto"
if (Test-Path $srcKitDir) {
    Copy-Item -Path $srcKitDir -Destination $nt8KitBackup -Recurse -Force
}

# 4. Copiar el Bridge Python i scripts auxiliars a C:\LayerSniper
Write-Host "[3/5] Copiant Bridge ATI a $workDir..." -ForegroundColor Cyan
Copy-Item -Path (Join-Path $scriptRoot "layersniper_nt8_bridge.py") -Destination (Join-Path $workDir "layersniper_nt8_bridge.py") -Force
Copy-Item -Path (Join-Path $scriptRoot "INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat") -Destination (Join-Path $workDir "INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat") -Force
Copy-Item -Path (Join-Path $scriptRoot "PROVAR_CONNEXIO_LOCAL.bat") -Destination (Join-Path $workDir "PROVAR_CONNEXIO_LOCAL.bat") -Force
foreach ($optFn in @("ACTUALITZAR_SISTEMA.bat", "update_vps_client.ps1")) {
    $optSrc = Join-Path $scriptRoot $optFn
    if (Test-Path $optSrc) {
        Copy-Item -Path $optSrc -Destination (Join-Path $workDir $optFn) -Force
    }
}
$pkgVerFile = Join-Path $pkgRoot "VERSION.json"
if (Test-Path $pkgVerFile) {
    Copy-Item -Path $pkgVerFile -Destination (Join-Path $workDir "VERSION.json") -Force
}

# 5. Generar o reutilitzar el Token Secret únic
$cfgPath = Join-Path $workDir "bridge_config.json"
$secretToken = $null
if (Test-Path $cfgPath) {
    try {
        $existingCfg = Get-Content $cfgPath -Raw | ConvertFrom-Json
        if ($existingCfg.webhook_secret) { $secretToken = $existingCfg.webhook_secret }
    } catch {}
}
if (-not $secretToken) {
    $bytes = New-Object byte[] 12
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $hex = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
    $secretToken = "ls_$hex"
}

$targetPort = if ($modeChoice -eq "1") { 80 } else { 8090 }
$restrictTvIps = if ($modeChoice -eq "1") { $true } else { $false }

if ($modeChoice -eq "1") {
    $inUse80 = Get-NetTCPConnection -LocalPort 80 -State Listen -ErrorAction SilentlyContinue
    if ($inUse80) {
        $owningPids = $inUse80 | Select-Object -ExpandProperty OwningProcess -Unique
        Write-Host "  [AVIS] El port 80 esta ocupat actualment (PID: $($owningPids -join ', '))." -ForegroundColor Yellow
        Write-Host "  Si tens IIS (W3SVC) actiu i no el fas servir, atura'l o executa INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat (Mode 2)." -ForegroundColor Yellow
    }
}

$cfgObj = @{
    port = $targetPort
    webhook_secret = $secretToken
    default_account = "Sim101"
    allowed_accounts = "Sim101,Sim103"
    restrict_to_tradingview_ips = $restrictTvIps
    extra_allowed_ips = @()
}
$cfgObj | ConvertTo-Json -Depth 4 | Set-Content -Path $cfgPath -Encoding UTF8

# 6. Configurar el Firewall de Windows de forma segura
Write-Host "[4/5] Configurant regles de seguretat al Windows Defender Firewall..." -ForegroundColor Cyan
Remove-NetFirewallRule -DisplayName "LayerSniper Pro Bridge (Port 80 TV Only)" -ErrorAction SilentlyContinue
Remove-NetFirewallRule -DisplayName "LayerSniper Pro Bridge (Port 8090)" -ErrorAction SilentlyContinue

if ($modeChoice -eq "1") {
    $tvIps = @("52.89.214.238", "34.212.75.30", "54.218.53.128", "52.32.178.7")
    New-NetFirewallRule -DisplayName "LayerSniper Pro Bridge (Port 80 TV Only)" `
        -Direction Inbound -LocalPort 80 -Protocol TCP -Action Allow -RemoteAddress $tvIps | Out-Null
    Write-Host "  [OK] Port TCP 80 obert EXCLUSIVAMENT per a les 4 IPs oficials de TradingView!" -ForegroundColor Green
} elseif ($modeChoice -eq "3") {
    New-NetFirewallRule -DisplayName "LayerSniper Pro Bridge (Port 8090)" `
        -Direction Inbound -LocalPort 8090 -Protocol TCP -Action Allow | Out-Null
    Write-Host "  [OK] Port TCP 8090 obert per rebre el reenviament del teu Servidor Railway!" -ForegroundColor Green
} else {
    Write-Host "  [OK] Mode Tunel HTTPS seleccionat (0 ports entrants oberts al Firewall)." -ForegroundColor Green
}

# 7. Crear accés directe a l'Escriptori i iniciar el Bridge
Write-Host "[5/5] Creant acces directe a l'Escriptori i iniciant el Bridge..." -ForegroundColor Cyan
$desktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::DesktopDirectory)
$batLauncher = Join-Path $desktopPath "Iniciar LayerSniper Bridge.bat"
$tvFlag = if ($restrictTvIps) { "--restrict-tv-ips" } else { "--no-restrict-tv-ips" }

$batBody = @"
@echo off
chcp 65001 >nul
title Layer Sniper Pro - NT8 ATI Bridge (Port $targetPort -> Sim101)
color 0A
echo ============================================================================
echo   LAYER SNIPER PRO - NINJATRADER 8 ATI BRIDGE ACTIU
echo   Port: $targetPort  ^|  Lider Bot: Sim101  ^|  Manual Bloquejat: Sim102
echo ============================================================================
echo.
cd /d C:\LayerSniper
python layersniper_nt8_bridge.py --port $targetPort --account Sim101 --allowed-accounts Sim101,Sim103 $tvFlag
pause
"@
Set-Content -Path $batLauncher -Value $batBody -Encoding ASCII

# Detectar IP pública del VPS per mostrar la URL exacta llesta per copiar
$publicIp = "<IP_PUBLICA_DEL_TEU_VPS>"
try {
    $ipResp = Invoke-RestMethod -Uri "https://api.ipify.org?format=json" -TimeoutSec 5
    if ($ipResp.ip) { $publicIp = $ipResp.ip }
} catch {}

$webhookUrlSummary = if ($modeChoice -eq "1") {
    "http://$publicIp/webhook"
} elseif ($modeChoice -eq "2") {
    "Executa C:\LayerSniper\INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat i copia la URL https://....trycloudflare.com/webhook"
} else {
    "A TradingView: https://<el-teu-railway>.up.railway.app/api/webhook/tradingview  |  A Railway FORWARD_WEBHOOK_URL: http://${publicIp}:8090/webhook"
}

$summaryTxt = @"
============================================================================
  DADES DE CONNEXIO LAYER SNIPER PRO (GUARDA AQUEST FITXER)
============================================================================
Mode seleccionat     : Mode $modeChoice (Port local: $targetPort)
Compte Lider Bot ATI : Sim101 (Activa Tools -> Options -> ATI -> Enabled a NT8)
Compte Lider Manual  : Sim102 (Bloquejat per codi contra ATI per compliance)

1) WEBHOOK SECRET TOKEN (Enganxar als parametres de l'Estrategia Layer Sniper Pro a TradingView):
   $secretToken

2) WEBHOOK URL:
   $webhookUrlSummary
============================================================================
"@
$summaryFile = Join-Path $workDir "DADES_CONNEXIO_TRADINGVIEW.txt"
Set-Content -Path $summaryFile -Value $summaryTxt -Encoding UTF8

Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$batLauncher`"" -WorkingDirectory $workDir

Write-Host ""
Write-Host $summaryTxt -ForegroundColor Yellow
Write-Host "Fitxer desat a: $summaryFile" -ForegroundColor Cyan
Write-Host "Recorda premer F5 dins de NinjaTrader 8 (New -> NinjaScript Editor)!" -ForegroundColor Green
