@echo off
chcp 65001 >nul
title Layer Sniper Pro - Assistent d'Instal-lacio VPS Windows
color 0B
echo ============================================================================
echo   LAYER SNIPER PRO - ASSISTENT D'INSTAL-LACIO DEL BRIDGE AL VPS WINDOWS
echo ============================================================================
echo.
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [AVIS] Executant elevacio de permisos d'Administrador per configurar el Firewall...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup_vps_client.ps1"
echo.
pause
