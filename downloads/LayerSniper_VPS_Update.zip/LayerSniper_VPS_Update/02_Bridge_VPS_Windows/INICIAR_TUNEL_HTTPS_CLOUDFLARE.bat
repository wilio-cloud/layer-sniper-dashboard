@echo off
chcp 65001 >nul
title Layer Sniper Pro - Tunel HTTPS Cloudflare (Port 443 -^> localhost:8090)
color 0E
echo ============================================================================
echo   LAYER SNIPER PRO - TUNEL HTTPS GRATUIT (CLOUDFLARE QUICK TUNNEL)
echo   Exposa http://127.0.0.1:8090 en una URL HTTPS (Port 443) per a TradingView
echo ============================================================================
echo.
set "CF_EXE=C:\LayerSniper\cloudflared.exe"
if not exist "C:\LayerSniper" mkdir "C:\LayerSniper"
if not exist "%CF_EXE%" (
    echo Descarregant client oficial cloudflared per a Windows x64...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe' -OutFile '%CF_EXE%' -UseBasicParsing"
)
echo.
echo [IMPORTANT] Copia la URL que apareixera a sota amb el format:
echo    https://xxxx-xxxx-xxxx.trycloudflare.com
echo I afegeix /webhook al final per enganxar-la a l'Alerta de TradingView:
echo    https://xxxx-xxxx-xxxx.trycloudflare.com/webhook
echo.
"%CF_EXE%" tunnel --url http://127.0.0.1:8090
pause
