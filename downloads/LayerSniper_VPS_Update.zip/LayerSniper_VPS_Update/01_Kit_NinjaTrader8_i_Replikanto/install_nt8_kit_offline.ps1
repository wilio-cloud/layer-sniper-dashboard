# ==============================================================================
# Layer Sniper Pro — Instal·lador Offline del Kit NinjaTrader 8
# Copia les 4 plantilles ATM XML + AddOn C# [BE +2t / FLAT / Auto-Qty] localment
# ==============================================================================
$ErrorActionPreference = "Stop"

$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host ""
Write-Host "Detectant carpeta d'usuari de NinjaTrader 8..." -ForegroundColor Cyan

$myDocs = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::MyDocuments)
$candidates = @(
    (Join-Path $myDocs "NinjaTrader 8"),
    (Join-Path $env:USERPROFILE "Documents\NinjaTrader 8"),
    (Join-Path $env:USERPROFILE "Documentos\NinjaTrader 8"),
    (Join-Path $env:USERPROFILE "OneDrive\Documents\NinjaTrader 8"),
    (Join-Path $env:USERPROFILE "OneDrive\Documentos\NinjaTrader 8")
)

$nt8Root = $null
foreach ($c in $candidates) {
    if ($c -and (Test-Path $c)) {
        $nt8Root = $c
        break
    }
}
if (-not $nt8Root) {
    $nt8Root = Join-Path $myDocs "NinjaTrader 8"
}

Write-Host "Carpeta NinjaTrader 8 seleccionada: $nt8Root" -ForegroundColor Green

$nt8AtmDir = Join-Path $nt8Root "templates\AtmStrategy"
$nt8AddOnsDir = Join-Path $nt8Root "bin\Custom\AddOns"
$nt8IndicatorsDir = Join-Path $nt8Root "bin\Custom\Indicators"

foreach ($dir in @($nt8AtmDir, $nt8AddOnsDir, $nt8IndicatorsDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
    }
}

$srcAtm = Join-Path $scriptRoot "templates\AtmStrategy"
$srcAddOns = Join-Path $scriptRoot "bin\Custom\AddOns"
$srcIndicators = Join-Path $scriptRoot "bin\Custom\Indicators"

if (Test-Path $srcAtm) {
    Get-ChildItem -Path $srcAtm -Filter "*.xml" | ForEach-Object {
        Copy-Item -Path $_.FullName -Destination (Join-Path $nt8AtmDir $_.Name) -Force
        Write-Host "  [OK] Plantilla ATM copiada: $($_.Name)" -ForegroundColor Green
    }
} else {
    throw "No s'ha trobat la carpeta local de plantilles ATM: $srcAtm"
}

if (Test-Path $srcAddOns) {
    Get-ChildItem -Path $srcAddOns -Filter "*.cs" | ForEach-Object {
        Copy-Item -Path $_.FullName -Destination (Join-Path $nt8AddOnsDir $_.Name) -Force
        Write-Host "  [OK] AddOn C# copiat: $($_.Name)" -ForegroundColor Green
    }
}

if (Test-Path $srcIndicators) {
    Get-ChildItem -Path $srcIndicators -Filter "*.cs" | ForEach-Object {
        Copy-Item -Path $_.FullName -Destination (Join-Path $nt8IndicatorsDir $_.Name) -Force
        Write-Host "  [OK] Indicador C# copiat: $($_.Name)" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  TOT COPIAT AMB EXIT! ULTIM PAS DINS DE NINJATRADER 8 (10 SEGONS):" -ForegroundColor Yellow
Write-Host "============================================================================" -ForegroundColor Green
Write-Host "  1. Obre NinjaTrader 8." -ForegroundColor White
Write-Host "  2. Al Control Center ves a: New -> NinjaScript Editor" -ForegroundColor Cyan
Write-Host "  3. Prem la tecla F5 per compilar (sentiras el so de compilacio)." -ForegroundColor Cyan
Write-Host ""
Write-Host "  Un cop compilat, obre qualsevol grafic amb Chart Trader actiu:" -ForegroundColor White
Write-Host "  - Veuras els botons [BE +2t (+0.50p)] i [FLAT] integrats automaticament." -ForegroundColor White
Write-Host "  - En triar una plantilla ATM LS_*, la casella 'Order qty' s'ajustara sola." -ForegroundColor White
