@echo off
chcp 65001 >nul
title Layer Sniper Pro - Instal-lador Kit NinjaTrader 8 (Offline)
color 0A
echo ============================================================================
echo   LAYER SNIPER PRO - INSTAL-LADOR KIT NINJATRADER 8 (100%% OFFLINE)
echo   Plantilles ATM (30p TP / 30p SL) + Botons [BE +2t] i [FLAT] + Auto-Qty
echo ============================================================================
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_nt8_kit_offline.ps1"
echo.
pause
