# 02 · Configuració de TradingView i Creació d'Alertes (Pas a Pas)

Segueix aquesta guia exactament en l'ordre indicat. Una configuració incorrecta del tipus d'espelma, de les dades CME, del desplegable *Condition* o de la caixa *Message* de l'alerta és la causa més freqüent d'errors.

---

## 1. Preparació del Gràfic Base (`MNQ1!` · `1m`)

1. A la barra superior esquerra de TradingView, busca el símbol **`MNQ1!`** (*Micro E-mini Nasdaq-100 Futures — Continuous contract*, mercat **CME_MINI**).
2. Selecciona la temporalitat d'**1 minut (`1m`)**. L'algorisme calcula l'àncora de les `09:30 NY` i l'estructura BOS sobre barres d'1 minut exactes.
3. Selecciona el tipus de gràfic **Espelmes estàndard (*Candles*)**.
   - ⚠️ **IMPORTANT:** No utilitzis **mai** *Heikin Ashi*, *Renko*, *Range* ni *Hollow Candles* modificades, ja que alteren els preus d'obertura/tancament sintètics i corrompen els nivells d'execució.
4. A la cantonada inferior dreta del gràfic, comprova que la zona horària estigui en **`New York (UTC-5 / UTC-4)`** (tot i que l'estratègia calcula internament `America/New_York` de forma independent, tenir el gràfic en hora NY facilita la lectura visual de la finestra `09:30 – 12:00`).
5. **Verificació de Dades CME en Temps Real:**
   - Al costat del nom `MNQ1! · 1 · CME` (a dalt a l'esquerra), comprova que NO hi aparegui cap icona taronja `D` (*Delayed 10m*). Ha d'estar en temps real.
   - A la cantonada inferior dreta del gràfic, assegura't que els botons **`B-ADJ`** (*Adjust for contract changes*) i **`SET`** estiguin **DESACTIVATS** (apagats) per veure exactament els mateixos preus de mercat actuals que cotitzen a NinjaTrader 8 / Tradovate.

---

## 2. Afegir l'Estratègia *Invite-Only* (`Layer Sniper Pro`)

1. Fes clic al botó superior **Indicators (`Indicadors`)**.
2. A la columna esquerra de la finestra emergent, clica a **Invite-only scripts (`Scripts només amb invitació`)**.
   - *(Si no veus aquesta pestanya o l'estratègia no hi apareix, tanca la sessió de TradingView i torna a entrar, o prem `F5` al navegador un cop se t'hagi concedit l'accés).*
3. Fes un sol clic sobre **`Layer Sniper Pro`** per carregar-la al gràfic.

---

## 3. Configuració dels Paràmetres de l'Estratègia (Roda Dentada ⚙️)

Passa el ratolí pel nom de l'estratègia **`Layer Sniper Pro`** a dalt a l'esquerra del gràfic i prem la icona de **Configuració (⚙️)** -> pestanya **Inputs (`Entrades de dades`)**:

### Bloc `🚀 0. Mode d'Execució & Webhook Bridge`
- **Mode Operatiu (Flota):**
  - Deixa per defecte `SNIPER COMBO ELITE (Max 2/Dia: Dual + Cont. L10_2>=55p & L11_1)` (màxim 2 entrades diàries filtrades) o selecciona el mode específic que vulguis operar (ex: `BLOC A` per a màxim 1 entrada diària a partir de les `10:00 NY`).
- **Webhook Secret Token:**
  - **Substitueix el valor per defecte** pel token secret únic generat per l'instal·lador del teu Bridge VPS (`C:\LayerSniper\DADES_CONNEXIO_TRADINGVIEW.txt`, ex: `ls_8a4f...`) o pel valor de `WEBHOOK_SECRET` que hagis posat a Railway.
- **Compte Líder ATI (Opcional, ex: Sim101):**
  - Pots deixar-lo **buit** (el teu Bridge ja enviarà les ordres a `Sim101` per defecte).
  - Omple'l (ex: escrivint `Sim101` o `Sim103`) només si tens dos gràfics amb configuracions diferents a TradingView apuntant a dos comptes líders diferents del mateix NinjaTrader 8.
- **Filtres Llei 5A i 5B (Festius EUA i Nadal):**
  - Mantén-los **activats (`true`)** per evitar ordres automàtiques en dies festius del CME/NYSE o baixa liquiditat de final de desembre.

### Bloc `🔄 0B. Rotació Setmanal d'Equip (3, 4 o 5 Slots · 4/5 Dies)`
- **Si operes en solitari (o en el gràfic d'operativa manual `Sim102`):**
  - Deixa `Mode d'Equip (Total Slots Actius)` en **`0. DESACTIVAT (5/5 Dies — Individual)`** per operar tots els 5 dies hàbils de la setmana.
- **Si formes part d'un equip coordinat amb Bot (`Sim101` / `Sim103`):**
  1. Selecciona la mida de l'equip a **Mode d'Equip**: `Equip de 3 Slots`, `Equip de 4 Slots` o `Equip de 5 Slots`.
  2. Selecciona a **El Meu Slot Assignat (Fix)** l'únic `Slot` que tens assignat (`Slot 1`, `Slot 2`, `Slot 3`, `Slot 4` o `Slot 5`) **abans** de crear l'alerta de Webhook.
  3. **Rotació 100% automàtica sense tocar mai l'alerta:** Cada dilluns a les `00:00 NY`, l'estratègia rota sola quin dia de la setmana descansa el teu `Slot` (`Dl -> Dm -> Dc -> Dj -> Dv`), operant `4 de 5` dies amb zero coincidència completa de grup i conservant intacte el càlcul intern del `Rang 5D`.
  4. **Escalat futur sense recrear alertes (`3 -> 4 -> 5 Slots`):** Els `Slots 1, 2 i 3` utilitzen desfasaments encaixats (`[0, 2, 4, 1, 3]`), de manera que si més endavant s'incorpora un 4t o 5è membre (`Slot 4` o `Slot 5`), els membres actuals (`Slots 1–3`) **no necessiten esborrar ni tornar a crear les seves alertes de TradingView**.

### Bloc `1. Perfil de Risc i Fase de Compte (Presets)`
- **Perfil de Lotatge i Brackets:**
  - Selecciona la mida d'ordre que vols que s'enviï al teu **Compte Líder** (`Sim101`):
    - `BLOC A 10 MNQ (30 TP / 30 SL @ 10 MNQ)` *(Recomanat com a líder base de `10 MNQ`: permet que Replikanto escali fàcilment als followers amb ràtio `1.0` = 10 MNQ, `0.5` = 5 MNQ, `0.3` = 3 MNQ o `3.0` = 30 MNQ).*
    - `CONSOLIDACIÓ 5 MNQ (30 TP / 30 SL @ 5 MNQ)`
    - `FUNDED DEFENSIU 3 MNQ (30 TP / 30 SL @ 3 MNQ)`

### Bloc `2. Àncora de Preu Just & Escut Breakeven`
- **🛡️ Llei 2: Activar Escut de Protecció al LAYER:** `Activat (true)`.
- **⚙️ Mode d'Escut BE / Sortida LAYER:** `1. BE Clàssic a Entrada LAYER (entry2 · 0p en TP 1)`.
- **Offset de Breakeven:** `0.50` (`+2 ticks` a favor sobre el preu d'entrada real per cobrir comissions sense tallar recorregut).

Prem **OK (`D'acord`)** per desar els canvis al gràfic.

---

## 4. Com Crear l'Alerta Automàtica de Webhook (1 Sola Alerta ho Fa Tot)

> **⚠️ PUNT CRÍTIC — LLEGEIX AMB ATENCIÓ:**  
> L'estratègia `Layer Sniper Pro` envia les entrades (`Buy`/`Sell`) com a execucions d'ordre de l'estratègia (`strategy.entry`) i envia l'`Escut Breakeven` instantani al tick mitjançant la funció `alert()`.  
> Per tant, en crear l'alerta has de complir **2 requisits obligatoris**:
> 1. Al segon desplegable de *Condition*, triar **`Order fills and alert() function calls`** (*"Ejecuciones de órdenes y llamadas a la función alert()"*).
> 2. A la caixa **`Message`**, esborrar tot el text per defecte i posar exactament: **`{{strategy.order.alert_message}}`**.

### Passos exactes per crear l'alerta automàtica:

1. Amb el gràfic `MNQ1!` (`1m`) obert i l'estratègia ja configurada, prem el botó del rellotge **Alerts (`Alertes`) -> Create Alert (`+` o `Alt + A`)**.
2. Pestanya **Settings (`Configuració`)**:
   - **Condition (`Condició`) — Primer desplegable:** Selecciona **`Layer Sniper Pro`**.
   - **Condition (`Condició`) — Segon desplegable (just a sota):** Selecciona obligatòriament **`Order fills and alert() function calls`** *(en castellà/català: "Ejecuciones de órdenes y llamadas a la función alert()")*.
   - **Message (`Missatge`):** Esborra tot el text que apareix per defecte i escriu **únicament**:
     ```text
     {{strategy.order.alert_message}}
     ```
   - **Alert name (`Nom de l'alerta`):** Posa un nom clar, ex: `AUTO — Layer Sniper Pro MNQ1! -> Sim101`.
   - **Expiration (`Venciment`):** Posa la data màxima permesa o marca *Open-ended alert* si tens pla Premium.
3. Pestanya **Notifications (`Notificacions`)**:
   - Marca la casella **`Webhook URL`**.
   - Enganxa la URL exacta segons el teu mode d'instal·lació:
     - **Mode Directe VPS (Port 80):** `http://<IP_DEL_TEU_VPS>/webhook` *(ex: `http://203.0.113.45/webhook` — sense `:80` ni `https`, comença per `http://`)*.
     - **Mode Directe VPS (Túnel HTTPS Cloudflare):** `https://<subdomini-generat>.trycloudflare.com/webhook`
     - **Mode Complet Pro (Railway):** `https://<el-teu-domini>.up.railway.app/api/webhook/tradingview`
4. Fes clic a **Create (`Crear`)**.

> **Important si canvies algun paràmetre més endavant:**  
> TradingView desa una "fotografia" dels paràmetres de l'estratègia en el moment de crear l'alerta. Si mai canvies el `Webhook Secret Token`, el `Mode Operatiu` o el `Perfil de Lotatge` a la roda dentada ⚙️ de l'estratègia, **esborra l'alerta antiga i torna-la a crear en 15 segons** perquè agafi els nous valors.

---

## 5. Alerta d'Avís al Mòbil per a Operativa Manual (`Sim102`)

Si operes comptes manuals (Apex PA, TPT, Topstep) fent clic humà sobre `Sim102`, crea **1 alerta sense marcar `Webhook URL`** (marcant només *Notify in app* i *Play sound*):

1. **Condition (`Condició`):** `Layer Sniper Pro` -> **`Order fills and alert() function calls`**.
2. **Notifications (`Notificacions`):** Deixa **`Webhook URL` DESMARCADA** i marca *Notify in app* + *Play sound*.
3. **Com operar quan soni:**
   - Quan vegis al gràfic l'etiqueta gris `👀 PREPARAT BUY/SELL (Esperant LAYER)`, prepara NinjaTrader (`Sim102`).
   - Amb el **1r avís sonor** (entrada `LAYER`), fes clic a `Buy Mkt` o `Sell Mkt` a `Sim102`.
   - Amb el **2n avís sonor** (`TP 1` tocat -> `breakeven`), fes clic al botó verd **`[🛡️ BE +2t (+0.50p)]`** del Chart Trader.
