"""
Mòdul News Guardian (Escut de Notícies Red Folder USD de Prop Firm) per a JJ Layer Sniper Pro 2026
Protecció automàtica nativa en horari America/New_York (immune a canvis DST EUA/Europa) contra
HARD BREACH de regles de News Trading (Lucid Daily Funded, TPT PRO/PRO+, MFFU, Alpha Futures, Phidias).
"""

import datetime
import logging
from typing import Optional, Dict, Any, Tuple, List
from bot.config import config

logger = logging.getLogger("NewsGuardian")


def _w10am(date_str: str, event_name: str, prohibited_strategies: Optional[List[str]] = None) -> Dict[str, Any]:
    """Crea una finestra de bloqueig de ±2 minuts al voltant d'una notícia USD Red Folder de les 10:00 AM NY (09:58 - 10:02 NY)."""
    return {
        "date": date_str,
        "event": f"{event_name} (10:00 NY)",
        "start_time_ny": "09:58",
        "end_time_ny": "10:02",
        "exact_time_ny": "10:00 NY",
        # Camps informatius / retrocompatibilitat
        "start_time_cest": "15:58",
        "end_time_cest": "16:02",
        "exact_time_cest": "16:00 BCN (15:00 en setmana DST)",
        "prohibited_strategies": list(prohibited_strategies or []),
    }


RESTRICTED_NEWS_WINDOWS: List[Dict[str, Any]] = [
    # --- HISTÒRIC ESTIU/TARDOR 2026 ---
    _w10am("2026-08-28", "Fed Chairman Speaks - Jackson Hole"),
    _w10am("2026-09-01", "ISM Manufacturing PMI"),

    # --- OCTUBRE 2026 (Setmana de desfasament DST 5h: 10:00 NY = 15:00 CET!) ---
    _w10am("2026-10-27", "CB Consumer Confidence"),

    # --- NOVEMBRE 2026 (USD Red Folder 10:00 AM NY) ---
    _w10am("2026-11-02", "ISM Manufacturing PMI"),
    _w10am("2026-11-03", "JOLTS Job Openings + US Midterm Elections"),
    _w10am("2026-11-04", "ISM Services PMI (Post-Midterms)"),
    _w10am("2026-11-06", "Prelim UoM Consumer Sentiment"),
    _w10am("2026-11-24", "CB Consumer Confidence"),

    # --- DESEMBRE 2026 (USD Red Folder 10:00 AM NY) ---
    _w10am("2026-12-01", "ISM Manufacturing PMI + JOLTS Job Openings"),
    _w10am("2026-12-03", "ISM Services PMI"),
    _w10am("2026-12-04", "Prelim UoM Consumer Sentiment"),
    _w10am("2026-12-22", "CB Consumer Confidence"),

    # --- ANY 2027 COMPLET (ISM Mfg, ISM Services, JOLTS, CB Consumer Confidence, Prelim UoM - 10:00 AM NY) ---
    # Gener 2027
    _w10am("2027-01-04", "ISM Manufacturing PMI"),
    _w10am("2027-01-05", "JOLTS Job Openings"),
    _w10am("2027-01-06", "ISM Services PMI"),
    _w10am("2027-01-15", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-01-26", "CB Consumer Confidence"),
    # Febrer 2027
    _w10am("2027-02-01", "ISM Manufacturing PMI"),
    _w10am("2027-02-02", "JOLTS Job Openings"),
    _w10am("2027-02-03", "ISM Services PMI"),
    _w10am("2027-02-12", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-02-23", "CB Consumer Confidence"),
    # Març 2027
    _w10am("2027-03-01", "ISM Manufacturing PMI"),
    _w10am("2027-03-03", "ISM Services PMI"),
    _w10am("2027-03-09", "JOLTS Job Openings"),
    _w10am("2027-03-12", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-03-30", "CB Consumer Confidence"),
    # Abril 2027
    _w10am("2027-04-01", "ISM Manufacturing PMI"),
    _w10am("2027-04-05", "ISM Services PMI"),
    _w10am("2027-04-06", "JOLTS Job Openings"),
    _w10am("2027-04-09", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-04-27", "CB Consumer Confidence"),
    # Maig 2027
    _w10am("2027-05-03", "ISM Manufacturing PMI"),
    _w10am("2027-05-04", "JOLTS Job Openings"),
    _w10am("2027-05-05", "ISM Services PMI"),
    _w10am("2027-05-14", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-05-25", "CB Consumer Confidence"),
    # Juny 2027
    _w10am("2027-06-01", "ISM Manufacturing PMI + JOLTS Job Openings"),
    _w10am("2027-06-03", "ISM Services PMI"),
    _w10am("2027-06-11", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-06-29", "CB Consumer Confidence"),
    # Juliol 2027
    _w10am("2027-07-01", "ISM Manufacturing PMI"),
    _w10am("2027-07-06", "ISM Services PMI + JOLTS Job Openings"),
    _w10am("2027-07-16", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-07-27", "CB Consumer Confidence"),
    # Agost 2027
    _w10am("2027-08-02", "ISM Manufacturing PMI"),
    _w10am("2027-08-03", "JOLTS Job Openings"),
    _w10am("2027-08-04", "ISM Services PMI"),
    _w10am("2027-08-13", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-08-31", "CB Consumer Confidence"),
    # Setembre 2027
    _w10am("2027-09-01", "ISM Manufacturing PMI"),
    _w10am("2027-09-03", "ISM Services PMI"),
    _w10am("2027-09-07", "JOLTS Job Openings"),
    _w10am("2027-09-17", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-09-28", "CB Consumer Confidence"),
    # Octubre 2027
    _w10am("2027-10-01", "ISM Manufacturing PMI"),
    _w10am("2027-10-05", "ISM Services PMI + JOLTS Job Openings"),
    _w10am("2027-10-15", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-10-26", "CB Consumer Confidence"),
    # Novembre 2027
    _w10am("2027-11-01", "ISM Manufacturing PMI"),
    _w10am("2027-11-02", "JOLTS Job Openings"),
    _w10am("2027-11-03", "ISM Services PMI"),
    _w10am("2027-11-12", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-11-30", "CB Consumer Confidence"),
    # Desembre 2027
    _w10am("2027-12-01", "ISM Manufacturing PMI"),
    _w10am("2027-12-03", "ISM Services PMI"),
    _w10am("2027-12-07", "JOLTS Job Openings"),
    _w10am("2027-12-10", "Prelim UoM Consumer Sentiment"),
    _w10am("2027-12-28", "CB Consumer Confidence"),
]


class NewsGuardian:
    def __init__(self):
        self.windows = RESTRICTED_NEWS_WINDOWS

    def _to_ny_dt(self, dt: Optional[datetime.datetime] = None) -> datetime.datetime:
        """
        Converteix qualsevol datetime a America/New_York de manera segura amb pytz.
        Si es passa un datetime naive (sense tzinfo), s'assumeix horari de Madrid per retrocompatibilitat.
        """
        if dt is None:
            return datetime.datetime.now(config.tz_ny)
        if dt.tzinfo is None:
            localized_madrid = config.tz_madrid.localize(dt)
            return localized_madrid.astimezone(config.tz_ny)
        return dt.astimezone(config.tz_ny)

    def _get_windows_for_date(self, date_str: str) -> List[Dict[str, Any]]:
        matched = [w for w in self.windows if w["date"] == date_str]
        # Cinturó extra amb MACRO_EVENTS (08:30 NY per NFP/CPI i 14:00 NY per FOMC)
        try:
            from bot.macro_calendar import MACRO_EVENTS
            ev = MACRO_EVENTS.get(date_str)
            if ev:
                ev_type = str(ev.get("type", "")).upper()
                ev_name = str(ev.get("name", "Macro Event"))
                if ev_type in ("NFP", "CPI"):
                    matched.append({
                        "date": date_str,
                        "event": f"{ev_name} (08:30 NY)",
                        "start_time_ny": "08:28",
                        "end_time_ny": "08:32",
                        "exact_time_ny": "08:30 NY",
                        "prohibited_strategies": [],
                    })
                elif ev_type == "FOMC" and "Dia 1" not in ev_name:
                    matched.append({
                        "date": date_str,
                        "event": f"{ev_name} (14:00 NY)",
                        "start_time_ny": "13:58",
                        "end_time_ny": "14:02",
                        "exact_time_ny": "14:00 NY",
                        "prohibited_strategies": [],
                    })
        except Exception:
            pass
        return matched

    @staticmethod
    def _window_bounds_ny(w: Dict[str, Any]) -> Tuple[str, str]:
        start_ny = w.get("start_time_ny") or "09:58"
        end_ny = w.get("end_time_ny") or "10:02"
        return start_ny, end_ny

    def is_in_restricted_window(self, dt: Optional[datetime.datetime] = None) -> Tuple[bool, Optional[Dict[str, Any]]]:
        now_ny = self._to_ny_dt(dt)
        date_str = now_ny.strftime("%Y-%m-%d")
        now_hm = now_ny.strftime("%H:%M")

        for w in self._get_windows_for_date(date_str):
            start_ny, end_ny = self._window_bounds_ny(w)
            if start_ny <= now_hm <= end_ny:
                return True, w
        return False, None

    def is_strategy_prohibited(self, strategy_name: str, dt: Optional[datetime.datetime] = None) -> Tuple[bool, Optional[str]]:
        now_ny = self._to_ny_dt(dt)
        date_str = now_ny.strftime("%Y-%m-%d")
        now_hm = now_ny.strftime("%H:%M")

        for w in self._get_windows_for_date(date_str):
            prohibited = w.get("prohibited_strategies", [])
            strat_clean = strategy_name.strip()
            exact_ny = w.get("exact_time_ny", "10:00 NY")
            if any(p.lower() in strat_clean.lower() for p in prohibited):
                return True, f"Prohibit per {w['event']} ({exact_ny}). Risc de Hard Breach."

            start_ny, end_ny = self._window_bounds_ny(w)
            if start_ny <= now_hm <= end_ny:
                now_bcn = now_ny.astimezone(config.tz_madrid).strftime("%H:%M %Z")
                return True, (
                    f"Finestra activa de Notícies Red Folder: {w['event']} "
                    f"({start_ny} a {end_ny} NY | ara {now_bcn})."
                )

        return False, None

    def check_sentinel_emergency_flatten(self, has_position: bool, dt: Optional[datetime.datetime] = None) -> Tuple[bool, Optional[str]]:
        """
        S'activa quan tenim posició oberta i entrem a la finestra de seguretat pre-notícia
        (ex: 09:58:00 NY per a una notícia de les 10:00:00 NY), deixant marge suficient per aplanar
        abans del minut crític 09:59:00 NY (Hard Breach ±1 min a Lucid Daily Funded i TPT PRO).
        """
        if not has_position:
            return False, None

        now_ny = self._to_ny_dt(dt)
        date_str = now_ny.strftime("%Y-%m-%d")

        for w in self._get_windows_for_date(date_str):
            start_ny, end_ny = self._window_bounds_ny(w)
            sh, sm = map(int, start_ny.split(":"))
            start_dt = now_ny.replace(hour=sh, minute=sm, second=0, microsecond=0)
            eh, em = map(int, end_ny.split(":"))
            end_dt = now_ny.replace(hour=eh, minute=em, second=59, microsecond=0)

            sec_to_start = (start_dt - now_ny).total_seconds()
            if 0 <= sec_to_start <= 15 or (start_dt <= now_ny <= end_dt):
                now_bcn = now_ny.astimezone(config.tz_madrid).strftime("%H:%M:%S %Z")
                return True, (
                    f"EMERGÈNCIA RED FOLDER: {w['event']} — Finestra d'escut {start_ny}-{end_ny} NY "
                    f"(ara {now_ny.strftime('%H:%M:%S')} NY / {now_bcn}). Aplanat preventiu abans de ±1 min!"
                )

        return False, None


news_guardian = NewsGuardian()
