"""
Base de Dades i Radar Automàtic del Calendari Macroeconòmic, Festius USA + Nadal (2025 - 2030),
Volatilitat Pre-Sessió dels Últims 5 Dies i Timing d'Estacionalitat (Setmana 4 / OPEX / Evaluations)
per a CME Globex MNQ — JJ Layer Sniper Pro 2026.
"""

import os
import glob
import json
import time
import datetime
import logging
from typing import Optional, Dict, Any, List, Tuple
import pandas as pd
import pytz
import requests

logger = logging.getLogger("MacroCalendar")

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_1M_DIR = os.path.join(ROOT_DIR, "MNQ", "data", "1m_ny_daily")
PARQUET_1M_YEAR = os.path.join(ROOT_DIR, "MNQ", "data", "mnq_1m_1year.parquet")
PLAYBOOKS_JSON_PATH = os.path.join(ROOT_DIR, "config", "historical_day_playbooks.json")

_PLAYBOOKS_CACHE: Optional[Dict[str, Any]] = None
_YAHOO_5D_CACHE: Dict[str, Tuple[float, Dict[str, float]]] = {}

DAYS_CA = {
    0: "Dilluns",
    1: "Dimarts",
    2: "Dimecres",
    3: "Dijous",
    4: "Divendres",
    5: "Dissabte",
    6: "Diumenge",
}

GOOD_FRIDAY_DATES = {
    20250418: "Good Friday (Divendres Sant)",
    20260403: "Good Friday (Divendres Sant)",
    20270326: "Good Friday (Divendres Sant)",
    20280414: "Good Friday (Divendres Sant)",
    20290330: "Good Friday (Divendres Sant)",
    20300419: "Good Friday (Divendres Sant)",
}

MACRO_EVENTS = {
    # --- 2026 ---
    "2026-09-16": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision", "time_cest": "20:00 CEST", "instructions": "Decisió de tipus de la Fed. Finestra matinal (16:00-16:59 CEST) operable amb normalitat."},
    "2026-09-18": {"type": "OPEX", "severity": "AMBER", "name": "Quadruple Witching OpEx (Venciment Trimestral)", "time_cest": "Tot el dia", "instructions": "Alta volatilitat d'expiració de contractes. Precaució a l'obertura de NY."},
    "2026-10-02": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY (14:30 CEST). La finestra Layer Sniper (10:00-10:59 NY) ja ha absorbit l'impacte inicial."},
    "2026-10-14": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY (14:30 CEST). Finestra 10:00-10:59 NY operable amb filtre d'Àncora 09:30 NY."},
    "2026-10-27": {"type": "NEWS_10AM", "severity": "AMBER", "name": "CB Consumer Confidence (10:00 NY / 15:00 CET DST)", "time_cest": "15:00 CET", "instructions": "Notícia Red Folder USD a les 10:00 NY (15:00 CET pel canvi d'hora DST). Escut actiu 09:58-10:02 NY: estar 100% flat abans de les 09:59 NY."},
    "2026-10-28": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision (19:00 CET DST)", "time_cest": "19:00 CET", "instructions": "Decisió de tipus de la Fed a les 14:00 NY (19:00 CET per setmana DST). Finestra matinal (14:30-16:59 CET) operable amb normalitat."},
    "2026-10-29": {"type": "GDP_PCE", "severity": "AMBER", "name": "PIB EUA Q3 Advance + Core PCE / Claims (08:30 NY / 13:30 CET DST)", "time_cest": "13:30 CET", "instructions": "Dades clau de PIB Q3 i PCE a les 08:30 NY (1h abans de l'obertura 09:30 NY) + Ressaca Post-FOMC + Big Tech Earnings."},
    "2026-11-02": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada Red Folder a les 10:00 NY exactes. Escut actiu 09:58-10:02 NY."},
    "2026-11-03": {"type": "JOLTS", "severity": "AMBER", "name": "US Midterm Elections + JOLTS Job Openings (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Jornada d'Eleccions Legislatives EUA (escrutini nocturn fora de sessió) + JOLTS Red Folder a les 10:00 NY. Escut actiu 09:58-10:02 NY."},
    "2026-11-04": {"type": "ISM", "severity": "AMBER", "name": "Post-Midterms + ISM Services PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Ressaca electoral (l'Àncora de les 09:30 NY absorbeix el gap nocturn) + ISM Services Red Folder a les 10:00 NY. Escut actiu 09:58-10:02 NY."},
    "2026-11-06": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA 08:30 NY) + Prelim UoM Sentiment (10:00 NY)", "time_cest": "14:30 / 16:00 CET", "instructions": "NFP a les 08:30 NY + Prelim UoM Sentiment a les 10:00 NY. Escut preventiu actiu 09:58-10:02 NY."},
    "2026-11-11": {"type": "HOLIDAY", "severity": "GRAY", "name": "Veterans Day (Festiu Bancari EUA)", "time_cest": "Tot el dia", "instructions": "Llei 5A activa: Festiu bancari EUA amb baixa liquiditat. No operar."},
    "2026-11-12": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY. Finestra Layer Sniper 09:30-11:59 NY operable."},
    "2026-11-20": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Venciment Opcions Novembre)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX (Gamma Pinning favorable a reversió)."},
    "2026-11-24": {"type": "NEWS_10AM", "severity": "AMBER", "name": "CB Consumer Confidence (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Notícia Red Folder USD a les 10:00 NY. Escut actiu 09:58-10:02 NY."},
    "2026-11-26": {"type": "HOLIDAY", "severity": "GRAY", "name": "Thanksgiving Day", "time_cest": "Tot el dia", "instructions": "CME Globex tancat. Festa operativa."},
    "2026-11-27": {"type": "HOLIDAY", "severity": "GRAY", "name": "Black Friday (Early Close)", "time_cest": "19:00 CET", "instructions": "Tancament anticipat de mercat. Volum baix, no operar."},
    "2026-12-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI + JOLTS (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada Red Folder a les 10:00 NY exactes. Escut actiu 09:58-10:02 NY."},
    "2026-12-03": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada Red Folder a les 10:00 NY exactes. Escut actiu 09:58-10:02 NY."},
    "2026-12-04": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA 08:30 NY) + Prelim UoM Sentiment (10:00 NY)", "time_cest": "14:30 / 16:00 CET", "instructions": "NFP a les 08:30 NY + Prelim UoM Sentiment a les 10:00 NY. Escut preventiu actiu 09:58-10:02 NY."},
    "2026-12-09": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision + Projeccions SEP (Powell)", "time_cest": "20:00 CET", "instructions": "Reunió trimestral clau de la Fed a les 14:00 NY. Finestra matinal operable amb normalitat."},
    "2026-12-10": {"type": "ROLLOVER", "severity": "AMBER", "name": "Rollover CME MNQH7 + CPI (Inflació EUA 08:30 NY)", "time_cest": "14:30 CET", "instructions": "Post-FOMC + Dada CPI a les 08:30 NY + canvi de contracte trimestral cap a MNQH7 (Març 2027)."},
    "2026-12-18": {"type": "OPEX", "severity": "AMBER", "name": "Quadruple Witching OpEx (Venciment Trimestral Desembre)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX (alta reversió institucional). Últim dia fort abans de la pausa de Nadal."},
    "2026-12-22": {"type": "NEWS_10AM", "severity": "AMBER", "name": "CB Consumer Confidence (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada 10:00 NY dins el període de bloqueig nadalenc (22-31 Des)."},
    "2026-12-24": {"type": "HOLIDAY", "severity": "GRAY", "name": "Christmas Eve", "time_cest": "19:15 CET", "instructions": "Tancament anticipat. Sense volum institucional. No operar."},
    "2026-12-25": {"type": "HOLIDAY", "severity": "GRAY", "name": "Nadal", "time_cest": "Tot el dia", "instructions": "CME Globex tancat."},
    "2026-12-31": {"type": "HOLIDAY", "severity": "GRAY", "name": "Cap d'Any (Early Close)", "time_cest": "Tot el dia", "instructions": "Volum festiu reduït. Mercat sense liquiditat institucional."},

    # --- 2027 (CALENDARI INSTITUCIONAL OFICIAL FEDERAL RESERVE / CME / BLS / ISM) ---
    "2027-01-01": {"type": "HOLIDAY", "severity": "GRAY", "name": "New Year's Day (Cap d'Any)", "time_cest": "Tot el dia", "instructions": "CME Globex tancat."},
    "2027-01-04": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "1r dia operatiu 2027 + ISM a les 10:00 NY."},
    "2027-01-06": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI + JOLTS (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-01-08": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY. Setmana 1 d'alta volatilitat."},
    "2027-01-13": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY. Absorbida abans de l'obertura 09:30 NY."},
    "2027-01-15": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Venciment Mensual Opcions Gener)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX (Gamma Pinning favorable a reversió)."},
    "2027-01-18": {"type": "HOLIDAY", "severity": "GRAY", "name": "Martin Luther King Jr. Day", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-01-27": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision (Gener 2027)", "time_cest": "20:00 CET", "instructions": "Decisió Fed a les 14:00 NY. Finestra matinal operable amb normalitat."},
    "2027-02-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-02-03": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-02-05": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY."},
    "2027-02-11": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY."},
    "2027-02-15": {"type": "HOLIDAY", "severity": "GRAY", "name": "Presidents' Day", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-02-19": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Venciment Opcions Febrer)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-03-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-03-03": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-03-05": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY."},
    "2027-03-11": {"type": "ROLLOVER", "severity": "AMBER", "name": "Rollover CME MNQM7 + CPI (Inflació EUA 08:30 NY)", "time_cest": "14:30 CET", "instructions": "Dada CPI 08:30 NY + Rollover cap al contracte de Juny 2027 (MNQM7)."},
    "2027-03-17": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision + SEP (Horari DST 5h)", "time_cest": "19:00 CET", "instructions": "Decisió Fed a les 14:00 NY (19:00 CET per canvi d'hora EUA)."},
    "2027-03-19": {"type": "OPEX", "severity": "AMBER", "name": "Quadruple Witching OpEx (Març 2027)", "time_cest": "Tot el dia", "instructions": "Venciment trimestral Q1."},
    "2027-03-26": {"type": "HOLIDAY", "severity": "GRAY", "name": "Good Friday (Divendres Sant)", "time_cest": "Tot el dia", "instructions": "Mercat CME tancat (Llei 5A). No operar."},
    "2027-04-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-04-02": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-04-05": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-04-13": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-04-16": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Abril 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-04-28": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision (Abril 2027)", "time_cest": "20:00 CEST", "instructions": "Decisió oficial Fed a les 14:00 NY. Finestra matinal operable."},
    "2027-05-03": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-05-05": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada Red Folder a les 10:00 NY exactes. Escut actiu 09:58-10:02 NY."},
    "2027-05-07": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-05-12": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-05-21": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Maig 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-05-31": {"type": "HOLIDAY", "severity": "GRAY", "name": "Memorial Day", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-06-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-06-03": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-06-04": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-06-09": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision + SEP", "time_cest": "20:00 CEST", "instructions": "Decisió oficial Fed a les 14:00 NY."},
    "2027-06-10": {"type": "ROLLOVER", "severity": "AMBER", "name": "Rollover CME MNQU7 + CPI (Inflació EUA 08:30 NY)", "time_cest": "14:30 CEST", "instructions": "Post-FOMC + Dada CPI 08:30 NY + Rollover cap al contracte de Setembre 2027 (MNQU7)."},
    "2027-06-18": {"type": "HOLIDAY", "severity": "GRAY", "name": "Juneteenth Observed", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-07-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-07-02": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-07-05": {"type": "HOLIDAY", "severity": "GRAY", "name": "Independence Day Observed", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-07-06": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-07-14": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-07-16": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Juliol 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-07-28": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision", "time_cest": "20:00 CEST", "instructions": "Decisió Fed a les 14:00 NY."},
    "2027-08-02": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-08-04": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-08-06": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-08-11": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-08-20": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Agost 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-09-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-09-03": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA) + ISM Services (10:00 NY)", "time_cest": "14:30 CEST", "instructions": "NFP a les 08:30 NY i ISM Services a les 10:00 NY."},
    "2027-09-06": {"type": "HOLIDAY", "severity": "GRAY", "name": "Labor Day", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-09-09": {"type": "ROLLOVER", "severity": "AMBER", "name": "Rollover Trimestral CME MNQZ7 (Desembre 2027)", "time_cest": "Tot el dia", "instructions": "2n Dijous de Setembre: migració de volum cap a MNQZ7."},
    "2027-09-14": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-09-15": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision + SEP", "time_cest": "20:00 CEST", "instructions": "Decisió oficial Fed a les 14:00 NY."},
    "2027-09-17": {"type": "OPEX", "severity": "AMBER", "name": "Quadruple Witching OpEx (Setembre 2027)", "time_cest": "Tot el dia", "instructions": "Venciment trimestral Q3."},
    "2027-10-01": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA) + ISM Mfg (10:00 NY)", "time_cest": "14:30 CEST", "instructions": "NFP 08:30 NY + ISM Manufacturing 10:00 NY."},
    "2027-10-05": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "16:00 CEST", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-10-13": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CEST", "instructions": "Dada a les 08:30 NY."},
    "2027-10-15": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Octubre 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-10-27": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision (Octubre 2027)", "time_cest": "20:00 CEST", "instructions": "Decisió oficial Fed a les 14:00 NY."},
    "2027-11-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "15:00 CET", "instructions": "Dada a les 10:00 NY (15:00 CET per setmana de desfasament DST)."},
    "2027-11-03": {"type": "ISM", "severity": "AMBER", "name": "ISM Services PMI (10:00 NY)", "time_cest": "15:00 CET", "instructions": "Dada Red Folder a les 10:00 NY (15:00 CET DST)."},
    "2027-11-05": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA)", "time_cest": "13:30 CET", "instructions": "Dada a les 08:30 NY (13:30 CET)."},
    "2027-11-10": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY."},
    "2027-11-11": {"type": "HOLIDAY", "severity": "GRAY", "name": "Veterans Day", "time_cest": "Tot el dia", "instructions": "Festiu bancari EUA (Llei 5A). No operar."},
    "2027-11-19": {"type": "OPEX", "severity": "AMBER", "name": "Monthly OPEX (Novembre 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX."},
    "2027-11-25": {"type": "HOLIDAY", "severity": "GRAY", "name": "Thanksgiving Day", "time_cest": "Tot el dia", "instructions": "Festiu oficial EUA (Llei 5A). No operar."},
    "2027-11-26": {"type": "HOLIDAY", "severity": "GRAY", "name": "Black Friday (Early Close)", "time_cest": "19:00 CET", "instructions": "Post-Thanksgiving sense volum institucional (Llei 5A). No operar."},
    "2027-12-01": {"type": "ISM", "severity": "AMBER", "name": "ISM Manufacturing PMI (10:00 NY)", "time_cest": "16:00 CET", "instructions": "Dada a les 10:00 NY exactes."},
    "2027-12-03": {"type": "NFP", "severity": "AMBER", "name": "NFP (Ocupació EUA) + ISM Services (10:00 NY)", "time_cest": "14:30 CET", "instructions": "NFP 08:30 NY i ISM Services a les 10:00 NY."},
    "2027-12-08": {"type": "FOMC", "severity": "RED", "name": "FOMC Rate Decision + SEP", "time_cest": "20:00 CET", "instructions": "Última reunió oficial Fed de l'any a les 14:00 NY."},
    "2027-12-09": {"type": "ROLLOVER", "severity": "AMBER", "name": "Rollover Trimestral CME MNQH8 (Març 2028)", "time_cest": "Tot el dia", "instructions": "Post-FOMC + 2n Dijous de Desembre: migració de volum cap a MNQH8."},
    "2027-12-14": {"type": "CPI", "severity": "AMBER", "name": "CPI (Inflació EUA)", "time_cest": "14:30 CET", "instructions": "Dada a les 08:30 NY."},
    "2027-12-17": {"type": "OPEX", "severity": "AMBER", "name": "Quadruple Witching OpEx (Desembre 2027)", "time_cest": "Tot el dia", "instructions": "Setmana 3 OPEX abans del tancament de Nadal (22-31 Des)."},
}


def get_us_holiday_or_xmas_info(dt: datetime.date) -> Tuple[bool, Optional[str]]:
    """
    Replica exacta de la Llei 5A + 5B de Pine Script (Festius Borsa EUA + Vacances de Nadal 22-31 Des).
    Retorna (is_holiday, nom_del_festiu).
    """
    y, m, d = dt.year, dt.month, dt.day
    dow = dt.weekday()  # 0=Dilluns .. 6=Diumenge
    date_id = y * 10000 + m * 100 + d

    if m == 12 and d >= 22:
        return True, "Vacances de Nadal i Cap d'Any (Bloqueig 22–31 Des)"
    if m == 1 and (d == 1 or (d == 2 and dow == 0)):
        return True, "New Year's Day (Cap d'Any)"
    if m == 1 and dow == 0 and 15 <= d <= 21:
        return True, "Martin Luther King Jr. Day"
    if m == 2 and dow == 0 and 15 <= d <= 21:
        return True, "Presidents' Day"
    if date_id in GOOD_FRIDAY_DATES:
        return True, GOOD_FRIDAY_DATES[date_id]
    if m == 5 and dow == 0 and d >= 25:
        return True, "Memorial Day"
    if m == 6 and (d == 19 or (d == 18 and dow == 4) or (d == 20 and dow == 0)):
        return True, "Juneteenth Holiday"
    if m == 7 and (d == 3 or d == 4 or (d == 5 and dow == 0)):
        return True, "Independence Day (4th of July)"
    if m == 9 and dow == 0 and d <= 7:
        return True, "Labor Day"
    if m == 11 and (d == 11 or (d == 10 and dow == 4) or (d == 12 and dow == 0)):
        return True, "Veterans Day"
    if m == 11 and (dow == 3 and 22 <= d <= 28):
        return True, "Thanksgiving Day (Acció de Gràcies)"
    if m == 11 and (dow == 4 and 23 <= d <= 29):
        return True, "Black Friday (Post-Thanksgiving Early Close)"

    return False, None


def get_macro_event_for_date(target_date: Optional[datetime.date] = None) -> Optional[Dict[str, Any]]:
    if target_date is None:
        target_date = datetime.date.today()
    date_key = target_date.strftime("%Y-%m-%d")
    if date_key in MACRO_EVENTS:
        return MACRO_EVENTS[date_key]
    is_hol, hol_name = get_us_holiday_or_xmas_info(target_date)
    if is_hol and target_date.weekday() < 5:
        return {
            "type": "HOLIDAY",
            "severity": "GRAY",
            "name": hol_name,
            "time_cest": "Tot el dia",
            "instructions": "Festiu oficial EUA / Bloqueig de Nadal (Llei 5A/5B). No operar.",
        }
    return None


def get_week_holidays_radar(target_date: Optional[datetime.date] = None) -> List[Dict[str, str]]:
    """
    Retorna tots els dies festius USA o de Nadal (de Dilluns a Divendres)
    de la setmana a la qual pertany `target_date`.
    """
    if target_date is None:
        target_date = datetime.date.today()
    monday = target_date - datetime.timedelta(days=target_date.weekday())
    holidays = []
    for offset in range(5):
        d = monday + datetime.timedelta(days=offset)
        is_hol, hol_name = get_us_holiday_or_xmas_info(d)
        if is_hol:
            holidays.append({
                "date": d.isoformat(),
                "date_str": d.strftime("%d/%m/%Y"),
                "day_name": DAYS_CA[d.weekday()],
                "name": hol_name or "Festiu EUA",
            })
    return holidays


def _fetch_live_yahoo_5d_ny_ranges(target_date: datetime.date) -> Dict[str, float]:
    """
    Fallback lleuger ($0.00, 0 MB disc) per a Railway quan la carpeta local `MNQ/` no hi és:
    consulta els últims 10 dies de barres de 5m de `NQ=F` i calcula el rang 09:30–11:00 NY
    de cada sessió hàbil, amb cau en memòria de 2 hores.
    """
    target_str = target_date.isoformat()
    now_ts = time.time()
    cached = _YAHOO_5D_CACHE.get("latest")
    if cached and (now_ts - cached[0]) < 7200:
        return {k: v for k, v in cached[1].items() if k < target_str}

    try:
        resp = requests.get(
            "https://query1.finance.yahoo.com/v8/finance/chart/NQ=F?interval=5m&range=10d",
            headers={"User-Agent": "Mozilla/5.0"},
            timeout=4,
        )
        if resp.status_code != 200:
            return {}
        res_list = resp.json().get("chart", {}).get("result") or []
        if not res_list:
            return {}
        res = res_list[0]
        timestamps = res.get("timestamp") or []
        quote = (res.get("indicators", {}).get("quote") or [{}])[0]
        highs = quote.get("high") or []
        lows = quote.get("low") or []
        tz_ny = pytz.timezone("America/New_York")

        by_day: Dict[str, List[Tuple[float, float]]] = {}
        for ts_val, h_val, l_val in zip(timestamps, highs, lows):
            if h_val is None or l_val is None:
                continue
            dt_ny = datetime.datetime.fromtimestamp(ts_val, tz_ny)
            if dt_ny.weekday() >= 5:
                continue
            dt_d = dt_ny.date()
            is_h, _ = get_us_holiday_or_xmas_info(dt_d)
            if is_h:
                continue
            hm = dt_ny.hour * 100 + dt_ny.minute
            if 930 <= hm < 1100:
                by_day.setdefault(dt_d.isoformat(), []).append((float(h_val), float(l_val)))

        computed: Dict[str, float] = {}
        for ds, pairs in by_day.items():
            if len(pairs) >= 10:
                computed[ds] = round(max(p[0] for p in pairs) - min(p[1] for p in pairs), 1)

        if computed:
            _YAHOO_5D_CACHE["latest"] = (now_ts, computed)
        return {k: v for k, v in computed.items() if k < target_str}
    except Exception as e:
        logger.debug(f"Fallback Yahoo 5D range no disponible: {e}")
        return {}


def get_rolling_5d_ny_range_stats(target_date: Optional[datetime.date] = None) -> Dict[str, Any]:
    """
    Calcula a cost $0.00 la mitjana del rang matinal de Nova York (09:30 - 11:00 NY)
    dels últims 5 dies operatius anteriors a `target_date` utilitzant la cau local
    (`MNQ/data/1m_ny_daily/*.parquet` i `mnq_1m_1year.parquet`) o el fallback en viu de `NQ=F` a Railway.
    """
    if target_date is None:
        target_date = datetime.date.today()
    target_str = target_date.isoformat()

    day_ranges: Dict[str, float] = {}

    # 1. Llegir fitxers diaris recents a MNQ/data/1m_ny_daily/
    if os.path.exists(CACHE_1M_DIR):
        daily_files = sorted(glob.glob(os.path.join(CACHE_1M_DIR, "*.parquet")))
        for f_path in daily_files[-20:]:
            dt_str = os.path.basename(f_path).replace(".parquet", "")
            if dt_str >= target_str:
                continue
            try:
                df = pd.read_parquet(f_path)
                if df.empty or "high" not in df.columns:
                    continue
                if "t_num" not in df.columns and "ny_time" in df.columns:
                    ny_t = pd.to_datetime(df["ny_time"])
                    df["t_num"] = ny_t.dt.hour * 100 + ny_t.dt.minute
                sub = df[(df["t_num"] >= 930) & (df["t_num"] < 1100)] if "t_num" in df.columns else df
                if len(sub) >= 30:
                    day_ranges[dt_str] = round(float(sub["high"].max() - sub["low"].min()), 1)
            except Exception as e:
                logger.debug(f"Error llegint {f_path}: {e}")

    # 2. Si tenim menys de 5 dies a 1m_ny_daily, completar amb mnq_1m_1year.parquet si cobreix dates anteriors
    if len(day_ranges) < 5 and os.path.exists(PARQUET_1M_YEAR):
        try:
            df_y = pd.read_parquet(PARQUET_1M_YEAR, columns=["ny_time", "high", "low"])
            ny_t = pd.to_datetime(df_y["ny_time"])
            df_y["date_str"] = ny_t.dt.strftime("%Y-%m-%d")
            df_y["t_num"] = ny_t.dt.hour * 100 + ny_t.dt.minute
            sub_y = df_y[(df_y["date_str"] < target_str) & (df_y["t_num"] >= 930) & (df_y["t_num"] < 1100)]
            if not sub_y.empty:
                last_dates = sorted(sub_y["date_str"].unique())[-10:]
                sub_recent = sub_y[sub_y["date_str"].isin(last_dates)]
                for dt_s, g in sub_recent.groupby("date_str"):
                    if dt_s not in day_ranges and len(g) >= 30:
                        day_ranges[dt_s] = round(float(g["high"].max() - g["low"].min()), 1)
        except Exception as e:
            logger.debug(f"Error llegint mnq_1m_1year.parquet: {e}")

    # 3. Fallback en viu per a Railway o quan falta l'última sessió hàbil al disc local
    prev_trading_iso = get_previous_valid_trading_date(target_date).isoformat()
    if (len(day_ranges) < 5 or prev_trading_iso not in day_ranges) and abs((datetime.date.today() - target_date).days) <= 7:
        live_ranges = _fetch_live_yahoo_5d_ny_ranges(target_date)
        for dt_s, r_val in live_ranges.items():
            if dt_s not in day_ranges:
                day_ranges[dt_s] = r_val

    sorted_days = sorted(day_ranges.keys())[-5:]
    last_5_values = [day_ranges[k] for k in sorted_days]
    avg_5d = round(sum(last_5_values) / len(last_5_values), 1) if last_5_values else 235.0
    is_slow = avg_5d < 220.0

    return {
        "target_date": target_str,
        "days_used": sorted_days,
        "ranges_pts": last_5_values,
        "avg_5d_range_pts": avg_5d,
        "threshold_pts": 220.0,
        "is_slow_regime": is_slow,
        "regime_label": "🐢 MERCAT LENT / COMPRIMIT (<220p)" if is_slow else "🔥 MERCAT VOLÀTIL / ÒPTIM (>=220p)",
    }


def _load_historical_playbooks() -> Dict[str, Any]:
    global _PLAYBOOKS_CACHE
    if _PLAYBOOKS_CACHE is not None:
        return _PLAYBOOKS_CACHE
    if os.path.exists(PLAYBOOKS_JSON_PATH):
        try:
            with open(PLAYBOOKS_JSON_PATH, encoding="utf-8") as f:
                _PLAYBOOKS_CACHE = json.load(f)
                return _PLAYBOOKS_CACHE
        except Exception as e:
            logger.warning(f"No s'ha pogut carregar {PLAYBOOKS_JSON_PATH}: {e}")
    return {"archetypes": {}, "standard_dow": {}}


def get_previous_valid_trading_date(dt: datetime.date) -> datetime.date:
    """Retorna el dia hàbil operable immediatament anterior (saltant caps de setmana i festius EUA)."""
    cur = dt - datetime.timedelta(days=1)
    for _ in range(15):
        if cur.weekday() < 5:
            is_h, _ = get_us_holiday_or_xmas_info(cur)
            if not is_h:
                return cur
        cur -= datetime.timedelta(days=1)
    return dt - datetime.timedelta(days=1)


def _is_cme_rollover_date(dt: datetime.date) -> bool:
    """2n Dijous o 2n Divendres de Març, Juny, Setembre i Desembre."""
    if dt.month not in (3, 6, 9, 12):
        return False
    first_day = dt.replace(day=1)
    days_to_thu = (3 - first_day.weekday()) % 7
    second_thu = 1 + days_to_thu + 7
    return dt.day in (second_thu, second_thu + 1)


def get_historical_day_pattern_insight(
    target_date: Optional[datetime.date] = None,
    avg_5d_range_pts: float = 235.0,
) -> Dict[str, Any]:
    """
    Identifica l'arquetip institucional exacte de `target_date` i retorna les mètriques històriques
    auditades d'anys anteriors (3A 1m + 2A 1s) sense biaix direccional, més l'avís d'escut 10:00 NY si aplica.
    """
    if target_date is None:
        target_date = datetime.date.today()

    is_hol, hol_name = get_us_holiday_or_xmas_info(target_date)
    if is_hol:
        return {
            "archetype_code": "HOLIDAY_OR_XMAS",
            "badge": f"🏖️ Festiu EUA / Nadal ({hol_name})",
            "short_field": "🛑 Festiu EUA (No Operar)",
            "sessions_3y": 0,
            "avg_ny_range_pts": 0.0,
            "wr_1s": 0.0,
            "pattern_summary": "En dies festius bancaris EUA o tancament de Nadal (22–31 Des) no hi ha volum institucional i les desviacions són soroll erràtic.",
            "tactical_takeaway": "Llei 5A/5B activa: avui el bot i els comptes es mantenen 100% tancats.",
            "shield_10am_alert": None,
            "discord_lines": (
                f"• **Arquetip (`{hol_name}`):** Sense liquiditat institucional real.\n"
                "• **Pauta Operativa:** Cadenat actiu tot el dia — zero operacions."
            ),
        }

    playbooks = _load_historical_playbooks()
    arch_map = playbooks.get("archetypes", {})
    std_dow_map = playbooks.get("standard_dow", {})

    ev_today = get_macro_event_for_date(target_date)
    ev_type = str(ev_today.get("type", "")).upper() if ev_today else ""
    ev_name = str(ev_today.get("name", "")) if ev_today else ""

    prev_valid = get_previous_valid_trading_date(target_date)
    ev_prev = get_macro_event_for_date(prev_valid)
    is_prev_fomc = bool(
        ev_prev
        and str(ev_prev.get("type", "")).upper() == "FOMC"
        and "Dia 1" not in str(ev_prev.get("name", ""))
    )

    # Detectar finestres d'escut Red Folder 10:00 NY (NewsGuardian) per avui amb hora BCN exacta (DST-aware)
    shield_10am_alert: Optional[str] = None
    has_10am_red = ev_type in ("ISM", "JOLTS", "NEWS_10AM")
    try:
        from bot.news_guardian import RESTRICTED_NEWS_WINDOWS
        tz_ny = pytz.timezone("America/New_York")
        tz_bcn = pytz.timezone("Europe/Madrid")
        d_iso = target_date.isoformat()
        w10_matches = [w for w in RESTRICTED_NEWS_WINDOWS if w.get("date") == d_iso]
        if w10_matches:
            has_10am_red = True
            w0 = w10_matches[0]
            sh, sm = map(int, (w0.get("start_time_ny") or "09:58").split(":"))
            eh, em = map(int, (w0.get("end_time_ny") or "10:02").split(":"))
            s_bcn = tz_ny.localize(datetime.datetime(target_date.year, target_date.month, target_date.day, sh, sm)).astimezone(tz_bcn)
            e_bcn = tz_ny.localize(datetime.datetime(target_date.year, target_date.month, target_date.day, eh, em)).astimezone(tz_bcn)
            ev_lbl = w0.get("event", "Red Folder 10:00 NY")
            shield_10am_alert = (
                f"🛡️ **Escut Red Folder Actiu (`{s_bcn.strftime('%H:%M')}–{e_bcn.strftime('%H:%M')} BCN` / "
                f"`{sh:02d}:{sm:02d}–{eh:02d}:{em:02d} NY`):** *{ev_lbl}* — aplanat preventiu automàtic per protegir `LucidDaily / TPT`."
            )
    except Exception as e:
        logger.debug(f"Error consultant finestres 10AM: {e}")

    dow = target_date.weekday()
    dom = target_date.day
    wom = (dom - 1) // 7 + 1
    is_slow = avg_5d_range_pts < 220.0

    # Selecció jeràrquica de l'arquetip institucional del dia
    chosen_key: Optional[str] = None
    if ev_type == "FOMC" and "Dia 1" not in ev_name:
        chosen_key = "FOMC_DAY"
    elif is_prev_fomc:
        chosen_key = "POST_FOMC_DAY"
    elif ev_type == "ROLLOVER" or _is_cme_rollover_date(target_date):
        chosen_key = "ROLLOVER_CME"
    elif ev_type == "NFP" or (dow == 4 and 1 <= dom <= 7):
        chosen_key = "NFP_FRIDAY"
    elif has_10am_red:
        chosen_key = "NEWS_10AM_RED"
    elif dow == 4 and 15 <= dom <= 21:
        chosen_key = "OPEX_FRIDAY"
    elif ev_type == "CPI":
        chosen_key = "CPI_DAY"
    elif wom == 3:
        chosen_key = "OPEX_WEEK"
    elif wom == 5:
        chosen_key = "MONTH_END"

    if chosen_key and chosen_key in arch_map:
        raw = dict(arch_map[chosen_key])
        p_sum = raw["pattern_summary"].format(**raw)
        takeaway = raw["tactical_takeaway"]
        short_f = raw["short_field"].format(**raw)

        # Si avui hi ha a més una dada secundària rellevant a MACRO_EVENTS (ex: Post-FOMC + PIB Q3/PCE 08:30 NY)
        extra_bits: List[str] = []
        if ev_today and chosen_key == "POST_FOMC_DAY":
            extra_bits.append(f"Catalitzador addicional avui: **{ev_name}** *(absorbit abans d'obrir a les 09:30 NY)*.")
        elif ev_today and chosen_key not in ("FOMC_DAY", "NEWS_10AM_RED", "CPI_DAY", "NFP_FRIDAY", "ROLLOVER_CME") and ev_name:
            extra_bits.append(f"Agenda d'avui: **{ev_name}**.")
        if shield_10am_alert and chosen_key != "NEWS_10AM_RED":
            extra_bits.append(shield_10am_alert)
        elif shield_10am_alert and chosen_key == "NEWS_10AM_RED":
            takeaway = f"{shield_10am_alert} A partir de les `10:02 NY`, via lliure."

        full_takeaway = (" ".join(extra_bits) + " " + takeaway).strip() if extra_bits else takeaway
        discord_lines = (
            f"• **Arquetip Detectat (`{raw['badge']}` · `{raw['sessions_3y']}` sessions):** {p_sum}\n"
            f"• **Pauta Tàctica Avui:** {full_takeaway}"
        )
        return {
            "archetype_code": chosen_key,
            "badge": raw["badge"],
            "short_field": short_f,
            "sessions_3y": raw["sessions_3y"],
            "avg_ny_range_pts": raw["avg_ny_range_pts"],
            "wr_1s": raw["wr_1s"],
            "pattern_summary": p_sum,
            "tactical_takeaway": full_takeaway,
            "shield_10am_alert": shield_10am_alert,
            "discord_lines": discord_lines,
        }

    # Sessió estàndard sense catalitzador macro especial -> desglossament exacte per Dia de la Setmana + Règim Rang 5D
    dow_entry = std_dow_map.get(str(dow), {})
    bucket_key = "slow_5d" if is_slow else "fast_5d"
    st = dow_entry.get(bucket_key) or dow_entry.get("all") or {
        "sessions_3y": 130,
        "avg_ny_range_pts": 216.0,
        "rev_ratio": 0.510,
        "overnight_fade_pct": 52.0,
        "w_1s": 35,
        "be_1s": 18,
        "l_1s": 22,
        "wr_1s": 61.4,
        "pts_1s": 340.0,
    }
    all_st = dow_entry.get("all") or st
    dow_title = dow_entry.get("title") or DAYS_CA.get(dow, "Sessió Estàndard")
    reg_tag = "Rang 5D <220p" if is_slow else "Rang 5D >=220p"
    badge = f"📊 {dow_title} ({reg_tag})"
    short_f = f"📊 {DAYS_CA.get(dow, 'Avui')} ({st['wr_1s']}% WR · Rang {st['avg_ny_range_pts']:.0f}p)"
    p_sum = (
        f"En sessions netes de **{DAYS_CA.get(dow, '')}** amb `{reg_tag}` (`{st['sessions_3y']}` sessions en 3 anys), "
        f"el rang matinal mitjà és de `{st['avg_ny_range_pts']:.0f}p` (gir nocturn `{st['overnight_fade_pct']:.0f}%`) "
        f"amb **`{st['wr_1s']}% WR` a 1s** (`{st['w_1s']}W / {st['be_1s']}BE / {st['l_1s']}L`, `{st['pts_1s']:+.1f}p`; global del dia `{all_st['wr_1s']}% WR`)."
    )
    if dow == 2:
        takeaway = "Els dimecres sense FOMC concentren molts Break-Evens (`~30% BE`): paciència màxima, zero sobre-operativa i no estrenar Evals nous."
    elif is_slow and wom == 4:
        takeaway = "Combinació de Setmana 4 + mercat lent: màxima prudència i protecció dels comptes Funded propers a cobrament."
    else:
        takeaway = "Sessió neta sense soroll macro a les 10:00 NY: deixa que el preu s'allunyi >=50p de l'àncora de les 09:30 NY i executa només amb confirmació LAYER."
    if shield_10am_alert:
        takeaway = f"{shield_10am_alert} {takeaway}"

    discord_lines = (
        f"• **Arquetip Detectat (`{badge}`):** {p_sum}\n"
        f"• **Pauta Tàctica Avui:** {takeaway}"
    )
    return {
        "archetype_code": f"STANDARD_DOW_{dow}",
        "badge": badge,
        "short_field": short_f,
        "sessions_3y": st["sessions_3y"],
        "avg_ny_range_pts": st["avg_ny_range_pts"],
        "wr_1s": st["wr_1s"],
        "pattern_summary": p_sum,
        "tactical_takeaway": takeaway,
        "shield_10am_alert": shield_10am_alert,
        "discord_lines": discord_lines,
    }


def get_seasonality_and_account_timing_advice(
    target_date: Optional[datetime.date] = None,
    avg_5d_range_pts: Optional[float] = None
) -> Dict[str, Any]:
    """
    Genera el diagnòstic automàtic de:
    1) Setmana del Mes (Setmanes 1..5) i alerta especial per a la Setmana 4 (Dies 22-28)
       o el Divendres previ al dia 22 segons si els 5 dies anteriors han estat lents (<220p) o volàtils (>=220p).
    2) Semàfor de Compra / Estrena de Nous Comptes d'Avaluació (evitar Dimecres i Dia 22 / Setmana 4;
       prioritzar Dijous, Divendres i Dimarts a les Setmanes 1 i 3).
    3) Radar de Festius USA + Nadal de la setmana actual.
    """
    if target_date is None:
        target_date = datetime.date.today()

    if avg_5d_range_pts is None:
        vol_stats = get_rolling_5d_ny_range_stats(target_date)
        avg_5d_range_pts = vol_stats["avg_5d_range_pts"]
    else:
        vol_stats = {
            "avg_5d_range_pts": round(float(avg_5d_range_pts), 1),
            "is_slow_regime": float(avg_5d_range_pts) < 220.0,
        }

    dom = target_date.day
    wom = (dom - 1) // 7 + 1
    dow = target_date.weekday()
    dow_name = DAYS_CA.get(dow, "")
    is_slow = avg_5d_range_pts < 220.0
    is_hol, hol_name = get_us_holiday_or_xmas_info(target_date)
    week_holidays = get_week_holidays_radar(target_date)

    # 1. Diagnòstic de la Setmana del Mes i Regla de la 4a Setmana (Dies 22-28)
    # També pre-avisa si som Divendres entre els dies 18 i 21 (just abans que comenci la setmana del 22!)
    approaching_week4 = (wom == 3 and dom >= 18 and dow == 4)

    if wom == 4:
        if is_slow:
            week4_status = "DANGER_SLOW"
            week4_headline = (
                f"🛑 **ALERTA 4a SETMANA + MERCAT LENT (`{avg_5d_range_pts:.0f}p < 220p`):** "
                f"La setmana anterior al dia 22 ha estat molt lenta/comprimida. "
                f"Històricament és l'únic moment de l'any amb esperança negativa (`35.3% WR`, `-145.5p`). "
                f"**Recomanació:** Evitar operar aquesta setmana o protegir els comptes PA que tinguis a punt de cobrar!"
            )
        else:
            week4_status = "SAFE_VOLATILE"
            week4_headline = (
                f"🟢 **4a SETMANA AMB BONA VOLATILITAT (`{avg_5d_range_pts:.0f}p >= 220p`):** "
                f"La setmana anterior al dia 22 ha estat viva i volàtil. "
                f"**Recomanació:** Podem operar la 4a setmana amb total normalitat per seguir sumant dies verds cap als Payouts!"
            )
    elif approaching_week4:
        if is_slow:
            week4_status = "PRE_WARNING_SLOW"
            week4_headline = (
                f"⚠️ **PRE-AVÍS PER DILLUNS (ENTRADA A 4a SETMANA · Dies 22–28):** "
                f"Aquesta setmana (dies 15–21) ha estat lenta (`{avg_5d_range_pts:.0f}p < 220p`). "
                f"La setmana vinent (del 22 al 28) entra en zona d'alerta (`35.3% WR`): vigila o descansa els comptes PA ajustats!"
            )
        else:
            week4_status = "PRE_OK_VOLATILE"
            week4_headline = (
                f"🟢 **PRE-AVÍS PER DILLUNS (ENTRADA A 4a SETMANA · Dies 22–28):** "
                f"Aquesta setmana (dies 15–21) ha tingut bona volatilitat (`{avg_5d_range_pts:.0f}p >= 220p`). "
                f"La setmana vinent (del 22 al 28) es podrà operar amb total normalitat!"
            )
    elif wom == 1:
        week4_status = "PRIME_WEEK_1"
        week4_headline = (
            f"🔥 **SETMANA 1 DEL MES (`Dies 1–7` · Fluxos + NFP · `66.2% WR`):** "
            f"Una de les dues millors setmanes del mes (`+696.5p` a 1s). Rang 5D actual: `{avg_5d_range_pts:.0f}p`."
        )
    elif wom == 3:
        week4_status = "PRIME_WEEK_3"
        week4_headline = (
            f"🏆 **SETMANA 3 DEL MES (`Dies 15–21` · Setmana OPEX · `64.2% WR`):** "
            f"La setmana més consistent dels 3 anys (`+870p` acumulat gràcies al Gamma Pinning). Rang 5D actual: `{avg_5d_range_pts:.0f}p`."
        )
    elif wom == 5:
        week4_status = "PRIME_WEEK_5"
        week4_headline = (
            f"🟢 **SETMANA 5 FINAL DE MES (`Dies 29–31` · Rebalanceig · `76.2% WR`):** "
            f"Finestra d'alta reversió de tancament mensual (`+334.5p` a 1s). Rang 5D actual: `{avg_5d_range_pts:.0f}p`."
        )
    else:
        week4_status = "NORMAL_WEEK_2"
        week4_headline = (
            f"🟢 **SETMANA 2 DEL MES (`Dies 8–14` · CPI/PPI · `52.3% WR`):** "
            f"Setmana d'operativa estàndard (`+360p` en 3 anys). Rang 5D actual: `{avg_5d_range_pts:.0f}p`."
        )

    # 2. Semàfor per Estrenar / Comprar Nous Comptes d'Avaluació (Timing d'Assalt)
    if is_hol:
        new_acc_status = "BLOCKED_HOLIDAY"
        new_acc_advice = f"🛑 **NO OPERAR NI OBRIR COMPTES AVUI:** Avui és festiu (`{hol_name}`)."
    elif dow == 2 and wom == 4:
        new_acc_status = "AVOID_BOTH"
        new_acc_advice = (
            f"🚫 **PROHIBIT ESTRENAR COMPTES NOUS AVUI ({dow_name} + Setmana 4):** "
            f"Avui coincideixen Dimecres (`51.9% WR`) i 4a Setmana (`46.8% WR`). "
            f"**Millors dies per estrenar comptes:** Dijous (`68.5% WR`), Divendres (`65.3% WR`) o Dimarts (`57.1% WR`) a les Setmanes 1 o 3."
        )
    elif dow == 2:
        new_acc_status = "AVOID_WEDNESDAY"
        new_acc_advice = (
            f"🚫 **NO ESTRENIS COMPTES NOUS AVUI (Dimecres · `51.9% WR`):** "
            f"Els dimecres són el dia més travat de la setmana (`29.7% BE`). "
            f"**Espera a demà Dijous (`68.5% WR`, `+607.5p`) o Divendres (`65.3% WR`, `+462.0p`)** per estrenar nous blocs d'Evaluations!"
        )
    elif wom == 4:
        new_acc_status = "AVOID_WEEK_4"
        new_acc_advice = (
            f"🚫 **NO ESTRENIS COMPTES NOUS EN SETMANA 4 (`Dies 22–28` · `46.8% WR`):** "
            f"Evita començar avaluacions noves a partir del dia 22 del mes. "
            f"**Guarda les compres per a l'inici de la Setmana 1 (`Dies 1–7`, `66.2% WR`) o Setmana 3 (`Dies 15–21`, `64.2% WR`)!**"
        )
    elif dow in (1, 3, 4) and wom in (1, 3, 5):
        wr_day = "68.5%" if dow == 3 else ("65.3%" if dow == 4 else "57.1%")
        new_acc_status = "OPTIMAL_DAY"
        new_acc_advice = (
            f"🔥 **DIA ÒPTIM PER ESTRENAR COMPTES NOUS ({dow_name} `{wr_day} WR` + Setmana {wom}):** "
            f"Estàs en un dels millors dies de la setmana i dins d'una setmana d'alta tracció. Finestra ideal per obrir nous blocs d'Evaluations!"
        )
    elif dow in (1, 3, 4):
        wr_day = "68.5%" if dow == 3 else ("65.3%" if dow == 4 else "57.1%")
        new_acc_status = "GOOD_DAY"
        new_acc_advice = (
            f"✅ **BON DIA PER ESTRENAR COMPTES NOUS ({dow_name} `{wr_day} WR`):** "
            f"Dimarts, Dijous i Divendres són els millors dies de la setmana (evita sempre els Dimecres i la Setmana 4 del dia 22 al 28)."
        )
    else:
        new_acc_status = "NEUTRAL_MONDAY"
        new_acc_advice = (
            f"ℹ️ **TIMING DE COMPTES NOUS (Dilluns `{dow_name}` · `56.7% WR`):** "
            f"Dia correcte en Setmana {wom}, tot i que els pics d'encert setmanal són **Dimarts (`57.1%`), Dijous (`68.5%`) i Divendres (`65.3%`)**. Recorda no estrenar mai comptes en Dimecres ni el dia 22."
        )

    # 3. Text del Radar de Festius de la Setmana
    if week_holidays:
        hol_lines = [f"• **`{h['day_name']} {h['date_str']}`** ➔ 🛑 **{h['name']}** *(NO OPERAR)*" for h in week_holidays]
        holidays_summary = "⚠️ **ATENCIÓ — DIES FESTIUS / NO OPERABLES AQUESTA SETMANA:**\n" + "\n".join(hol_lines)
    else:
        holidays_summary = "✅ **Calendari Festius USA d'aquesta setmana:** Cap dia festiu (5/5 sessions operables de Dilluns a Divendres)."

    # 4. Patró Històric i Arquetip Institucional d'Anys Anteriors (3A 1m + 2A 1s)
    historical_pattern = get_historical_day_pattern_insight(target_date, avg_5d_range_pts=avg_5d_range_pts)

    return {
        "date": target_date.isoformat(),
        "date_str": target_date.strftime("%d/%m/%Y"),
        "day_name": dow_name,
        "day_of_month": dom,
        "week_of_month": wom,
        "avg_5d_range_pts": avg_5d_range_pts,
        "is_slow_regime": is_slow,
        "is_holiday_today": is_hol,
        "holiday_name_today": hol_name,
        "week_holidays": week_holidays,
        "holidays_summary": holidays_summary,
        "week4_status": week4_status,
        "week4_headline": week4_headline,
        "new_account_status": new_acc_status,
        "new_account_advice": new_acc_advice,
        "historical_pattern": historical_pattern,
    }


def get_day_trading_status(target_date: Optional[datetime.date] = None) -> Dict[str, Any]:
    if target_date is None:
        target_date = datetime.date.today()

    date_str = target_date.strftime("%d/%m/%Y")
    is_weekend = target_date.weekday() >= 5

    if is_weekend:
        day_name = "Dissabte" if target_date.weekday() == 5 else "Diumenge"
        return {
            "date": target_date,
            "date_str": date_str,
            "status": "NOT_OPERABLE",
            "can_trade": False,
            "severity": "GRAY",
            "color_name": "danger",
            "badge": "🔴 MERCAT TANCAT (CAP DE SETMANA)",
            "title": f"MERCAT TANCAT — {day_name} {date_str}",
            "headline": f"Mercat CME Globex tancat ({day_name}).",
            "instructions": "Cap de setmana. El mercat romandrà tancat fins diumenge a la nit.",
            "time_window": "Mercat tancat",
            "event": None,
            "is_weekend": True,
            "is_holiday": False
        }

    event = get_macro_event_for_date(target_date)
    if event and event.get("severity") == "GRAY":
        event_name = event.get("name", "Festiu CME")
        return {
            "date": target_date,
            "date_str": date_str,
            "status": "NOT_OPERABLE",
            "can_trade": False,
            "severity": "GRAY",
            "color_name": "danger",
            "badge": f"🔴 FESTIU CME ({event_name})",
            "title": f"FESTIU DE MERCAT — {date_str}",
            "headline": f"{event_name}",
            "instructions": event.get("instructions", "No operar en dia festiu."),
            "time_window": "Sense operativa",
            "event": event,
            "is_weekend": False,
            "is_holiday": True
        }

    if event:
        event_name = event.get("name", "Esdeveniment Macro")
        time_str = event.get("time_cest", "")
        return {
            "date": target_date,
            "date_str": date_str,
            "status": "OPERABLE",
            "can_trade": True,
            "severity": event.get("severity", "AMBER"),
            "color_name": "warning",
            "badge": f"🟡 OPERABLE AMB ATENCIÓ ({event.get('type')})",
            "title": f"LAYER SNIPER 10AM — {date_str}",
            "headline": f"{event_name} ({time_str})",
            "instructions": event.get("instructions", "Respectar la finestra 10:00-10:59 NY i l'escut de notícies."),
            "time_window": "10:00 a 10:59 NY (16:00 a 16:59 CET)",
            "event": event,
            "is_weekend": False,
            "is_holiday": False
        }

    return {
        "date": target_date,
        "date_str": date_str,
        "status": "OPERABLE",
        "can_trade": True,
        "severity": "GREEN",
        "color_name": "success",
        "badge": "🟢 OPERAR (LLUM VERDA)",
        "title": f"LAYER SNIPER 10AM — {date_str}",
        "headline": "Sessió neta per a l'estratègia JJ Fair Pricing (Layer Sniper).",
        "instructions": "Àncora a les 09:30 NY. Executar 🔷 LAYER entre 10:00 i 10:59 NY amb +30p/-30p i BE en TP1.",
        "time_window": "10:00 a 10:59 NY (16:00 a 16:59 CET)",
        "event": None,
        "is_weekend": False,
        "is_holiday": False
    }
