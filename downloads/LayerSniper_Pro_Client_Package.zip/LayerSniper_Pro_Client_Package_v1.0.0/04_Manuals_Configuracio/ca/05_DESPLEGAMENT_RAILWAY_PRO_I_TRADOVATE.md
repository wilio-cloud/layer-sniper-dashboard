# 05 · Desplegament del Servidor Railway Pro i Connexió Tradovate API (Opcional)

Aquest manual és només per als usuaris que escullin la **Modalitat C (Mode Complet Pro)**: disposar d'un servidor núvol propi 24/7 a **Railway** amb **Tauler de Control Web (HUD)**, *Kill-Switch* des del mòbil, *Escut de Notícies Red Folder USD*, notificacions a Discord/Telegram i/o execució directa OSO contra l'API REST de Tradovate.

*(Si utilitzes el Mode Directe cap al VPS descrit al Manual `04`, no necessites desplegar Railway).*

---

## 1. Preparació i Desplegament a Railway (5 Minuts)

1. Crea un compte a https://railway.app (el pla *Hobby* de ~5 USD/mes manté el contenidor encès les 24h sense adormir-se).
2. Tens dues maneres de pujar la carpeta **`03_Servidor_Railway_Pro`**:
   - **Via GitHub Privat (Recomanat):** Crea un repositori **Privat** al teu compte de GitHub i puja-hi tot el contingut de dins de `03_Servidor_Railway_Pro/` (`Procfile`, `railway.json`, `requirements.txt`, `bot/`, `dashboard/`, `replikanto/`). A Railway clica **`New Project -> Deploy from GitHub repo`** i selecciona aquest repositori privat.
   - **Via Railway CLI (Sense GitHub):** Des del terminal situat dins de `03_Servidor_Railway_Pro/`, executa `railway init` i després `railway up`.
3. **Generar el Domini Públic HTTPS:**
   - Dins del servei a Railway, ves a la pestanya **`Settings -> Networking -> Public Networking`**.
   - Clica a **`Generate Domain`**.
   - Obtindràs una URL HTTPS pròpia del tipus:
     `https://<el-teu-servei>.up.railway.app`

---

## 2. Configuració de Variables d'Entorn (`Variables` a Railway)

Ves a la pestanya **`Variables`** del teu servei a Railway (pots usar el botó **`RAW Editor`** i copiar la plantilla `03_Servidor_Railway_Pro/.env.example`):

### 2.1 Variables Obligatòries (Seguretat i HUD)
```env
WEBHOOK_SECRET=posa_aqui_un_token_secret_llarg_i_unic
DASHBOARD_USER=admin
DASHBOARD_PASS=posa_aqui_una_contrasenya_forta!
```
- **`WEBHOOK_SECRET`**: És la mateixa clau que enganxaràs al camp `Webhook Secret Token` de l'estratègia **`Layer Sniper Pro`** a TradingView.
- **`DASHBOARD_USER` / `DASHBOARD_PASS`**: Protegeixen amb autenticació l'entrada al teu panell web `https://<el-teu-servei>.up.railway.app/`.

### 2.2 Connexió amb el Bridge de NinjaTrader 8 al teu VPS Windows
1. Al teu VPS Windows, executa `02_Bridge_VPS_Windows\INSTALAR_BRIDGE_VPS.bat` i selecciona l'opció **`[3] MODE SERVIDOR RAILWAY PRO`**.
2. Obre `C:\LayerSniper\DADES_CONNEXIO_TRADINGVIEW.txt` al VPS per veure la IP pública del teu VPS i el token generat pel Bridge (`ls_...`), i afegeix a Railway:
```env
FORWARD_WEBHOOK_URL=http://<IP_PUBLICA_DEL_TEU_VPS>:8090/webhook
FORWARD_WEBHOOK_SECRET=<token_ls_del_fitxer_del_VPS>
NT8_BOT_ACCOUNT=Sim101
```
*(Si només operes a través de NinjaTrader 8 + Replikanto i NO connectes cap compte per API directa de Tradovate, deixa `TRADOVATE_DIRECT_ENABLED=false`).*

### 2.3 Connexió Directa Opcional a Tradovate REST API (Ordres OSO sense NinjaTrader)
Si tens un compte Live a Tradovate amb accés API activat i vols que Railway col·loqui ordres OSO natives directament a CME Globex:
```env
TRADOVATE_DIRECT_ENABLED=true
ACCOUNT_ROLE=live
TRADOVATE_ENV=live
TRADOVATE_USER=el_teu_usuari_tradovate
TRADOVATE_PASS=la_teva_contrasenya_tradovate
TRADOVATE_CID=el_teu_cid_api
TRADOVATE_SEC=el_teu_secret_api
TRADOVATE_ACCOUNT_SPEC=nom_del_compte_opcional
```
*(Per provar-ho primer en Demo de Tradovate, posa `TRADOVATE_ENV=demo`).*

### 2.4 Notificacions Opcionals a Discord o Telegram
```env
DISCORD_WEBHOOK_URL=https://discord.com/api/webhooks/...
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
```

Un cop desades les variables, Railway reiniciarà automàticament el contenidor en ~20 segons.

---

## 3. Verificació del Servidor i Configuració de l'Alerta a TradingView

1. **Comprovació d'estat (`/health`):**
   Obre al navegador:
   `https://<el-teu-servei>.up.railway.app/health`
   Has de veure una resposta JSON amb `"status": "healthy"`.
2. **Accés al Tauler de Control (HUD):**
   Obre `https://<el-teu-servei>.up.railway.app/` i introdueix el teu `DASHBOARD_USER` i `DASHBOARD_PASS`.
   - Des d'aquí pots supervisar el rellotge NY/BCN, l'estat del Relay cap al VPS, forçar el moviment d'Stop Loss a Breakeven, activar el Cadenat 15:00h o disparar el **KILL-SWITCH** d'emergència des del mòbil.
3. **URL de Webhook a TradingView:**
   Quan creïs l'alerta a TradingView (seguint el Manual `02` amb **`Order fills and alert() function calls`** i `{{strategy.order.alert_message}}` a *Message*), posa com a **Webhook URL**:
   ```text
   https://<el-teu-servei>.up.railway.app/api/webhook/tradingview
   ```
