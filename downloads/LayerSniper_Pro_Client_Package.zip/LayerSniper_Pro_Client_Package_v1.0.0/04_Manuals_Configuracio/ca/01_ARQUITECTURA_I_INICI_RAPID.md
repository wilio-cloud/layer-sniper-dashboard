# 01 · Arquitectura del Sistema i Guia d'Inici Ràpid

Aquest document resumeix els requisits tècnics i el funcionament de les tres arquitectures d'execució incloses a **Layer Sniper Pro**.

---

## 1. Requisits Tècnics Previs

Abans de començar la instal·lació, comprova aquests quatre punts:

1. **TradingView:**
   - **Accés a l'Estratègia:** Has de tenir activat el teu nom d'usuari de TradingView per veure **`Layer Sniper Pro`** dins de la pestanya *Indicators -> Invite-only scripts*.
   - **Subscripció de Dades CME en Temps Real (Obligatori):** Els futurs del Nasdaq (`MNQ1!`) a TradingView tenen **10 minuts de retard** per defecte si no es té el paquet de dades *CME Group (E-mini / Micro)* activat (~7 USD/mes). Sense dades en temps real, els senyals sortirien amb 10 minuts de retard.
   - **Pla amb Webhooks (Només per a Mode Automàtic):** TradingView requereix un pla **Essential, Plus o Premium** per activar la casella *Webhook URL* a les alertes. Si només operes en Mode Manual (`Sim102`), qualsevol pla amb alertes Push et serveix.
2. **Entorn Windows 10/11 o VPS Dedicat (ex: ChartVPS / Windows Server):**
   - Recomanat tenir un VPS Windows amb latència baixa cap a Chicago (CME) encès durant la sessió de Nova York (`09:30 – 12:30 NY`) perquè NinjaTrader 8 no depengui de la connexió domèstica.
   - Assegura't que el rellotge de Windows tingui activada la sincronització automàtica d'hora (*Set time automatically = ON*).
3. **NinjaTrader 8 (Versió 8.1+):**
   - Instal·lat i connectat a les credencials dels teus comptes (Rithmic, Tradovate / NinjaTrader Brokerage, ProjectX compatibles, etc.).
4. **Copiador d'Ordres (Si repliques a múltiples comptes):**
   - **Flowbots Replikanto — Compliance Edition** instal·lat com a Add-On a NinjaTrader 8.

---

## 2. Comparativa de les 3 Arquitectures Disponibles

### Opció A — Mode Manual / Híbrid 1-Clic (`Sim102`)
- **Flux:** `TradingView (Avís visual / Push) -> Clic humà a Sim102 (Chart Trader) -> Replikanto -> Comptes Followers`
- **Com funciona:**
  - Selecciones al Chart Trader una de les 4 plantilles ATM incloses (`LS_50K_10MNQ_30TP_30SL`, `5MNQ`, `3MNQ` o `30MNQ`). L'AddOn C# ajusta sol la casella de quantitat (*Order qty*) i col·loca automàticament els brackets de `+30p TP` i `-30p SL` (`120 ticks`).
  - Quan l'estratègia avisa que el *PRIMARY* ha tocat `TP 1`, prems el botó verd **`[🛡️ BE +2t (+0.50p)]`** integrat al Chart Trader i l'Stop Loss puja/baixa sol al teu preu real d'entrada `+2 ticks` en tots els comptes copiats.
- **Avantatge clau:** Compliment 100% amb empreses que prohibeixen bots o automatismes API/ATI (*Apex PA, Take Profit Trader, Topstep, Tradeify*).

### Opció B — Mode Directe Automàtic VPS (`TradingView -> VPS Windows -> Sim101`)
- **Flux:** `TradingView Webhook -> VPS Windows (layersniper_nt8_bridge.py) -> NinjaTrader 8 ATI (Sim101) -> Replikanto`
- **Com funciona:**
  - Sense necessitat de Railway ni serveis externs de pagament.
  - TradingView només envia webhooks als ports **`80` (HTTP)** o **`443` (HTTPS)** des de **4 adreces IP estàtiques oficials** (`52.89.214.238`, `34.212.75.30`, `54.218.53.128`, `52.32.178.7`).
  - L'assistent `INSTALAR_BRIDGE_VPS.bat` et permet escollir entre:
    1. **Port `80` Directe amb Firewall Blindat:** Obre el port `80` del VPS acceptant *exclusivament* peticions d'aquestes 4 IPs de TradingView + validació de `Webhook Secret Token`.
    2. **Túnel HTTPS Cloudflare (`443` -> `localhost:8090`):** Crea un túnel xifrat gratuït sense obrir cap port d'entrada al VPS (ideal si el port `80` ja està ocupat o el teu proveïdor bloqueja el port `80`).
- **Avantatge clau:** Latència mínima (`< 25 ms` al VPS), cost mensual d'infraestructura extra zero i lectura del *fill* real a `outgoing\` per calcular el Breakeven exacte incloent el *slippage*.

### Opció C — Mode Complet Pro (`TradingView -> Servidor Railway -> Tradovate API + VPS Sim101`)
- **Flux:** `TradingView Webhook -> Railway HTTPS (:443) -> [Tradovate REST API OSO] + [Relay cap al VPS :8090]`
- **Com funciona:**
  - Desplegues la carpeta `03_Servidor_Railway_Pro` al teu propi compte de Railway (~5 USD/mes).
  - Disposes d'un **Tauler de Control Web (HUD)** protegit amb contrasenya des del mòbil o PC (amb botó de *Kill-Switch*, *Moure SL a BE*, *Cadenat Anti-Tilt 15:00h*, *Escut automàtic de Notícies Red Folder USD* i notificacions riques a Discord/Telegram).
  - Permet executar directament sobre un compte Live/API de Tradovate (ordres OSO natives) i, alhora, reenviar el senyal al Bridge del teu VPS (`FORWARD_WEBHOOK_URL`).

---

## 3. Checklist d'Instal·lació en 15 Minuts

- [ ] **Pas 1 (NinjaTrader 8 — 3 min):** Executar `01_Kit_NinjaTrader8_i_Replikanto\INSTALAR_KIT_NT8.bat`, obrir `New -> NinjaScript Editor` i prémer **`F5`** per compilar els botons. *(Manual `03`)*
- [ ] **Pas 2 (Comptes i Replikanto — 4 min):** Activar *Automated Trading Interface (ATI)* a NinjaTrader 8, verificar els comptes `Sim101` (Bot) i/o `Sim102` (Manual) i configurar les ràtios a Replikanto amb *Follower ATM = OFF*. *(Manual `03`)*
- [ ] **Pas 3 (Bridge o Railway — 4 min):**
  - Si vas directe al VPS: executar `02_Bridge_VPS_Windows\INSTALAR_BRIDGE_VPS.bat` i anotar la URL i el `Webhook Secret Token` desats a `C:\LayerSniper\DADES_CONNEXIO_TRADINGVIEW.txt`. *(Manual `04`)*
  - Si uses Railway Pro: desplegar `03_Servidor_Railway_Pro`, configurar les variables `.env` i connectar el VPS en Mode `[3]`. *(Manual `05`)*
- [ ] **Pas 4 (TradingView — 4 min):** Obrir `MNQ1!` en temporalitat **`1m`** (espelmes normals), afegir l'estratègia *Invite-Only* **`Layer Sniper Pro`**, enganxar el `Webhook Secret Token` i crear **1 sola alerta** amb **`Order fills and alert() function calls`** i el missatge **`{{strategy.order.alert_message}}`**. *(Manual `02`)*
