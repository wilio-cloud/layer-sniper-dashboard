# 03 · Configuració de NinjaTrader 8 i Replikanto (Automàtic `Sim101` + Manual `Sim102`)

Aquest manual explica com deixar preparat **NinjaTrader 8** i **Replikanto** tant per a l'execució automàtica via Bridge ATI (`Sim101`) com per a l'execució manual d'1 clic (`Sim102`).

---

## 1. Instal·lació amb 1 Clic de Plantilles ATM i Botons C# (`[BE +2t]` i `[FLAT]`)

1. Al teu PC o VPS Windows on tinguis instal·lat NinjaTrader 8, entra a la carpeta del paquet:
   `01_Kit_NinjaTrader8_i_Replikanto`
2. Fes doble clic sobre **`INSTALAR_KIT_NT8.bat`**.
   - L'instal·lador detecta sol la teva carpeta `Documents\NinjaTrader 8` (fins i tot si utilitzes OneDrive o Windows en espanyol/anglès) i hi copia de forma 100% offline:
     - **4 Plantilles ATM** (`120 ticks` TP = `+30.0p` / `120 ticks` SL = `-30.0p`):
       - `LS_50K_10MNQ_30TP_30SL` (`10 MNQ`)
       - `LS_50K_5MNQ_30TP_30SL` (`5 MNQ`)
       - `LS_50K_3MNQ_30TP_30SL` (`3 MNQ`)
       - `LS_150K_30MNQ_30TP_30SL` (`30 MNQ`)
     - **AddOn de Chart Trader (`LayerSniperChartTraderAddOn.cs`):** Afegeix automàticament els botons **`[🛡️ BE +2t (+0.50p)]`** i **`[🛑 FLAT]`** a tots els gràfics i sincronitza sola la casella *Order qty* quan canvies de plantilla ATM.
     - **Indicador Alternatiu (`LayerSniperManualBEButton.cs`):** Botó opcional per si prefereixes carregar-lo només en un gràfic concret.
3. **Compilació (10 segons dins de NinjaTrader 8):**
   - Al menú principal (*Control Center*) de NinjaTrader 8, ves a **`New -> NinjaScript Editor`**.
   - Prem la tecla **`F5`** (o la icona taronja *Compile* de la barra superior) i espera 3 segons fins que s'escolti la campaneta de confirmació sense cap avís a la part inferior.
   - Tanca el *NinjaScript Editor*. Ja ho tens compilat per sempre.

---

## 2. Activació de la Interfície ATI i Creació dels Comptes Líders (`Sim101` / `Sim102`)

### 2.1 Activar l'Automated Trading Interface (Obligatori per al Mode Automàtic)
1. Al *Control Center* de NinjaTrader 8, ves a **`Tools -> Options`**.
2. A la llista de l'esquerra, selecciona **`Automated Trading Interface`**.
3. Marca la casella **`AT Interface`** (activada / `Checked`).
4. Prem **OK**.
   - *Això permet que NinjaTrader 8 llegeixi instantàniament els fitxers d'ordres que el Bridge Python escriu a `Documents\NinjaTrader 8\incoming\` i exporti el preu real d'execució a `outgoing\`.*

### 2.2 Separació de Comptes Líders (Arquitectura de Seguretat Compliance)
Per defecte, NinjaTrader 8 ja inclou el compte de simulació **`Sim101`**. Si operes tant empreses que permeten automatisme com empreses que exigeixen clic manual, crea també **`Sim102`**:

1. Al *Control Center*, ves a la pestanya **`Accounts`**.
2. Fes clic dret sobre la llista de comptes -> **`Add Simulation Account...`**.
3. A *Account name*, escriu exactament **`Sim102`** i prem **OK** *(si et demana reiniciar NinjaTrader 8 perquè aparegui `Sim102`, reinicia'l ara)*.

| Compte Líder | Funció Exclusiva | Com s'opera? |
| :--- | :--- | :--- |
| **`Sim101`** | **Líder Automàtic Bot (ATI)** | **No el toquis amb el ratolí.** Rep automàticament les ordres `PLACE` (amb brackets OCO) i el `CHANGE` de Breakeven des del Bridge Python. |
| **`Sim102`** | **Líder Manual 1-Clic** | **100% clic humà** des del Chart Trader amb plantilla ATM `LS_*` + clic al botó `[🛡️ BE +2t (+0.50p)]`. El Bridge Python té `Sim102` bloquejat per codi (`HTTP 403`) perquè cap bot hi pugui enviar mai una ordre. |

---

## 3. Configuració Exacta de Replikanto (Compliance Edition)

1. Instal·la **Flowbots Replikanto — Compliance Edition** des de `Tools -> Import -> NinjaScript Add-On...` (seleccionant el `.zip` oficial de la teva llicència Flowbots) i reinicia NinjaTrader 8 si cal.
2. Obre una finestra de Replikanto des de **`New -> Replikanto`**.
3. **Configuració dels paràmetres clau de la finestra de Replikanto:**
   - **Instrument:** Selecciona el contracte trimestral vigent d'MNQ a NinjaTrader 8 (ex: **`MNQ 12-26`**, `MNQ 03-27`, etc.).
     - *⚠️ Nota de Rollover:* Recorda actualitzar aquest contracte cada trimestre (2n divendres de març, juny, setembre i desembre) perquè coincideixi amb el contracte actiu que resol automàticament el Bridge.
   - **Leader Account:**
     - Selecciona **`Sim101`** a la finestra de Replikanto per als comptes automàtics.
     - *(Si també tens comptes manuals, obre una segona finestra o pestanya `+` de Replikanto i posa **`Sim102`** com a Leader Account).*
   - **Copy Mode (Mètode d'escalat):** Selecciona **`Ratio`** (clicant el menú de 3 punts `⋮` a dalt a la dreta de Replikanto).
   - **ATM Strategy (als Followers):** Deixa-ho en **`OFF` / Desmarcat**.
     - *Per què?* Tant el Bridge ATI (a `Sim101`) com les plantilles ATM del Chart Trader (a `Sim102`) ja col·loquen al compte Líder l'entrada + el Take Profit Limit (`+30p`) + l'Stop Loss (`-30p`). Amb *Follower ATM = OFF*, Replikanto replica l'entrada, els dos brackets i el moviment posterior de l'Stop Loss a Breakeven (`+0.50p`) a tots els Followers de manera sincronitzada!
   - **Cross Order:** **`OFF`** (desactivat; operem sempre `MNQ -> MNQ`).
   - **Follower Guard:** **`ON`** (activat; si algun follower pateix un rebuig puntual del broker, aplana i protegeix aquell follower per no deixar-lo desprotegit).

### Taula d'Exemples de Ràtios (quan el Líder `Sim101` envia `10 MNQ`):

| Mida / Tipus del Compte Follower | Contractes Desitjats al Follower | Ràtio a posar a Replikanto |
| :--- | :---: | :---: |
| Compte 50K Estàndard (`10 MNQ`) | `10 MNQ` | **`1.0`** |
| Compte 50K Consolidació (`5 MNQ`) | `5 MNQ` | **`0.5`** |
| Compte 50K Defensiu (`3 MNQ`) | `3 MNQ` | **`0.3`** |
| Compte 150K Escalat 3x (`30 MNQ`) | `30 MNQ` | **`3.0`** |

*(Pots consultar també el fitxer de referència `01_Kit_NinjaTrader8_i_Replikanto/replikanto_config_template.json`).*

4. Marca la casella d'activació (**Check verd / ON**) a l'esquerra de cada compte Follower que vulguis copiar avui i verifica que l'interruptor principal del Leader estigui en **ON (Verd)**.

---

## 4. Com Operar en Mode Manual 1-Clic sobre `Sim102` (Chart Trader)

Si operes comptes amb obligació de clic manual a través de `Sim102`:

1. Obre un gràfic a NinjaTrader 8 (`New -> Chart -> Instrument: MNQ <trimestre actual>`, `1 Minute`).
2. Activa el **Chart Trader** a la barra superior del gràfic (icona *Chart Trader*).
3. Al Chart Trader (columna dreta):
   - **Account:** Selecciona **`Sim102`**.
   - **ATM Strategy:** Desplega i selecciona per exemple **`LS_50K_5MNQ_30TP_30SL`** o **`LS_50K_10MNQ_30TP_30SL`**. Veuràs que la casella **`Order qty`** canvia automàticament a `5` o `10` sense haver de teclejar res.
   - A sota dels botons d'ordres veuràs la barra integrada amb dos botons grans:
     - **`[🛡️ BE +2t (+0.50p)]`**
     - **`[🛑 FLAT]`**
4. **Execució durant la sessió:**
   - **Entrada:** Quan tanqui l'espelma confirmada amb senyal `LAYER BUY` o `LAYER SELL`, prem **`Buy Mkt`** o **`Sell Mkt`**. Es col·locaran a l'instant l'entrada, el TP (`+30p`) i l'SL (`-30p`) a `Sim102` i a tots els Followers de la pestanya de `Sim102`.
   - **Escut Breakeven:** Quan el preu arribi al nivell `TP 1` de l'explorador (avís visual i sonor a TradingView), fes **1 sol clic** a **`[🛡️ BE +2t (+0.50p)]`**. L'AddOn llegirà el preu mitjà real del teu *fill* i mourà l'Stop Loss a `Entrada + 0.50p` (en Long) o `Entrada - 0.50p` (en Short) en tots els comptes copiats.
   - **Tancament d'emergència o fi de sessió:** Un clic a **`[🛑 FLAT]`** cancel·la ordres pendents i tanca la posició a mercat.
