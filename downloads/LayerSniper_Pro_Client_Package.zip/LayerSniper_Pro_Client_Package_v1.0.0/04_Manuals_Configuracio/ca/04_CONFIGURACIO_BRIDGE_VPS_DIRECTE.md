# 04 · Configuració del Bridge al VPS Windows (Mode Directe sense Railway)

Aquest manual explica com instal·lar i operar el motor **`layersniper_nt8_bridge.py`** al teu VPS Windows (ex: *ChartVPS*, *ServerMania*, *Contabo*, *AWS EC2*) per rebre directament els Webhooks de TradingView i executar-los a NinjaTrader 8 (`Sim101`) sense necessitat de crear cap servidor extern a Railway.

---

## 1. Com es Connecta TradingView amb el teu VPS?

Per normativa tècnica de TradingView:
1. Els Webhooks de TradingView **només envien peticions als ports `80` (HTTP) o `443` (HTTPS)** (no admeten ports personalitzats com `:8090` directament des de TradingView).
2. Totes les alertes de TradingView surten exclusivament des de **4 adreces IPv4 estàtiques oficials**:
   - `52.89.214.238`
   - `34.212.75.30`
   - `54.218.53.128`
   - `52.32.178.7`

Per això, l'instal·lador inclou **dues opcions directes llestes per triar**:
- **Mode `[1]` — Directe Port `80` amb Firewall Blindat (Recomanat en VPS dedicats tipus ChartVPS):** El Bridge escolta al port `80` i tant el Windows Defender Firewall com el propi codi Python rebutgen qualsevol connexió d'internet que no vingui d'una d'aquestes 4 IPs oficials de TradingView + validació de `Webhook Secret Token`. URL resultant: `http://<IP_DEL_VPS>/webhook`.
- **Mode `[2]` — Directe via Túnel HTTPS Cloudflare (`443` -> `localhost:8090`):** El Bridge escolta únicament en local (`8090`) sense obrir cap port d'entrada al VPS, i `INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat` aixeca un túnel xifrat HTTPS al port `443`. Ideal si el port `80` del VPS ja està ocupat o el proveïdor de núvol tanca ports entrants.

---

## 2. Instal·lació Pas a Pas en 2 Minuts

1. Copia i descomprimeix el paquet dins del teu VPS Windows (per exemple a l'Escriptori).
2. Entra a la carpeta **`02_Bridge_VPS_Windows`**.
3. Fes doble clic sobre **`INSTALAR_BRIDGE_VPS.bat`** i accepta el permís d'Administrador (*Sí* a la finestra UAC de Windows).
4. Quan aparegui el menú interactiu a la consola blava/negra:
   - Escriu **`1`** i prem **Enter** per al **Mode Directe Port 80** *(o escriu **`2`** si prefereixes usar el Túnel HTTPS de Cloudflare)*.
5. L'instal·lador executarà automàticament els 5 passos:
   - Comprovarà si tens **Python 3** instal·lat; si no hi és, descarregarà i instal·larà silenciosament Python 3.11.9 oficial.
   - Copiarà de forma offline les 4 plantilles ATM i l'AddOn C# a la teva carpeta `NinjaTrader 8`.
   - Instal·larà el Bridge a **`C:\LayerSniper\layersniper_nt8_bridge.py`**.
   - Generarà una clau criptogràfica única **`ls_...`** (`webhook_secret`) exclusiva per a la teva instal·lació dins de `C:\LayerSniper\bridge_config.json`.
   - Configurarà el Windows Firewall, crearà l'accés directe **`Iniciar LayerSniper Bridge.bat`** al teu Escriptori i obrirà la finestra activa del Bridge.

---

## 3. On Trobar la teva URL i el teu Token per a TradingView

En acabar la instal·lació, es mostra per pantalla i es desa automàticament el fitxer:
👉 **`C:\LayerSniper\DADES_CONNEXIO_TRADINGVIEW.txt`**

Obre'l amb el Bloc de notes:
1. Copia el **`WEBHOOK SECRET TOKEN`** (ex: `ls_4f9c2a...`) i enganxa'l al camp `Webhook Secret Token` de la configuració ⚙️ de l'estratègia **`Layer Sniper Pro`** a TradingView.
2. Copia la **`WEBHOOK URL`**:
   - Si has triat **Mode `[1]`**: tindrà el format `http://203.0.113.45/webhook` *(enganxa-la tal qual a la pestanya Notifications de l'alerta de TradingView)*.
   - Si has triat **Mode `[2]`**: fes doble clic a `C:\LayerSniper\INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat`. En 5 segons veuràs a la consola una línia amb `https://xxxx-xxxx.trycloudflare.com`. Afegeix `/webhook` al final (`https://xxxx-xxxx.trycloudflare.com/webhook`) i enganxa-la a l'alerta de TradingView. *(Nota: en túnels gratuïts Quick Tunnel, si tanques la finestra del túnel o reinicies el VPS, Cloudflare assignarà un subdomini nou i caldrà actualitzar la URL de l'alerta).*

---

## 4. Com Verificar que Tot Funciona Abans d'Operar (`PROVAR_CONNEXIO_LOCAL.bat`)

Amb **NinjaTrader 8 obert** (i `Tools -> Options -> Automated Trading Interface` activat):

1. Ves a **`C:\LayerSniper`** (o a `02_Bridge_VPS_Windows`) i fes doble clic a **`PROVAR_CONNEXIO_LOCAL.bat`**.
2. L'script comprovarà primer l'estat `/health` del Bridge i et mostrarà:
   - Que el servei respon `"status": "healthy"`.
   - Que el compte automàtic actiu és `Sim101` i que `Sim102` està bloquejat per Compliance.
   - Quin contracte trimestral d'MNQ ha detectat automàticament (ex: `MNQ 12-26`).
3. A continuació et preguntarà:
   `Vols enviar una ordre de PROVA (1 MNQ BUY + TP/SL i Flatten a Sim101)? (S/N)`
   - **Important:** Abans d'escriure **`S`**, assegura't que tens Replikanto temporalment desconnectat o bé sense comptes reals marcats si el mercat està obert!
   - Escriu **`S`** i prem **Enter**:
     1. Veuràs entrar a l'instant a NinjaTrader 8 (`Sim101`) una compra d'`1 MNQ` amb els seus dos brackets OCO (`+30p` Limit i `-30p` Stop).
     2. Al cap de 3 segons, el test tancarà automàticament la posició de prova (`CLOSEPOSITION`) deixant `Sim101` completament pla (`Flat`).

Si veus l'ordre entrar i tancar-se sola a la pestanya *Orders / Executions* de NinjaTrader 8, la connexió Bridge <-> NinjaTrader 8 està **100% verificada**.

---

## 5. Operativa Diària i Resolució de Problemes Freqüents

### Rutina abans de les 09:30 NY
1. Comprova al VPS que **NinjaTrader 8** estigui obert i amb els comptes connectats (llum verda a baix a l'esquerra).
2. Comprova que la finestra negra **`Layer Sniper Pro - NT8 ATI Bridge`** estigui oberta (si s'hagués reiniciat el VPS per manteniment de Windows, fes doble clic a **`Iniciar LayerSniper Bridge.bat`** a l'Escriptori).
3. A Replikanto, revisa que `Sim101` tingui l'interruptor verd activat amb els Followers desitjats.

### Preguntes Freqüents / Troubleshooting
- **Error `PermissionError` o "Port 80 ja està ocupat" en Mode `[1]`:**
  - Alguns Windows Server porten activat de fàbrica el servidor web buit *IIS (`World Wide Web Publishing Service / W3SVC`)* o el driver `HTTP.sys` escoltant al port `80`.
  - **Solució ràpida A:** Obre PowerShell com a Administrador i executa:
    ```powershell
    Stop-Service W3SVC -Force; Set-Service W3SVC -StartupType Disabled
    ```
    I torna a obrir `Iniciar LayerSniper Bridge.bat`.
  - **Solució ràpida B:** Sense tocar cap servei de Windows, executa `INSTALAR_BRIDGE_VPS.bat`, selecciona el **Mode `[2]` (Túnel HTTPS Cloudflare)** i inicia `INICIAR_TUNEL_HTTPS_CLOUDFLARE.bat`.
- **El test local funciona (`PROVAR_CONNEXIO_LOCAL.bat`), però l'alerta de TradingView no arriba al Mode `[1]`:**
  - Alguns proveïdors de núvol (AWS EC2, Google Cloud, Oracle, Azure, Hetzner Cloud) tenen un segon panell web extern anomenat *Security Group / Cloud Firewall* davant del VPS. Obre al panell web del teu proveïdor el port **TCP `80`** per a les 4 IPs de TradingView (`52.89.214.238/32`, `34.212.75.30/32`, `54.218.53.128/32`, `52.32.178.7/32`) — o utilitza directament el **Mode `[2]` (Túnel HTTPS Cloudflare)** que travessa qualsevol tallafocs sense configurar res al proveïdor. *(A ChartVPS no hi ha panell extern bloquejant i el Mode `[1]` funciona directament).*
- **El Bridge escriu el fitxer a `incoming\`, però NinjaTrader 8 no executa l'ordre:**
  - Revisa `Tools -> Options -> Automated Trading Interface` i confirma que **`AT Interface`** està marcat.
  - Revisa a la pestanya *Log* del Control Center de NinjaTrader 8 si l'instrument trimestral (ex: `MNQ 12-26`) està descarregat a `Tools -> Instruments`.
