# 🎯 Layer Sniper Pro — Paquet d'Instal·lació i Configuració (v1.0)

> **💡 RECOMANAT (MOLT MÉS FÀCIL):**  
> Fes **doble clic a l'arxiu `OBRIR_GUIA_INTERACTIVA.html`** situat en aquesta mateixa carpeta per obrir al navegador el **Dashboard Visual Interactiu** (amb selector de modalitat, checkboxes de progrés i calculadora de ràtios Replikanto).

Benvingut al paquet tècnic d'execució de **Layer Sniper Pro** per a **TradingView + NinjaTrader 8 + Replikanto** (i opcionalment **Railway + Tradovate API**).

Aquest paquet conté tots els instal·ladors offline, el motor Bridge per a Windows/VPS i els manuals pas a pas per deixar el sistema operatiu en menys de **15 minuts**.

---

## 🧭 Pas 1: Tria la teva Modalitat d'Execució (2 minuts)

Segons les regles de les empreses de fondeig (*Prop Firms*) o comptes propis que operis, pots utilitzar una o diverses d'aquestes tres modalitats simultàniament:

| Modalitat | Quan utilitzar-la? | Carpetes que necessites |
| :--- | :--- | :--- |
| **A. Mode Manual 1-Clic (`Sim102`)** | Comptes amb prohibició de bots i obligació de clic humà (ex: *Apex PA, Take Profit Trader, Topstep, Tradeify*). | `01_Kit_NinjaTrader8_i_Replikanto` + Manuals `02` i `03` |
| **B. Mode Directe Automàtic VPS (`Sim101`)** | Voler automatitzar 100% des de TradingView cap al teu VPS Windows amb NinjaTrader 8 + Replikanto **sense crear servidor a Railway**. | `01_Kit...` + `02_Bridge_VPS_Windows` + Manuals `02`, `03` i `04` |
| **C. Mode Complet Pro (Railway + VPS / Tradovate)** | Voler tauler de control web (HUD), escut de notícies centralitzat, alertes Discord/Telegram i/o connexió directa OSO a l'API de Tradovate. | Totes (`01`, `02` i `03_Servidor_Railway_Pro`) + Manuals `01` a `05` |

> **Nota sobre Operativa Híbrida (`Sim101` + `Sim102` alhora):**  
> El sistema permet operar simultàniament al mateix NinjaTrader 8 un compte líder automàtic **`Sim101`** (per a empreses que permeten ATI/Webhooks) i un compte líder manual **`Sim102`** (per a empreses manuals). El Bridge Python bloqueja per codi (`HTTP 403`) qualsevol ordre automàtica cap a `Sim102` per garantir el compliment normatiu al 100%.

---

## 📂 Mapa de Carpetes del Paquet

```text
LayerSniper_Pro_Client_Package_v1.0/
├── LLEGIR_PRIMER.md                         <-- Estàs aquí
├── 01_Kit_NinjaTrader8_i_Replikanto/        <-- Plantilles ATM (3, 5, 10, 30 MNQ) + Botons [BE +2t] i [FLAT] + Auto-Qty
├── 02_Bridge_VPS_Windows/                   <-- Servidor Webhook lleuger per a Windows VPS (Port 80 / Túnel HTTPS 443 / Port 8090)
├── 03_Servidor_Railway_Pro/                 <-- Servidor central opcional amb HUD Web, News Guardian i Tradovate REST API
└── 04_Manuals_Configuracio/
    └── ca/
        ├── 01_ARQUITECTURA_I_INICI_RAPID.md
        ├── 02_CONFIGURACIO_TRADINGVIEW_I_ALERTES.md
        ├── 03_CONFIGURACIO_NINJATRADER_I_REPLIKANTO.md
        ├── 04_CONFIGURACIO_BRIDGE_VPS_DIRECTE.md
        └── 05_DESPLEGAMENT_RAILWAY_PRO_I_TRADOVATE.md
```

---

## 🚀 Ordre Recomanat de Posada en Marxa

1. Llegeix **`04_Manuals_Configuracio/ca/01_ARQUITECTURA_I_INICI_RAPID.md`** per verificar els requisits previs (dades CME en temps real a TradingView, pla amb Webhooks i llicència de NinjaTrader 8 / Replikanto).
2. Segueix **`03_CONFIGURACIO_NINJATRADER_I_REPLIKANTO.md`** al teu PC o VPS Windows:
   - Executa `01_Kit_NinjaTrader8_i_Replikanto\INSTALAR_KIT_NT8.bat` i prem **`F5`** al *NinjaScript Editor*.
   - Configura els comptes líders `Sim101` / `Sim102` i les pestanyes de Replikanto.
3. Si activaràs l'execució automàtica per Webhook:
   - **Sense Railway (Directe al VPS):** Segueix **`04_CONFIGURACIO_BRIDGE_VPS_DIRECTE.md`** executant `02_Bridge_VPS_Windows\INSTALAR_BRIDGE_VPS.bat`.
   - **Amb Servidor Railway Pro:** Segueix **`05_DESPLEGAMENT_RAILWAY_PRO_I_TRADOVATE.md`** i després connecta el VPS en Mode `[3]`.
4. Finalment, obre **`02_CONFIGURACIO_TRADINGVIEW_I_ALERTES.md`** per carregar l'estratègia *Invite-Only* **`Layer Sniper Pro`** sobre `MNQ1!` (`1m`), introduir el teu `Webhook Secret Token` i crear l'alerta amb **`Order fills and alert() function calls`** i el missatge **`{{strategy.order.alert_message}}`**.
