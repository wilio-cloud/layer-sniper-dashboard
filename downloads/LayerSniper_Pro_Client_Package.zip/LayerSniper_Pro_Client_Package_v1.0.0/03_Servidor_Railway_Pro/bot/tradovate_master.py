import os
import json
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, Any, Optional, List
import requests
from bot.config import config

logger = logging.getLogger("TradovateMaster")

LOCKOUT_FILE_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "config",
    "tradovate_lockout.json"
)


class TradovateMasterClient:
    def __init__(self):
        self.base_url = config.base_url
        self.access_token: Optional[str] = None
        self.token_expiry: Optional[datetime] = None
        self.user_id: Optional[int] = None
        self.account_id: Optional[int] = config.account_id
        self.account_spec: Optional[str] = config.account_spec
        self._attempted_resolve_account: bool = False

        # Estat persistent del Cadenat Anti-Tilt (bloqueig de Tradovate fins a les 15:00h BCN)
        self.locked_until_madrid: Optional[datetime] = None
        self.locked_at_madrid: Optional[str] = None
        self.lock_reason: Optional[str] = None
        self._load_lockout_state()

        # Cache interna per evitar saturació de l'API (429 Too Many Requests)
        self._cache_ttl: float = 4.0
        self._last_balance: float = 50000.00
        self._last_balance_time: float = 0.0
        self._last_positions: List[Dict[str, Any]] = []
        self._last_positions_time: float = 0.0
        self._last_orders: List[Dict[str, Any]] = []
        self._last_orders_time: float = 0.0
        self._last_prices: Dict[str, float] = {}
        self._last_prices_time: Dict[str, float] = {}
        self._auth_cooldown_until: Optional[datetime] = None

        # Rastreig de l'última entrada col·locada per facilitar el Breakeven ràpid
        self.last_entry_price: Optional[float] = None
        self.last_entry_action: Optional[str] = None
        self.last_entry_qty: Optional[int] = None
        self.last_entry_symbol: Optional[str] = None

    def authenticate(self, force: bool = False) -> bool:
        if not getattr(config, "tradovate_direct_enabled", True):
            return False
        if not config.user or not config.password:
            logger.warning("Credencials Tradovate no configurades (TRADOVATE_USER o TRADOVATE_PASS buit).")
            return False

        if not force and self._auth_cooldown_until:
            now_utc = datetime.now(timezone.utc)
            if now_utc < self._auth_cooldown_until:
                return False

        if not force and self.access_token:
            now_utc = datetime.now(timezone.utc)
            if self.token_expiry is None or now_utc < self.token_expiry - timedelta(minutes=15):
                return True
            if now_utc < self.token_expiry - timedelta(minutes=1):
                try:
                    renew_resp = requests.get(
                        f"{self.base_url}/auth/renewaccesstoken",
                        headers={
                            "Authorization": f"Bearer {self.access_token}",
                            "Accept": "application/json"
                        },
                        timeout=10
                    )
                    if renew_resp.status_code == 200:
                        r_data = renew_resp.json()
                        if r_data.get("accessToken"):
                            self.access_token = r_data["accessToken"]
                            exp_str = r_data.get("expirationTime")
                            if exp_str:
                                try:
                                    self.token_expiry = datetime.fromisoformat(exp_str.replace("Z", "+00:00"))
                                except Exception:
                                    self.token_expiry = now_utc + timedelta(minutes=75)
                            else:
                                self.token_expiry = now_utc + timedelta(minutes=75)
                            logger.info(f"🔄 Token Tradovate renovat via /auth/renewaccesstoken! Expira a: {self.token_expiry.isoformat()}")
                            return True
                except Exception as ren_err:
                    logger.warning(f"No s'ha pogut renovar el token via /auth/renewaccesstoken: {ren_err}")

        url = f"{self.base_url}/auth/accesstokenrequest"
        payload: Dict[str, Any] = {
            "name": config.user,
            "password": config.password,
            "appId": config.app_id,
            "appVersion": config.app_version,
            "sec": config.sec
        }
        if getattr(config, "device_id", None):
            payload["deviceId"] = config.device_id
        if config.cid:
            try:
                payload["cid"] = int(config.cid)
            except ValueError:
                payload["cid"] = config.cid

        headers = {"Content-Type": "application/json", "Accept": "application/json"}

        try:
            logger.info(f"Connectant a Tradovate ({config.tradovate_env.upper()}): sol·licitant access token...")
            resp = requests.post(url, json=payload, headers=headers, timeout=10)

            if resp.status_code == 200:
                data = resp.json()
                self.access_token = data.get("accessToken")
                self.user_id = data.get("userId")

                if not self.access_token:
                    err_msg = data.get("errorText", str(data))
                    p_time = data.get("p-time", 60)
                    cd = int(p_time) if isinstance(p_time, (int, float)) else 60
                    self._auth_cooldown_until = datetime.now(timezone.utc) + timedelta(seconds=max(cd, 30))
                    logger.error(f"❌ Error d'autenticació Tradovate ({config.tradovate_env.upper()}): {err_msg}")
                    return False

                self._auth_cooldown_until = None
                expiration_str = data.get("expirationTime")
                if expiration_str:
                    try:
                        self.token_expiry = datetime.fromisoformat(expiration_str.replace("Z", "+00:00"))
                    except Exception:
                        self.token_expiry = datetime.now(timezone.utc) + timedelta(minutes=75)
                else:
                    self.token_expiry = datetime.now(timezone.utc) + timedelta(minutes=75)

                logger.info(f"✅ Autenticació Tradovate OK! Expira a: {self.token_expiry.isoformat()}")

                if not self.account_id or not self.account_spec:
                    self._resolve_default_account()
                return True
            else:
                logger.error(f"Error d'autenticació Tradovate: HTTP {resp.status_code} - {resp.text}")
                self._auth_cooldown_until = datetime.now(timezone.utc) + timedelta(seconds=60)
                return False
        except Exception as e:
            logger.error(f"Excepció durant l'autenticació Tradovate: {e}")
            self._auth_cooldown_until = datetime.now(timezone.utc) + timedelta(seconds=30)
            return False

    def _get_headers(self) -> Dict[str, str]:
        self.authenticate(force=False)
        return {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

    def _request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        url = endpoint if endpoint.startswith("http") else f"{self.base_url}{endpoint}"
        headers = self._get_headers()
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        timeout = kwargs.pop("timeout", 10)
        http_fn = requests.post if method.upper() == "POST" else (requests.get if method.upper() == "GET" else requests.request)
        if http_fn in (requests.post, requests.get):
            resp = http_fn(url, headers=headers, timeout=timeout, **kwargs)
        else:
            resp = requests.request(method, url, headers=headers, timeout=timeout, **kwargs)

        if resp.status_code == 401:
            logger.warning(f"⚠️ Rebut HTTP 401 a {url}. Renovant token Tradovate...")
            self.access_token = None
            self.token_expiry = None
            if self.authenticate(force=True):
                headers = self._get_headers()
                if http_fn in (requests.post, requests.get):
                    resp = http_fn(url, headers=headers, timeout=timeout, **kwargs)
                else:
                    resp = requests.request(method, url, headers=headers, timeout=timeout, **kwargs)
                logger.info(f"🔄 Reintent després de re-autenticació: HTTP {resp.status_code}")

        return resp

    def _resolve_default_account(self):
        if self._attempted_resolve_account:
            return
        self._attempted_resolve_account = True
        try:
            accounts = self.get_accounts()
            if accounts and len(accounts) > 0:
                acc = accounts[0]
                self.account_id = acc.get("id")
                self.account_spec = acc.get("name")
                logger.info(f"Compte Tradovate per defecte: {self.account_spec} (ID: {self.account_id})")
        except Exception as e:
            logger.warning(f"No s'ha pogut auto-resoldre compte: {e}")

    def get_accounts(self) -> List[Dict[str, Any]]:
        resp = self._request("GET", "/account/list")
        resp.raise_for_status()
        return resp.json()

    def get_cash_balance(self) -> float:
        now = time.time()
        if now - self._last_balance_time < self._cache_ttl:
            return self._last_balance

        try:
            resp = self._request("GET", "/cashBalance/list")
            if resp.status_code == 200:
                items = resp.json()
                fx_to_usd = {
                    1: 1.0,
                    2: 1.08,
                    4: 1.28,
                    3: 0.65,
                    5: 0.73,
                    6: 0.0067,
                    9: 1.13,
                    10: 1.08,
                    12: 1.28,
                    14: 0.65,
                }
                matching_items = [
                    item for item in items
                    if not self.account_id or item.get("accountId") == self.account_id
                ]
                if matching_items:
                    total_usd = 0.0
                    for item in matching_items:
                        amt = float(item.get("amount", 0.0))
                        c_id = item.get("currencyId", 1)
                        rate = fx_to_usd.get(c_id, 1.0)
                        total_usd += amt * rate
                    self._last_balance = round(total_usd, 2)
                    self._last_balance_time = now
                    return self._last_balance
            accounts = self.get_accounts()
            for acc in accounts:
                if not self.account_id or acc.get("id") == self.account_id:
                    if "balance" in acc:
                        val = float(acc["balance"])
                        self._last_balance = val
                        self._last_balance_time = now
                        return val
        except Exception as e:
            logger.warning(f"Error consultant saldo de caixa ({e}). Utilitzant saldo anterior: {self._last_balance}")
        return self._last_balance

    def suggest_contract(self, symbol_text: str = "MNQ") -> Optional[str]:
        try:
            resp = self._request("GET", f"/contract/suggest?text={symbol_text}")
            if resp.status_code == 200:
                data = resp.json()
                if isinstance(data, list) and len(data) > 0:
                    return data[0].get("name")
        except Exception as e:
            logger.debug(f"Error suggerint contracte: {e}")
        return None

    def place_bracket_order(
        self,
        symbol: str,
        action: str,  # "Buy" o "Sell"
        qty: int,
        entry_price: float,
        tp_price: float,
        sl_price: float,
        order_type: str = "Market",
        allow_marketable: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Envia una ordre OSO nativa a Tradovate:
        Parent: Market o Limit
        Bracket1: Stop Loss
        Bracket2: Take Profit Limit
        """
        if self.is_locked_out():
            st = self.get_lockout_status()
            logger.error(
                f"🔒 SAFETY LOCKOUT: Compte Tradovate bloquejat fins a {st.get('locked_until_madrid_str')}. "
                f"Rebutjant ordre {action} {qty} {symbol}."
            )
            return None

        if not self.account_id or not self.account_spec:
            self._resolve_default_account()

        clean_symbol = symbol.strip() if symbol else ""
        if not clean_symbol or "!" in clean_symbol or clean_symbol.upper() in ("MNQ", "NQ"):
            from bot.contract_resolver import resolve_active_contract
            clean_symbol = resolve_active_contract(self, symbol_base="MNQ")
            logger.info(f"🔄 Contracte resolt automàticament: '{symbol}' -> '{clean_symbol}'")
        symbol = clean_symbol

        if order_type.lower() == "limit" and not allow_marketable:
            mkt_price = self.get_current_market_price(symbol)
            if mkt_price:
                if action.lower() == "buy" and mkt_price <= entry_price:
                    logger.error(f"🛑 SAFETY REJECT: Buy Limit ({entry_price:.2f}) >= mkt ({mkt_price:.2f}).")
                    return None
                elif action.lower() == "sell" and mkt_price >= entry_price:
                    logger.error(f"🛑 SAFETY REJECT: Sell Limit ({entry_price:.2f}) <= mkt ({mkt_price:.2f}).")
                    return None

        exit_action = "Sell" if action.lower() == "buy" else "Buy"

        payload: Dict[str, Any] = {
            "accountSpec": self.account_spec,
            "accountId": self.account_id,
            "action": action.capitalize(),
            "symbol": symbol,
            "orderQty": qty,
            "orderType": "Market" if str(order_type).lower() == "market" else order_type,
            "isAutomated": True,
            "bracket1": {
                "action": exit_action,
                "orderType": "Stop",
                "stopPrice": round(sl_price, 2)
            },
            "bracket2": {
                "action": exit_action,
                "orderType": "Limit",
                "price": round(tp_price, 2)
            }
        }
        if str(order_type).lower() != "market" and entry_price is not None:
            payload["price"] = round(entry_price, 2)

        logger.info(
            f"Enviant OSO Tradovate: {action.upper()} {str(order_type).upper()} {qty} {symbol} "
            f"[Ref: {entry_price:.2f} | TP: {tp_price:.2f} | SL: {sl_price:.2f}]"
        )

        try:
            resp = self._request("POST", "/order/placeOSO", json=payload, timeout=10)
            if resp.status_code in (200, 201):
                data = resp.json()
                if "failureReason" in data or "failureText" in data or not data.get("orderId"):
                    err_msg = data.get("failureText") or data.get("failureReason") or "Unknown rejection"
                    logger.error(f"❌ Ordre OSO rebutjada per Tradovate ({err_msg}): {data}")
                    return None
                self._last_orders_time = 0.0
                self.last_entry_price = round(entry_price, 2)
                self.last_entry_action = action.capitalize()
                self.last_entry_qty = qty
                self.last_entry_symbol = symbol
                logger.info(f"✅ Ordre OSO acceptada: {data}")
                return data
            else:
                logger.error(f"❌ Error col·locant ordre OSO: HTTP {resp.status_code} - {resp.text}")
                return None
        except Exception as e:
            logger.error(f"Excepció en place_bracket_order: {e}")
            return None

    def move_stop_to_breakeven(
        self,
        be_price: Optional[float] = None,
        entry_price: Optional[float] = None,
        direction: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        🛡️ Llei 2 Layer Sniper: Mou l'ordre Stop Loss activa a Breakeven (preu d'entrada + offset)
        mitjançant l'endpoint POST /order/modifyorder de Tradovate.
        """
        self._last_orders_time = 0.0
        self._last_positions_time = 0.0

        orders = self.get_open_orders()
        positions = self.get_positions()

        working_stops = [
            o for o in orders
            if o.get("ordStatus", "").lower() in ("working", "accepted", "pending")
            and (
                o.get("orderType", "").lower() in ("stop", "stoplimit")
                or o.get("stopPrice") is not None
            )
        ]

        if not working_stops:
            logger.warning("⚠️ move_stop_to_breakeven: No s'ha trobat cap ordre Stop Loss activa a Tradovate.")
            return {"status": "NO_ACTIVE_STOP_FOUND", "modified": False}

        target_stop = working_stops[-1]
        stop_order_id = target_stop.get("id")
        stop_qty = target_stop.get("orderQty") or self.last_entry_qty or config.contracts_live
        stop_type = target_stop.get("orderType") or "Stop"

        # Determinar el preu de Breakeven exacte:
        # Prioritat 1: Posició real oberta a Tradovate (netPrice exacte del fill) + be_offset_points
        # Prioritat 2: be_price passat pel webhook de TradingView
        # Prioritat 3: entry_price o last_entry_price
        resolved_be_price = be_price
        active_pos = next((p for p in positions if p.get("netPos", 0) != 0), None)
        if active_pos and active_pos.get("netPrice"):
            net_px = float(active_pos["netPrice"])
            net_pos_qty = int(active_pos.get("netPos", 0))
            stop_qty = abs(net_pos_qty)
            offset = getattr(config, "be_offset_points", 0.0)
            if net_pos_qty > 0:
                resolved_be_price = round(round((net_px + offset) / 0.25) * 0.25, 2)
            else:
                resolved_be_price = round(round((net_px - offset) / 0.25) * 0.25, 2)
        elif resolved_be_price is None:
            base_px = entry_price or self.last_entry_price
            if base_px is not None:
                offset = getattr(config, "be_offset_points", 0.0)
                dir_clean = (direction or self.last_entry_action or "Buy").upper()
                if dir_clean in ("LONG", "BUY"):
                    resolved_be_price = round(round(( float(base_px) + offset) / 0.25) * 0.25, 2)
                else:
                    resolved_be_price = round(round((float(base_px) - offset) / 0.25) * 0.25, 2)

        if resolved_be_price is None:
            logger.error("❌ move_stop_to_breakeven: No s'ha pogut determinar el preu de Breakeven.")
            return {"status": "CANNOT_RESOLVE_BE_PRICE", "modified": False}

        payload = {
            "orderId": stop_order_id,
            "orderQty": int(stop_qty),
            "orderType": stop_type,
            "stopPrice": round(float(resolved_be_price), 2),
            "isAutomated": True
        }

        logger.info(f"🛡️ Modificant Stop Loss ID {stop_order_id} a Breakeven @ {resolved_be_price:.2f} (Qty: {stop_qty})...")
        try:
            resp = self._request("POST", "/order/modifyorder", json=payload, timeout=10)
            if resp.status_code in (200, 201):
                data = resp.json()
                if "failureReason" in data or "failureText" in data:
                    err = data.get("failureText") or data.get("failureReason")
                    logger.error(f"❌ Tradovate ha rebutjat modifyorder a BE: {err}")
                    return {"status": "MODIFY_REJECTED", "modified": False, "error": err}
                self._last_orders_time = 0.0
                logger.info(f"✅ Stop Loss ID {stop_order_id} mogut a Breakeven ({resolved_be_price:.2f}) amb èxit!")
                return {
                    "status": "BREAKEVEN_APPLIED",
                    "modified": True,
                    "order_id": stop_order_id,
                    "be_price": round(float(resolved_be_price), 2),
                    "qty": int(stop_qty),
                    "response": data
                }
            else:
                logger.error(f"❌ Error HTTP {resp.status_code} en modifyorder: {resp.text}")
                return {"status": "HTTP_ERROR", "modified": False, "code": resp.status_code}
        except Exception as e:
            logger.error(f"Excepció en move_stop_to_breakeven: {e}")
            return {"status": "EXCEPTION", "modified": False, "error": str(e)}

    def get_open_orders(self) -> List[Dict[str, Any]]:
        now = time.time()
        if now - self._last_orders_time < self._cache_ttl:
            return self._last_orders

        try:
            resp = self._request("GET", "/order/list")
            if resp.status_code == 200:
                all_orders = resp.json()
                filtered_orders = [o for o in all_orders if not self.account_id or o.get("accountId") == self.account_id]

                try:
                    v_resp = self._request("GET", "/orderVersion/list")
                    if v_resp.status_code == 200:
                        versions = v_resp.json()
                        version_map = {v.get("orderId"): v for v in versions if v.get("orderId")}
                        for o in filtered_orders:
                            v = version_map.get(o.get("id"), {})
                            if not o.get("orderType"):
                                o["orderType"] = v.get("orderType", "")
                            if o.get("price") is None:
                                o["price"] = v.get("price")
                            if o.get("stopPrice") is None:
                                o["stopPrice"] = v.get("stopPrice")
                            if o.get("orderQty") is None:
                                o["orderQty"] = v.get("orderQty")
                except Exception as ve:
                    logger.debug(f"No s'ha pogut obtenir orderVersion/list: {ve}")

                self._last_orders = filtered_orders
                self._last_orders_time = now
                return filtered_orders
        except Exception as e:
            logger.error(f"Error consultant ordres: {e}")
        return self._last_orders

    def cancel_order(self, order_id: int) -> bool:
        payload = {"orderId": order_id}
        try:
            resp = self._request("POST", "/order/cancelorder", json=payload)
            if resp.status_code in (200, 201):
                self._last_orders_time = 0.0
                return True
            return False
        except Exception as e:
            logger.error(f"Error cancel·lant ordre {order_id}: {e}")
            return False

    def cancel_all_pending_orders(self) -> int:
        orders = self.get_open_orders()
        canceled_count = 0
        for o in orders:
            status = o.get("ordStatus", "").lower()
            if status in ("working", "accepted", "pending"):
                oid = o.get("id")
                if oid and self.cancel_order(oid):
                    canceled_count += 1
        logger.info(f"Cancel·lades {canceled_count} ordres pendents a Tradovate.")
        return canceled_count

    def get_positions(self) -> List[Dict[str, Any]]:
        now = time.time()
        if now - self._last_positions_time < self._cache_ttl:
            return self._last_positions

        try:
            resp = self._request("GET", "/position/list")
            if resp.status_code == 200:
                all_positions = resp.json()
                pos = [p for p in all_positions if (not self.account_id or p.get("accountId") == self.account_id) and p.get("netPos", 0) != 0]
                self._last_positions = pos
                self._last_positions_time = now
                return pos
        except Exception as e:
            logger.error(f"Error consultant posicions: {e}")
        return self._last_positions

    def close_all_positions(self) -> bool:
        positions = self.get_positions()
        success = True
        for pos in positions:
            net_pos = pos.get("netPos", 0)
            if net_pos == 0:
                continue
            contract_id = pos.get("contractId")
            payload = {
                "accountId": self.account_id,
                "contractId": contract_id,
                "admin": False
            }
            logger.warning(f"🚨 Tancant posició d'emergència: ContractId {contract_id} (Net: {net_pos})...")
            try:
                resp = self._request("POST", "/order/liquidateposition", json=payload)
                if resp.status_code not in (200, 201):
                    logger.error(f"Error liquidant posició: {resp.status_code} - {resp.text}")
                    success = False
            except Exception as e:
                logger.error(f"Excepció liquidant posició: {e}")
                success = False
        return success

    def has_active_position(self) -> bool:
        positions = self.get_positions()
        return any(p.get("netPos", 0) != 0 for p in positions)

    def verify_bracket_integrity(self) -> Dict[str, Any]:
        positions = self.get_positions()
        active_pos = [p for p in positions if p.get("netPos", 0) != 0]

        if not active_pos:
            return {"status": "OK", "has_position": False, "protected": True}

        orders = self.get_open_orders()
        working_stops = [
            o for o in orders
            if o.get("ordStatus", "").lower() in ("working", "accepted")
            and (
                o.get("orderType", "").lower() in ("stop", "stoplimit")
                or o.get("stopPrice") is not None
            )
        ]

        if not working_stops:
            logger.error("🚨 ALERTA CRÍTICA: Posició oberta SENSE Stop Loss actiu!")
            return {
                "status": "UNPROTECTED_POSITION",
                "has_position": True,
                "protected": False,
                "positions": active_pos,
                "working_stops": []
            }

        return {
            "status": "OK",
            "has_position": True,
            "protected": True,
            "positions": active_pos,
            "working_stops": working_stops
        }

    def get_current_market_price(self, symbol: str = "MNQ") -> Optional[float]:
        now = time.time()
        if symbol in self._last_prices and now - self._last_prices_time.get(symbol, 0) < self._cache_ttl:
            return self._last_prices[symbol]

        try:
            import yfinance as yf
            base = "MNQ"
            if symbol.upper().startswith("NQ"):
                base = "NQ"
            candidates = [f"{symbol}=F", f"{base}=F", "MNQ=F", "NQ=F"]
            for c in candidates:
                try:
                    t = yf.Ticker(c)
                    p = t.fast_info.get("lastPrice")
                    if p and p > 0:
                        val = float(p)
                        self._last_prices[symbol] = val
                        self._last_prices_time[symbol] = now
                        return val
                except Exception:
                    continue
        except Exception:
            pass
        return self._last_prices.get(symbol)

    # =========================================================================
    # CADENAT ANTI-TILT TRADOVATE FINS A L'ENDEMÀ A LES 15:00H BCN
    # =========================================================================
    def _load_lockout_state(self):
        try:
            if os.path.exists(LOCKOUT_FILE_PATH):
                with open(LOCKOUT_FILE_PATH, "r", encoding="utf-8") as f:
                    data = json.load(f)
                until_iso = data.get("locked_until_iso")
                if until_iso:
                    dt = datetime.fromisoformat(until_iso)
                    if dt.tzinfo is None:
                        dt = config.tz_madrid.localize(dt)
                    else:
                        dt = dt.astimezone(config.tz_madrid)
                    self.locked_until_madrid = dt
                    self.locked_at_madrid = data.get("locked_at_iso")
                    self.lock_reason = data.get("reason", "Cadenat de sessió 15:00h")
        except Exception as e:
            logger.warning(f"No s'ha pogut carregar l'estat del cadenat Tradovate: {e}")

    def _save_lockout_state(self):
        try:
            os.makedirs(os.path.dirname(LOCKOUT_FILE_PATH), exist_ok=True)
            data = {
                "locked_until_iso": self.locked_until_madrid.isoformat() if self.locked_until_madrid else None,
                "locked_at_iso": self.locked_at_madrid,
                "reason": self.lock_reason
            }
            with open(LOCKOUT_FILE_PATH, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.warning(f"No s'ha pogut desar l'estat del cadenat Tradovate: {e}")

    def clear_lockout(self):
        self.locked_until_madrid = None
        self.locked_at_madrid = None
        self.lock_reason = None
        self._save_lockout_state()

    def is_locked_out(self, now_madrid: Optional[datetime] = None) -> bool:
        if self.locked_until_madrid is None:
            return False
        now_m = now_madrid or datetime.now(config.tz_madrid)
        if now_m.tzinfo is None:
            now_m = config.tz_madrid.localize(now_m)
        else:
            now_m = now_m.astimezone(config.tz_madrid)

        if now_m < self.locked_until_madrid:
            return True

        # S'ha assolit l'hora de desbloqueig (09:00 NY = 15:00h BCN / 14:00h BCN en setmana DST) -> s'obre automàticament
        logger.info("🔓 Cadenat Tradovate finalitzat (09:00 NY assolides). Desbloquejant operació per a la nova sessió.")
        self.clear_lockout()
        return False

    def get_lockout_status(self, now_madrid: Optional[datetime] = None) -> Dict[str, Any]:
        now_m = now_madrid or datetime.now(config.tz_madrid)
        if now_m.tzinfo is None:
            now_m = config.tz_madrid.localize(now_m)
        else:
            now_m = now_m.astimezone(config.tz_madrid)

        locked = self.is_locked_out(now_m)
        if not locked or not self.locked_until_madrid:
            return {
                "locked": False,
                "locked_until_iso": None,
                "locked_until_madrid_str": None,
                "remaining_seconds": 0,
                "reason": None
            }

        rem_sec = max(0, int((self.locked_until_madrid - now_m).total_seconds()))
        return {
            "locked": True,
            "locked_until_iso": self.locked_until_madrid.isoformat(),
            "locked_until_madrid_str": self.locked_until_madrid.strftime("%d/%m/%Y %H:%M:%S BCN"),
            "locked_at_iso": self.locked_at_madrid,
            "remaining_seconds": rem_sec,
            "reason": self.lock_reason or "Bloqueig de fi de sessió fins a les 15:00h BCN"
        }

    def enforce_lockout_across_all_accounts(self) -> Dict[str, Any]:
        """
        Cancel·la les ordres pendents i liquida a mercat les posicions obertes
        EXCLUSIVAMENT al compte dedicat de Layer Sniper (`self.account_id`),
        sense tocar MAI altres subcomptes del mateix usuari.
        """
        if not getattr(config, "tradovate_direct_enabled", True):
            return {"status": "TRADOVATE_DIRECT_DISABLED_ISOLATED_MODE", "cancelled_orders": 0, "closed_positions": 0}
        if not (config.user and config.password):
            return {"status": "NO_CREDENTIALS_CONFIGURED", "cancelled_orders": 0, "closed_positions": 0}
        target_acc_id = self.account_id or config.account_id
        if not target_acc_id:
            return {"status": "NO_DEDICATED_ACCOUNT_ID_CONFIGURED", "cancelled_orders": 0, "closed_positions": 0}

        cancelled_orders = 0
        closed_positions = 0
        try:
            self._last_orders_time = 0.0
            self._last_positions_time = 0.0

            # 1. Cancel·lar ordres pendents NOMÉS del compte dedicat de Layer Sniper
            resp_o = self._request("GET", "/order/list")
            if resp_o.status_code == 200:
                for o in resp_o.json():
                    if o.get("accountId") != target_acc_id:
                        continue
                    st = str(o.get("ordStatus", "")).lower()
                    if st in ("working", "accepted", "pending"):
                        oid = o.get("id")
                        if oid and self.cancel_order(oid):
                            cancelled_orders += 1

            # 2. Liquidar posicions obertes NOMÉS del compte dedicat de Layer Sniper
            resp_p = self._request("GET", "/position/list")
            if resp_p.status_code == 200:
                for p in resp_p.json():
                    if p.get("accountId") != target_acc_id:
                        continue
                    net_pos = p.get("netPos", 0)
                    if net_pos != 0:
                        cid = p.get("contractId")
                        if cid:
                            liq_resp = self._request(
                                "POST",
                                "/order/liquidateposition",
                                json={"accountId": target_acc_id, "contractId": cid, "admin": False}
                            )
                            if liq_resp.status_code in (200, 201):
                                closed_positions += 1
        except Exception as e:
            logger.error(f"Error aplicant enforce_lockout_across_all_accounts: {e}")

        return {
            "status": "LOCKOUT_ENFORCED",
            "cancelled_orders": cancelled_orders,
            "closed_positions": closed_positions
        }

    def lock_accounts_until_15h(
        self,
        reason: str = "Tancament de sessió Layer Sniper — Bloqueig fins demà 09:00 NY",
        now_madrid: Optional[datetime] = None
    ) -> Dict[str, Any]:
        """
        Bloqueja el compte de Tradovate des d'ara mateix fins al proper cicle de les 09:00:00 NY
        (equivalent a les 15:00:00 BCN la major part de l'any i a les 14:00:00 BCN durant les setmanes de desfasament DST):
        - Si s'activa a partir de les 09:00 NY d'avui, bloqueja fins al proper dia hàbil a les 09:00:00 NY.
        - Si s'activa abans de les 09:00 NY d'avui (matinada o matí), bloqueja fins a AVUI a les 09:00:00 NY.
        """
        now_m = now_madrid or datetime.now(config.tz_madrid)
        if now_m.tzinfo is None:
            now_m = config.tz_madrid.localize(now_m)
        else:
            now_m = now_m.astimezone(config.tz_madrid)

        now_ny = now_m.astimezone(config.tz_ny)
        unlock_h_ny = getattr(config, "unlock_hour_ny", 9)
        unlock_m_ny = getattr(config, "unlock_minute_ny", 0)

        target_day_ny = now_ny.date()
        today_unlock_ny = config.tz_ny.localize(
            datetime(target_day_ny.year, target_day_ny.month, target_day_ny.day, unlock_h_ny, unlock_m_ny, 0)
        )
        if now_ny >= today_unlock_ny or target_day_ny.weekday() >= 5:
            target_day_ny = target_day_ny + timedelta(days=1)
            while target_day_ny.weekday() >= 5:
                target_day_ny = target_day_ny + timedelta(days=1)

        target_unlock_ny = config.tz_ny.localize(
            datetime(target_day_ny.year, target_day_ny.month, target_day_ny.day, unlock_h_ny, unlock_m_ny, 0)
        )
        target_unlock = target_unlock_ny.astimezone(config.tz_madrid)

        self.locked_until_madrid = target_unlock
        self.locked_at_madrid = now_m.isoformat()
        self.lock_reason = reason
        self._save_lockout_state()

        enforce_res = self.enforce_lockout_across_all_accounts()
        logger.warning(
            f"🔒 CADENAT TRADOVATE ACTIVAT fins a {target_unlock.strftime('%d/%m/%Y %H:%M:%S BCN')} | "
            f"Motiu: {reason} | Ordres cancel·lades: {enforce_res.get('cancelled_orders')} | "
            f"Posicions tancades: {enforce_res.get('closed_positions')}"
        )

        status_dict = self.get_lockout_status(now_m)
        status_dict["enforcement"] = enforce_res
        return status_dict


tradovate_master = TradovateMasterClient()
