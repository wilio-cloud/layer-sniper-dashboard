import os
import uuid
import socket
import datetime
from dataclasses import dataclass
from typing import Optional
import pytz
from dotenv import load_dotenv

load_dotenv()


def _default_device_id() -> str:
    seed = os.getenv("TRADOVATE_USER") or socket.gethostname() or "layersniper-node"
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, f"layersniper.tradovate.{seed}"))


@dataclass
class LayerSniperConfig:
    # --- ENTORNS TRADOVATE ---
    # Si és False, Layer Sniper opera 100% sobre el seu compte dedicat de NinjaTrader 8 / Replikanto
    # sense tocar l'API directa de Tradovate. Posa'l a True quan hi assignis un compte Tradovate exclusiu.
    tradovate_direct_enabled: bool = os.getenv("TRADOVATE_DIRECT_ENABLED", "false").lower() in ("true", "1", "yes")
    tradovate_env: str = os.getenv("TRADOVATE_ENV", "demo").lower()

    # Credencials Tradovate
    user: str = os.getenv("TRADOVATE_USER", "")
    password: str = os.getenv("TRADOVATE_PASS", "")
    app_id: str = os.getenv("TRADOVATE_APP_ID", "LayerSniperPro")
    app_version: str = os.getenv("TRADOVATE_APP_VERSION", "1.0")
    cid: Optional[str] = os.getenv("TRADOVATE_CID", None)
    sec: str = os.getenv("TRADOVATE_SEC", "")
    device_id: str = os.getenv("TRADOVATE_DEVICE_ID") or _default_device_id()

    # Compte Tradovate
    account_id: Optional[int] = int(os.getenv("TRADOVATE_ACCOUNT_ID")) if os.getenv("TRADOVATE_ACCOUNT_ID") else None
    account_spec: Optional[str] = os.getenv("TRADOVATE_ACCOUNT_SPEC", None)

    # Mode del sistema: 'sentinel_and_live', 'sentinel_only', 'webhook_only'
    engine_mode: str = os.getenv("ENGINE_MODE", "sentinel_and_live").lower()
    sentinel_poll_interval: int = int(os.getenv("SENTINEL_POLL_INTERVAL", "15"))
    retest_bot_url: Optional[str] = os.getenv("RETEST_BOT_URL", None)

    # Actiu i Mida Operativa
    symbol_base: str = os.getenv("SYMBOL_BASE", "MNQ")
    contracts_live: int = int(os.getenv("CONTRACTS_LIVE", os.getenv("INITIAL_CONTRACTS", "10")))
    auto_scale: bool = os.getenv("AUTO_SCALE", "false").lower() in ("true", "1", "yes")
    max_contracts: int = int(os.getenv("MAX_CONTRACTS", "20"))
    tick_size: float = 0.25
    point_value: float = 2.0  # 1 punt MNQ = $2.00 USD

    # --- ROL DE COMPTE I DUALITAT LIVE / PROP MASTER ---
    # 'prop_master': Servei per a comptes fondejats (Tradovate Demo o Relay cap a NinjaTrader/Replikanto)
    # 'live': Servei per a capital propi real (Tradovate Live, mida dinàmica per tram de capital)
    account_role: str = os.getenv("ACCOUNT_ROLE", "prop_master").lower()
    prop_master_contracts: int = int(os.getenv("PROP_MASTER_CONTRACTS", os.getenv("CONTRACTS_LIVE", "10")))
    prop_bloc_a_contracts: int = int(os.getenv("PROP_BLOC_A_CONTRACTS", "10"))
    prop_bloc_b_contracts: int = int(os.getenv("PROP_BLOC_B_CONTRACTS", "10"))

    # Execució a Tradovate quan estem en rol prop_master:
    # Si és True, a més d'enviar al Bridge de NinjaTrader (si FORWARD_WEBHOOK_URL està definit),
    # també col·loca l'ordre al compte Tradovate configurat (si n'hi ha).
    execute_tradovate_in_prop_mode: bool = os.getenv("EXECUTE_TRADOVATE_IN_PROP_MODE", "true").lower() in ("true", "1", "yes")

    # Model 1 de dimensionament Live (Capital per tram de saldo net disponible)
    live_capital_step: float = float(os.getenv("LIVE_CAPITAL_STEP", "1000.0"))
    live_min_contracts: int = int(os.getenv("LIVE_MIN_CONTRACTS", "1"))
    live_max_contracts: Optional[int] = int(os.getenv("LIVE_MAX_CONTRACTS")) if os.getenv("LIVE_MAX_CONTRACTS") else 10

    # --- WEBHOOK RELAY / FANOUT (Cap al segon Railway Live o cap al ChartVPS NinjaTrader Bridge) ---
    forward_webhook_url: Optional[str] = os.getenv("FORWARD_WEBHOOK_URL", None)
    forward_webhook_secret: Optional[str] = os.getenv("FORWARD_WEBHOOK_SECRET", None)
    nt8_bot_account: str = os.getenv("NT8_BOT_ACCOUNT", "Sim103")

    # --- PARÀMETRES ESTRATÈGIA JJ LAYER SNIPER COMBO ELITE 2026 ---
    strategy_mode: str = os.getenv("STRATEGY_MODE", "SNIPER_COMBO_ELITE")
    anchor_hour_ny: int = int(os.getenv("ANCHOR_HOUR_NY", "9"))
    anchor_minute_ny: int = int(os.getenv("ANCHOR_MINUTE_NY", "30"))
    sniper_start_hour_ny: int = int(os.getenv("SNIPER_START_HOUR_NY", "9"))
    sniper_end_hour_ny: int = int(os.getenv("SNIPER_END_HOUR_NY", "12"))
    min_deviation_points: float = float(os.getenv("MIN_DEVIATION_POINTS", "50.0"))
    min_layer_deviation_points: float = float(os.getenv("MIN_LAYER_DEVIATION_POINTS", "40.0"))
    min_deep_cont_dev_points: float = float(os.getenv("MIN_DEEP_CONT_DEV_POINTS", "55.0"))
    tp_far_points: float = float(os.getenv("TP_FAR_POINTS", "30.0"))
    sl_far_points: float = float(os.getenv("SL_FAR_POINTS", "30.0"))
    tp_close_points: float = float(os.getenv("TP_CLOSE_POINTS", "15.0"))
    sl_close_points: float = float(os.getenv("SL_CLOSE_POINTS", "15.0"))
    be_offset_points: float = float(os.getenv("BE_OFFSET_POINTS", "0.5"))
    max_trades_per_day_bloc_a: int = int(os.getenv("MAX_TRADES_PER_DAY_BLOC_A", "1"))
    max_daily_trades: int = int(os.getenv("MAX_DAILY_TRADES", "2"))
    max_daily_losses: int = int(os.getenv("MAX_DAILY_LOSSES", "2"))

    # --- CADENAT ANTI-TILT TRADOVATE FINS L'ENDEMÀ A LES 09:00 NY (15:00H BCN normal / 14:00H BCN setmana DST) ---
    unlock_hour_ny: int = int(os.getenv("UNLOCK_HOUR_NY", "9"))
    unlock_minute_ny: int = int(os.getenv("UNLOCK_MINUTE_NY", "0"))
    unlock_hour_madrid: int = int(os.getenv("UNLOCK_HOUR_MADRID", "15"))
    unlock_minute_madrid: int = int(os.getenv("UNLOCK_MINUTE_MADRID", "0"))
    auto_lock_at_cutoff: bool = os.getenv("AUTO_LOCK_AT_CUTOFF", "true").lower() in ("true", "1", "yes")

    # --- MATRIU DE COMPTES I FLOTES DIFERENCIADES ---
    live_account_spec: str = os.getenv("LIVE_ACCOUNT_SPEC", "LIVE-CAPITAL-PROPI")
    prop_bot_account_spec: str = os.getenv("PROP_BOT_ACCOUNT_SPEC", "PROP-BLOC-A-SNIPER")
    prop_manual_account_spec: str = os.getenv("PROP_MANUAL_ACCOUNT_SPEC", "NT8-REPLIKANTO-FLEET")

    # --- ZONES HORÀRIES ---
    tz_ny_str: str = "America/New_York"
    tz_madrid_str: str = "Europe/Madrid"

    @property
    def tz_ny(self):
        return pytz.timezone(self.tz_ny_str)

    @property
    def tz_madrid(self):
        return pytz.timezone(self.tz_madrid_str)

    @property
    def dst_gap_hours(self) -> float:
        madrid_dt = datetime.datetime.now(self.tz_madrid)
        ny_dt = datetime.datetime.now(self.tz_ny)
        return (madrid_dt.utcoffset() - ny_dt.utcoffset()).total_seconds() / 3600.0

    @property
    def is_dst_divergence(self) -> bool:
        return abs(self.dst_gap_hours - 6.0) > 0.1

    # --- HORARIS DE TANCAMENT SESSIÓ (12:30 NY per defecte per permetre L11_1 11:00-11:59) I CME EOD ---
    session_cutoff_hour_ny: int = int(os.getenv("SESSION_CUTOFF_HOUR_NY", "12"))
    session_cutoff_minute_ny: int = int(os.getenv("SESSION_CUTOFF_MINUTE_NY", "30"))
    eod_close_hour_ny: int = int(os.getenv("EOD_CLOSE_HOUR", "16"))
    eod_close_minute_ny: int = int(os.getenv("EOD_CLOSE_MINUTE", "55"))

    # --- NOTIFICACIONS ---
    discord_webhook_url: Optional[str] = os.getenv("DISCORD_WEBHOOK_URL", None)
    discord_webhook_url_diari_comptes: Optional[str] = os.getenv("DISCORD_WEBHOOK_URL_DIARI_COMPTES") or os.getenv("DISCORD_WEBHOOK_URL", None)
    telegram_bot_token: Optional[str] = os.getenv("TELEGRAM_BOT_TOKEN", None)
    telegram_chat_id: Optional[str] = os.getenv("TELEGRAM_CHAT_ID", None)

    # --- DATABENTO API (PER AUDITORIA 1M / 1S DE FI DE SESSIÓ) ---
    databento_api_key: Optional[str] = os.getenv("DATABENTO_API_KEY") or os.getenv("API_KEY")
    commission_per_contract_rt: float = float(os.getenv("COMMISSION_PER_CONTRACT_RT", "1.24"))

    # --- DASHBOARD HUD, PORTAL INSTAL·LACIÓ & WEBHOOK ---
    port: int = int(os.getenv("PORT", "8080"))
    host: str = os.getenv("HOST", "0.0.0.0")
    webhook_secret: str = os.getenv("WEBHOOK_SECRET", "layersniper2026")
    dashboard_user: str = os.getenv("DASHBOARD_USER", "admin")
    dashboard_pass: str = os.getenv("DASHBOARD_PASS", "sniper2026!")
    portal_user: str = os.getenv("PORTAL_USER", "sniper")
    portal_pass: str = os.getenv("PORTAL_PASS", "sniperportal2026!")

    @property
    def base_url(self) -> str:
        if self.tradovate_env == "live":
            return "https://live.tradovateapi.com/v1"
        return "https://demo.tradovateapi.com/v1"

    @property
    def ws_url(self) -> str:
        if self.tradovate_env == "live":
            return "wss://live.tradovateapi.com/v1/websocket"
        return "wss://demo.tradovateapi.com/v1/websocket"


config = LayerSniperConfig()
