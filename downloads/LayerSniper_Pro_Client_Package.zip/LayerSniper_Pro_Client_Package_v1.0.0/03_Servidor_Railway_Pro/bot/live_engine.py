import datetime
import logging
from typing import Optional, Dict, Any, List
from bot.config import config
from bot.contract_resolver import get_current_front_month_code

logger = logging.getLogger("LiveEngine")


class LiveSniperEngine:
    """
    Motor d'estat en viu per a l'estratègia JJ Layer Sniper Pro 2026.
    Mantingut en memòria i sincronitzat amb els webhooks rebuts de TradingView.
    """
    def __init__(self):
        self.tz_ny = config.tz_ny
        self.tz_madrid = config.tz_madrid
        self.current_date: Optional[datetime.date] = None
        self.active_symbol: str = get_current_front_month_code(config.symbol_base)

        # Estat diari de Layer Sniper
        self.anchor_price: Optional[float] = None
        self.trades_executed_today: int = 0
        self.bloc_a_executed_today: int = 0
        self.bloc_b_executed_today: int = 0
        self.breakevens_triggered_today: int = 0
        self.last_signal_info: Optional[Dict[str, Any]] = None
        self.signal_history_today: List[Dict[str, Any]] = []
        self.eod_cleaned: bool = False

    def reset_day(self, today: datetime.date, reload_state: bool = False):
        self.current_date = today
        self.active_symbol = get_current_front_month_code(config.symbol_base)
        self.anchor_price = None
        self.trades_executed_today = 0
        self.bloc_a_executed_today = 0
        self.bloc_b_executed_today = 0
        self.breakevens_triggered_today = 0
        self.last_signal_info = None
        self.signal_history_today = []
        self.eod_cleaned = False
        logger.info(f"🔄 LiveSniperEngine: Estat diari reiniciat per a {today}")

    def record_trade_execution(self, payload: Dict[str, Any], qty: int, tp_price: float, sl_price: float, order_id: Any):
        strat = str(payload.get("strategy", "JJ_Layer_Sniper_ComboElite"))
        slot_str = str(payload.get("slot", "LAYER")).upper()
        self.trades_executed_today += 1
        if "bloca" in strat.lower() or "bloc_a" in strat.lower():
            self.bloc_a_executed_today += 1
        elif "blocb" in strat.lower() or "bloc_b" in strat.lower() or "cont" in strat.lower():
            self.bloc_b_executed_today += 1
        elif self.trades_executed_today == 1:
            self.bloc_a_executed_today += 1
        else:
            self.bloc_b_executed_today += 1

        now_ny = datetime.datetime.now(self.tz_ny)
        entry_info = {
            "time_ny": now_ny.strftime("%H:%M:%S"),
            "strategy": strat,
            "slot": payload.get("slot", "LAYER"),
            "mode": payload.get("mode", "FAR"),
            "action": payload.get("action"),
            "price": payload.get("price"),
            "tp_price": tp_price,
            "sl_price": sl_price,
            "qty": qty,
            "order_id": order_id,
            "be_applied": False
        }
        self.last_signal_info = entry_info
        self.signal_history_today.append(entry_info)

    def record_breakeven(self, be_price: float):
        self.breakevens_triggered_today += 1
        if self.last_signal_info:
            self.last_signal_info["be_applied"] = True
            self.last_signal_info["sl_price"] = be_price

    def tick(self, now_madrid: datetime.datetime):
        today = now_madrid.date()
        if self.current_date != today:
            self.reset_day(today)


live_unified_engine = LiveSniperEngine()
