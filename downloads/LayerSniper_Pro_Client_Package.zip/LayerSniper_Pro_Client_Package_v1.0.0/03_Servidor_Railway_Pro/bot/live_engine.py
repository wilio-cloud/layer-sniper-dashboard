import os
import json
import datetime
import logging
from typing import Optional, Dict, Any, List
from bot.config import config
from bot.contract_resolver import get_current_front_month_code

logger = logging.getLogger("LiveEngine")

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_LIVE_ENGINE_STATE_PATH = os.path.join(ROOT_DIR, "config", "live_engine_daily_state.json")


class LiveSniperEngine:
    """
    Motor d'estat en viu per a l'estratègia JJ Layer Sniper Pro 2026.
    Mantingut en memòria, sincronitzat amb els webhooks rebuts de TradingView
    i persistit diàriament en disc per sobreviure reinicis intra-sessió.
    """
    def __init__(self, state_file: Optional[str] = None):
        self.tz_ny = config.tz_ny
        self.tz_madrid = config.tz_madrid
        self.state_file = state_file or DEFAULT_LIVE_ENGINE_STATE_PATH
        self.current_date: Optional[datetime.date] = None
        self.active_symbol: str = get_current_front_month_code(config.symbol_base)

        # Estat diari de Layer Sniper
        self.anchor_price: Optional[float] = None
        self.trades_executed_today: int = 0
        self.bloc_a_executed_today: int = 0
        self.bloc_b_executed_today: int = 0
        self.breakevens_triggered_today: int = 0
        self.last_signal_info: Optional[Dict[str, Any]] = None
        self.signal_history_today: List[Dict[str, Any]] = []
        self.eod_cleaned: bool = False

        if self._persistence_enabled():
            today_madrid = datetime.datetime.now(self.tz_madrid).date()
            self._load_daily_state_if_today(today_madrid)

    def _persistence_enabled(self) -> bool:
        if self.state_file != DEFAULT_LIVE_ENGINE_STATE_PATH:
            return True
        return "PYTEST_CURRENT_TEST" not in os.environ

    def _save_daily_state(self):
        if not self._persistence_enabled():
            return
        try:
            os.makedirs(os.path.dirname(self.state_file), exist_ok=True)
            date_iso = (
                self.current_date.isoformat()
                if self.current_date
                else datetime.datetime.now(self.tz_madrid).date().isoformat()
            )
            payload = {
                "date": date_iso,
                "active_symbol": self.active_symbol,
                "anchor_price": self.anchor_price,
                "trades_executed_today": self.trades_executed_today,
                "bloc_a_executed_today": self.bloc_a_executed_today,
                "bloc_b_executed_today": self.bloc_b_executed_today,
                "breakevens_triggered_today": self.breakevens_triggered_today,
                "last_signal_info": self.last_signal_info,
                "signal_history_today": self.signal_history_today,
                "eod_cleaned": self.eod_cleaned,
                "updated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }
            with open(self.state_file, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f"No s'ha pogut desar l'estat diari de LiveSniperEngine: {e}")

    def _load_daily_state_if_today(self, today: datetime.date) -> bool:
        if not os.path.exists(self.state_file):
            return False
        try:
            with open(self.state_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data.get("date") != today.isoformat():
                return False
            self.current_date = today
            self.active_symbol = data.get("active_symbol") or get_current_front_month_code(config.symbol_base)
            self.anchor_price = data.get("anchor_price")
            self.trades_executed_today = int(data.get("trades_executed_today", 0))
            self.bloc_a_executed_today = int(data.get("bloc_a_executed_today", 0))
            self.bloc_b_executed_today = int(data.get("bloc_b_executed_today", 0))
            self.breakevens_triggered_today = int(data.get("breakevens_triggered_today", 0))
            self.signal_history_today = list(data.get("signal_history_today", []))
            self.last_signal_info = self.signal_history_today[-1] if self.signal_history_today else data.get("last_signal_info")
            self.eod_cleaned = bool(data.get("eod_cleaned", False))
            logger.info(
                f"♻️ LiveSniperEngine: Estat restaurat per a {today} "
                f"({self.trades_executed_today} trades, {self.breakevens_triggered_today} BE)"
            )
            return True
        except Exception as e:
            logger.warning(f"No s'ha pogut carregar l'estat diari de LiveSniperEngine: {e}")
            return False

    def reset_day(self, today: datetime.date, reload_state: bool = False):
        if reload_state and self._load_daily_state_if_today(today):
            return
        self.current_date = today
        self.active_symbol = get_current_front_month_code(config.symbol_base)
        self.anchor_price = None
        self.trades_executed_today = 0
        self.bloc_a_executed_today = 0
        self.bloc_b_executed_today = 0
        self.breakevens_triggered_today = 0
        self.last_signal_info = None
        self.signal_history_today = []
        self.eod_cleaned = False
        self._save_daily_state()
        logger.info(f"🔄 LiveSniperEngine: Estat diari reiniciat per a {today}")

    def record_trade_execution(self, payload: Dict[str, Any], qty: int, tp_price: float, sl_price: float, order_id: Any):
        today_madrid = datetime.datetime.now(self.tz_madrid).date()
        if self.current_date != today_madrid:
            self.reset_day(today_madrid, reload_state=True)
            self.current_date = today_madrid

        strat = str(payload.get("strategy", "JJ_Layer_Sniper_ComboElite"))
        self.trades_executed_today += 1
        if "bloca" in strat.lower() or "bloc_a" in strat.lower():
            self.bloc_a_executed_today += 1
        elif "blocb" in strat.lower() or "bloc_b" in strat.lower() or "cont" in strat.lower():
            self.bloc_b_executed_today += 1
        elif self.trades_executed_today == 1:
            self.bloc_a_executed_today += 1
        else:
            self.bloc_b_executed_today += 1

        if payload.get("anchor_price") is not None:
            try:
                self.anchor_price = float(payload["anchor_price"])
            except (TypeError, ValueError):
                pass

        now_ny = datetime.datetime.now(self.tz_ny)
        entry_info = {
            "time_ny": now_ny.strftime("%H:%M:%S"),
            "strategy": strat,
            "slot": payload.get("slot", "LAYER"),
            "mode": payload.get("mode", "FAR"),
            "action": payload.get("action"),
            "price": payload.get("price"),
            "tp_price": tp_price,
            "sl_price": sl_price,
            "initial_sl_price": sl_price,
            "qty": qty,
            "order_id": order_id,
            "be_applied": False,
            "outcome": None,
        }
        self.last_signal_info = entry_info
        self.signal_history_today.append(entry_info)
        self._save_daily_state()

    def record_breakeven(self, be_price: float):
        self.breakevens_triggered_today += 1
        if self.last_signal_info:
            self.last_signal_info["be_applied"] = True
            self.last_signal_info["sl_price"] = be_price
            if self.signal_history_today:
                self.signal_history_today[-1]["be_applied"] = True
                self.signal_history_today[-1]["sl_price"] = be_price
        self._save_daily_state()

    def record_trade_exit(self, exit_price: Optional[float] = None, outcome: Optional[str] = None):
        if not self.last_signal_info:
            return
        now_ny = datetime.datetime.now(self.tz_ny)
        self.last_signal_info["exit_time_ny"] = now_ny.strftime("%H:%M:%S")
        if exit_price is not None:
            self.last_signal_info["exit_price"] = exit_price
        if outcome:
            self.last_signal_info["outcome"] = outcome.upper()
        if self.signal_history_today:
            self.signal_history_today[-1].update(self.last_signal_info)
        self._save_daily_state()

    def tick(self, now_madrid: datetime.datetime):
        today = now_madrid.date()
        if self.current_date != today:
            self.reset_day(today, reload_state=True)


live_unified_engine = LiveSniperEngine()
