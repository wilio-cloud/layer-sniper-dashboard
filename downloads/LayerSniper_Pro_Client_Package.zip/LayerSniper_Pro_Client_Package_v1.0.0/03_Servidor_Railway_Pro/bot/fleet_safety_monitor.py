"""
Fleet Safety Pack — Monitor Passiu de Flota Prop Firm i Alertes Privades
========================================================================
Mòdul 100% passiu (zero interacció amb ordres, lotatge ni enrutament) que rep
instantànies de només lectura dels comptes connectats a NinjaTrader 8 i avalua
les 4 fites accionables per al canal privat (`DISCORD_WEBHOOK_URL_PRIVATE_ALERTS`):

  1. 🎉 EVAL APROVADA: L'avaluació arriba a l'objectiu (`$53,000` en `50K` / `$159,000` en `150K`).
  2. 💵 MÍNIM PAYOUT DISPONIBLE (`$52,600` Lucid `50K` / `$53,100` Apex `50K`) i
     🏦 ZONA COFRE D'ACUMULACIÓ (`$55,500` en `50K` / `$160,500` en `150K`, configurable).
  3. 💥 COMPTE LIQUIDAT (REPOSICIÓ): El saldo toca o cau sota el MLL (`coixí <= $0`).
     (Fidel al backtest 1s: mai es redueix ràtio per coixí baix; només s'avisa si es liquida.)
  4. ⏰ AVÍS ANTI-CADUCITAT (INACTIVITAT): `>= 12 dies` sense trades a `Apex` (abans del
     Dia 15 Dormant) i `>= 22 dies` a `Lucid` / resta (abans de l'esborrat del Dia 30).
"""

import os
import re
import json
import datetime
import logging
import threading
from typing import Dict, Any, List, Optional, Tuple

logger = logging.getLogger("FleetSafetyMonitor")

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_ALERTS_STATE_PATH = os.path.join(ROOT_DIR, "config", "fleet_alerts_state.json")
DEFAULT_LATEST_SNAPSHOT_PATH = os.path.join(ROOT_DIR, "config", "fleet_latest_snapshot.json")

_STATE_LOCK = threading.Lock()


def is_monitored_prop_account(account_name: Optional[str]) -> bool:
    """Retorna True per a comptes Prop Firm reals/avaluació i descarta comptes simulats interns (`Sim*`, `Playback*`)."""
    clean = str(account_name or "").strip()
    if not clean:
        return False
    upper = clean.upper()
    if upper.startswith(("SIM", "PLAYBACK", "BACKTEST")):
        return False
    return True


def format_account_label(account_name: str) -> str:
    """Formata un identificador llarg (ex: `PAAPEX000100000099` -> `PAAPEX...0099`) per lectura ràpida al mòbil."""
    clean = str(account_name or "").strip()
    if len(clean) <= 13:
        return clean
    return f"{clean[:6]}...{clean[-4:]}"


def _infer_size_k(upper_name: str, balance: float, explicit_size_k: Optional[int] = None) -> int:
    if explicit_size_k in (25, 50, 100, 150, 250, 300):
        return int(explicit_size_k)

    # 1. Etiqueta explícita com 50K / 100K / 150K (aïllada de dígits adjacents)
    m_k = re.search(r"(?:^|[^0-9])(25|50|100|150)K(?:$|[^A-Z0-9])", upper_name)
    if m_k:
        return int(m_k.group(1))

    # 2. Prefix estàndard Lucid de 3 lletres + 3 dígits de mida (025 / 050 / 100 / 150)
    m_lucid = re.match(r"^(?:LDI|LDE|LLD|LDD|LDF|LDP)(\d{3})", upper_name)
    if m_lucid:
        code_k = int(m_lucid.group(1))
        if code_k in (25, 50, 100, 150):
            return code_k

    # 3. Inferència neta pel rang de saldo (evita falsos positius amb números de sèrie interns com 100 dins d'un ID)
    if balance >= 125000.0:
        return 150
    if balance >= 80000.0:
        return 100
    if balance >= 38000.0:
        return 50
    return 25


def classify_prop_account(
    acct: Dict[str, Any],
    vault_target_50k: float = 55500.0,
    vault_target_100k: float = 108500.0,
    vault_target_150k: float = 160500.0,
    prev_peak_balance: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Classifica firmat, fase (`EVAL` / `FUNDED`), mida (`50K` / `100K` / `150K`) i llindars
    exactes d'avaluació, payout, cofre, MLL i caducitat d'un compte connectat a NT8.
    """
    raw_name = str(acct.get("name") or acct.get("account") or "").strip()
    upper = raw_name.upper()
    balance = float(acct.get("cash_value") if acct.get("cash_value") is not None else acct.get("balance", 0.0))

    # Firma
    explicit_firm = str(acct.get("firm") or "").strip().upper()
    if explicit_firm:
        firm = explicit_firm
    elif "APEX" in upper:
        firm = "APEX"
    elif re.match(r"^(?:LD[A-Z]|LLD|LUCID)", upper):
        firm = "LUCID"
    elif "TPT" in upper or "TAKEPROFIT" in upper:
        firm = "TPT"
    elif "ALPHA" in upper:
        firm = "ALPHA"
    elif "TRADEIFY" in upper or "TDY" in upper:
        firm = "TRADEIFY"
    elif "PHIDIAS" in upper:
        firm = "PHIDIAS"
    else:
        firm = "GENERIC"

    # Fase (EVAL vs FUNDED)
    explicit_phase = str(acct.get("phase") or "").strip().upper()
    if explicit_phase in ("EVAL", "FUNDED"):
        phase = explicit_phase
    elif (
        upper.startswith(("PAAPEX", "PA-", "PA_", "LLD", "LDD", "LDF", "LDP", "LDPA"))
        or "_PA" in upper
        or "FUNDED" in upper
        or "MASTER" in upper
    ):
        phase = "FUNDED"
    elif (
        upper.startswith(("LDI", "LDE"))
        or (upper.startswith("APEX") and not upper.startswith("PAAPEX"))
        or any(tok in upper for tok in ("EVAL", "CHALLENGE", "COMBINE", "TEST"))
    ):
        phase = "EVAL"
    else:
        phase = "FUNDED"

    explicit_size = int(acct["size_k"]) if acct.get("size_k") is not None else None
    size_k = _infer_size_k(upper, balance, explicit_size)
    initial_balance = float(acct.get("initial_balance") or (size_k * 1000.0))

    # Paràmetres per mida i firma
    if size_k == 150:
        eval_target = float(acct.get("eval_target") or 159000.0)
        max_dd_amount = 5000.0 if firm == "APEX" else 4500.0
        min_payout_balance = 155600.0 if firm == "APEX" else 155100.0
        vault_target_balance = float(acct.get("vault_target") or vault_target_150k)
    elif size_k == 100:
        eval_target = float(acct.get("eval_target") or 106000.0)
        max_dd_amount = 3000.0
        min_payout_balance = 103600.0
        vault_target_balance = float(acct.get("vault_target") or vault_target_100k)
    elif size_k == 25:
        eval_target = float(acct.get("eval_target") or 26500.0)
        max_dd_amount = 1500.0 if firm == "APEX" else 1000.0
        min_payout_balance = 26600.0 if firm == "APEX" else 26350.0
        vault_target_balance = float(acct.get("vault_target") or 28500.0)
    else:
        # 50K estàndard de flota
        eval_target = float(acct.get("eval_target") or 53000.0)
        max_dd_amount = 2500.0 if firm == "APEX" else 2000.0
        min_payout_balance = 53100.0 if firm == "APEX" else 52600.0
        vault_target_balance = float(acct.get("vault_target") or vault_target_50k)

    if acct.get("min_payout_balance") is not None:
        min_payout_balance = float(acct["min_payout_balance"])

    peak_balance = max(initial_balance, balance, float(prev_peak_balance or 0.0), float(acct.get("peak_balance") or 0.0))
    base_floor = initial_balance - max_dd_amount
    lock_ceiling = initial_balance + 100.0
    inferred_mll = max(base_floor, min(lock_ceiling, peak_balance - max_dd_amount))

    # Si NinjaTrader o el test aporta un mll_floor explícit, un nivell AutoLiq (>= 70% saldo inicial),
    # o bé el coixí restant real de Tradovate (`0 < trailing_max_dd <= max_dd_amount`), l'integrem respectant el sostre de congelació ($50,100).
    raw_tdd = acct.get("trailing_max_dd")
    explicit_mll = acct.get("mll_floor")
    if explicit_mll is not None:
        mll_floor = float(explicit_mll)
    elif raw_tdd is not None and float(raw_tdd) >= initial_balance * 0.70:
        mll_floor = float(raw_tdd)
    elif raw_tdd is not None and 0.0 < float(raw_tdd) <= (max_dd_amount + 1.0) and balance > initial_balance - max_dd_amount:
        tdd_implied_mll = min(lock_ceiling, balance - float(raw_tdd))
        mll_floor = max(inferred_mll, tdd_implied_mll)
    else:
        mll_floor = inferred_mll

    if acct.get("remaining_cushion") is not None:
        cushion = float(acct["remaining_cushion"])
        mll_floor = balance - cushion
    else:
        cushion = round(balance - mll_floor, 2)

    inactivity_warn_days = 12 if firm == "APEX" else 22
    inactivity_hard_days = 15 if firm == "APEX" else 30

    return {
        "name": raw_name,
        "label": format_account_label(raw_name),
        "firm": firm,
        "phase": phase,
        "size_k": size_k,
        "initial_balance": initial_balance,
        "balance": round(balance, 2),
        "realized_pnl_today": round(float(acct.get("realized_pnl") or 0.0), 2),
        "peak_balance": round(peak_balance, 2),
        "mll_floor": round(mll_floor, 2),
        "cushion": cushion,
        "eval_target": eval_target,
        "min_payout_balance": min_payout_balance,
        "vault_target_balance": vault_target_balance,
        "inactivity_warn_days": inactivity_warn_days,
        "inactivity_hard_days": inactivity_hard_days,
        "liquidated_flag": bool(acct.get("liquidated", False)) or str(acct.get("status") or "").upper() == "LIQUIDATED",
    }


def _parse_iso_utc(ts_str: Optional[str]) -> Optional[datetime.datetime]:
    if not ts_str or not str(ts_str).strip():
        return None
    clean = str(ts_str).strip()
    if clean.endswith("Z"):
        clean = clean[:-1] + "+00:00"
    try:
        dt = datetime.datetime.fromisoformat(clean)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=datetime.timezone.utc)
        return dt.astimezone(datetime.timezone.utc)
    except ValueError:
        return None


def load_fleet_alerts_state(state_path: Optional[str] = None) -> Dict[str, Any]:
    path = state_path or DEFAULT_ALERTS_STATE_PATH
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                data.setdefault("accounts", {})
                return data
        except Exception as e:
            logger.warning(f"No s'ha pogut llegir {path}: {e}")
    return {"updated_at": None, "accounts": {}}


def save_fleet_alerts_state(state: Dict[str, Any], state_path: Optional[str] = None) -> None:
    target = state_path or DEFAULT_ALERTS_STATE_PATH
    if target == DEFAULT_ALERTS_STATE_PATH and os.environ.get("PYTEST_CURRENT_TEST"):
        return
    os.makedirs(os.path.dirname(target), exist_ok=True)
    tmp_path = f"{target}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)
    os.replace(tmp_path, target)


def save_latest_fleet_snapshot(snapshot: Dict[str, Any], snapshot_path: Optional[str] = None) -> None:
    target = snapshot_path or DEFAULT_LATEST_SNAPSHOT_PATH
    if target == DEFAULT_LATEST_SNAPSHOT_PATH and os.environ.get("PYTEST_CURRENT_TEST"):
        return
    os.makedirs(os.path.dirname(target), exist_ok=True)
    tmp_path = f"{target}.tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(snapshot, f, indent=2, ensure_ascii=False)
    os.replace(tmp_path, target)


def load_latest_fleet_snapshot(snapshot_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    target = snapshot_path or DEFAULT_LATEST_SNAPSHOT_PATH
    if not os.path.isfile(target):
        return None
    try:
        with open(target, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def evaluate_fleet_snapshot(
    snapshot: Dict[str, Any],
    now_utc: Optional[datetime.datetime] = None,
    state_path: Optional[str] = None,
    snapshot_cache_path: Optional[str] = None,
    vault_target_50k: Optional[float] = None,
    vault_target_100k: Optional[float] = None,
    vault_target_150k: Optional[float] = None,
) -> Dict[str, Any]:
    """
    Avalua una instantània de comptes procedent de `LayerSniperFleetMonitorAddOn.cs` i retorna:
      - `alerts`: llista d'alertes noves (`title`, `message`, `color`, `fields`, `code`, `account`)
      - `classified_accounts`: llista de comptes classificats amb saldo, MLL, coixí i inactivitat
    """
    if vault_target_50k is None or vault_target_100k is None or vault_target_150k is None:
        try:
            from bot.config import config as _cfg
            vt50 = float(vault_target_50k if vault_target_50k is not None else getattr(_cfg, "fleet_vault_target_50k", 55500.0))
            vt100 = float(vault_target_100k if vault_target_100k is not None else getattr(_cfg, "fleet_vault_target_100k", 108500.0))
            vt150 = float(vault_target_150k if vault_target_150k is not None else getattr(_cfg, "fleet_vault_target_150k", 160500.0))
        except Exception:
            vt50 = float(vault_target_50k or 55500.0)
            vt100 = float(vault_target_100k or 108500.0)
            vt150 = float(vault_target_150k or 160500.0)
    else:
        vt50, vt100, vt150 = float(vault_target_50k), float(vault_target_100k), float(vault_target_150k)

    now = now_utc or datetime.datetime.now(datetime.timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=datetime.timezone.utc)
    today_str = now.date().isoformat()

    raw_accounts = snapshot.get("accounts") or []
    alerts: List[Dict[str, Any]] = []
    classified_list: List[Dict[str, Any]] = []

    with _STATE_LOCK:
        state = load_fleet_alerts_state(state_path=state_path)
        acct_states: Dict[str, Any] = state.setdefault("accounts", {})

        for raw_acct in raw_accounts:
            if not isinstance(raw_acct, dict):
                continue
            name = str(raw_acct.get("name") or raw_acct.get("account") or "").strip()
            if not is_monitored_prop_account(name):
                continue

            st_entry: Dict[str, Any] = acct_states.setdefault(name, {
                "peak_balance": 0.0,
                "last_balance": None,
                "last_activity_utc": None,
                "active_milestones": {},
                "last_inactivity_alert_date": None,
            })
            active_ms: Dict[str, str] = st_entry.setdefault("active_milestones", {})

            info = classify_prop_account(
                raw_acct,
                vault_target_50k=vt50,
                vault_target_100k=vt100,
                vault_target_150k=vt150,
                prev_peak_balance=st_entry.get("peak_balance"),
            )
            bal = info["balance"]
            st_entry["peak_balance"] = info["peak_balance"]

            # Seguiment d'última activitat operativa per a l'avís anti-caducitat
            explicit_days_inactive = raw_acct.get("days_inactive")
            explicit_last_trade = _parse_iso_utc(raw_acct.get("last_trade_utc"))
            prev_bal = st_entry.get("last_balance")
            balance_moved = (prev_bal is not None and abs(bal - float(prev_bal)) >= 1.0)
            had_pnl_today = abs(info["realized_pnl_today"]) >= 0.50
            st_entry["last_balance"] = bal

            if explicit_last_trade is not None:
                prev_act = _parse_iso_utc(st_entry.get("last_activity_utc"))
                if prev_act is None or explicit_last_trade > prev_act:
                    st_entry["last_activity_utc"] = explicit_last_trade.isoformat()
            elif balance_moved or had_pnl_today:
                st_entry["last_activity_utc"] = now.isoformat()
            elif not st_entry.get("last_activity_utc"):
                st_entry["last_activity_utc"] = now.isoformat()

            if explicit_days_inactive is not None:
                days_inactive = max(0, int(explicit_days_inactive))
            else:
                act_dt = _parse_iso_utc(st_entry.get("last_activity_utc")) or now
                days_inactive = max(0, int((now - act_dt).total_seconds() // 86400))

            info["days_inactive"] = days_inactive
            classified_list.append(info)

            # -----------------------------------------------------------------
            # 1) 💥 COMPTE LIQUIDAT (REPOSICIÓ) — Coixí <= $0 (sense avisos intermedis de coixí baix)
            # -----------------------------------------------------------------
            is_liquidated = info["liquidated_flag"] or (info["cushion"] <= 0.0)
            if is_liquidated:
                if "ACCOUNT_LIQUIDATED" not in active_ms:
                    active_ms["ACCOUNT_LIQUIDATED"] = today_str
                    alerts.append({
                        "code": "ACCOUNT_LIQUIDATED",
                        "account": name,
                        "title": f"💥 COMPTE LIQUIDAT (REPOSICIÓ): {info['label']}",
                        "message": (
                            f"🛑 El compte **`{name}`** (`{info['firm']} {info['size_k']}K {info['phase']}`) ha tocat el seu límit de pèrdua màxima (`MLL`).\n\n"
                            f"• **Saldo actual**: `${bal:,.2f}` | **Sòl MLL**: `${info['mll_floor']:,.2f}`\n"
                            "👉 **Acció de contingència (2 min):** Desmarca aquest compte a Replikanto i, quan tinguis un minut, connecta un compte de reposició."
                        ),
                        "color": "danger",
                        "fields": {
                            "Compte": f"`{info['label']}`",
                            "Fase / Mida": f"{info['firm']} {info['size_k']}K ({info['phase']})",
                            "Saldo / MLL": f"${bal:,.2f} / ${info['mll_floor']:,.2f}",
                        },
                    })
                # Un compte liquidat no pot disparar fites d'aprovació ni payout
                continue
            else:
                if info["cushion"] > 150.0:
                    active_ms.pop("ACCOUNT_LIQUIDATED", None)

            # -----------------------------------------------------------------
            # 2) 🎉 EVAL APROVADA
            # -----------------------------------------------------------------
            if info["phase"] == "EVAL":
                if bal >= info["eval_target"]:
                    if "EVAL_PASSED" not in active_ms:
                        active_ms["EVAL_PASSED"] = today_str
                        alerts.append({
                            "code": "EVAL_PASSED",
                            "account": name,
                            "title": f"🎉 EVAL APROVADA: {info['label']} (${bal:,.2f})",
                            "message": (
                                f"🏆 El compte d'avaluació **`{name}`** (`{info['firm']} {info['size_k']}K`) ha superat l'objectiu de `${info['eval_target']:,.0f}`!\n\n"
                                "👉 **Acció de contingència (2 min):**\n"
                                "1️⃣ Desmarca l'`Eval` a Replikanto perquè no faci cap més operació.\n"
                                "2️⃣ Activa el pas a **Funded** al portal de la Prop Firm i marca el nou compte Funded a Replikanto."
                            ),
                            "color": "green",
                            "fields": {
                                "Compte": f"`{info['label']}`",
                                "Saldo Final": f"${bal:,.2f}",
                                "Objectiu Eval": f"${info['eval_target']:,.0f}",
                            },
                        })
                elif bal < info["eval_target"] - 100.0:
                    active_ms.pop("EVAL_PASSED", None)

            # -----------------------------------------------------------------
            # 3) 💵 MÍNIM PAYOUT DISPONIBLE i 🏦 ZONA COFRE (FUNDED)
            # -----------------------------------------------------------------
            if info["phase"] == "FUNDED":
                # 3a. Zona Cofre / Acumulació (prioritat superior: si entra directe al Cofre o hi arriba després)
                if bal >= info["vault_target_balance"]:
                    if "VAULT_TARGET_REACHED" not in active_ms:
                        active_ms["VAULT_TARGET_REACHED"] = today_str
                        active_ms.setdefault("MIN_PAYOUT_READY", today_str)
                        withdrawable = max(0.0, bal - (info["min_payout_balance"] - 500.0))
                        alerts.append({
                            "code": "VAULT_TARGET_REACHED",
                            "account": name,
                            "title": f"🏦 ZONA COFRE ASSOLIDA: {info['label']} (${bal:,.2f})",
                            "message": (
                                f"💎 El compte Funded **`{name}`** (`{info['firm']} {info['size_k']}K`) ha assolit el llindar de **Cofre (`${info['vault_target_balance']:,.0f}`)**!\n\n"
                                f"• **Excedent net sobre buffer**: `~${withdrawable:,.2f}`\n"
                                "👉 **Opcions d'actuació:**\n"
                                "• **Operativa normal:** Demana retirada del benefici excedent (*Withdraw ASAP*).\n"
                                "• **En període de baixa / absència:** Desmarca aquest compte a Replikanto (o baixa'l a `Ratio 0.1`) per **congelar el benefici al 100% sense facturar** fins a la data de cobrament."
                            ),
                            "color": "green",
                            "fields": {
                                "Compte": f"`{info['label']}`",
                                "Saldo Cofre": f"${bal:,.2f}",
                                "Excedent Buffer": f"+${withdrawable:,.2f}",
                            },
                        })
                else:
                    if bal < info["vault_target_balance"] - 200.0:
                        active_ms.pop("VAULT_TARGET_REACHED", None)

                    if bal >= info["min_payout_balance"]:
                        if "MIN_PAYOUT_READY" not in active_ms:
                            active_ms["MIN_PAYOUT_READY"] = today_str
                            withdrawable = max(0.0, bal - (info["min_payout_balance"] - 500.0))
                            alerts.append({
                                "code": "MIN_PAYOUT_READY",
                                "account": name,
                                "title": f"💵 MÍNIM PAYOUT DISPONIBLE: {info['label']} (${bal:,.2f})",
                                "message": (
                                    f"💵 El compte Funded **`{name}`** (`{info['firm']} {info['size_k']}K`) ja supera el buffer intocable + mínim de retirada (`${info['min_payout_balance']:,.0f}`).\n\n"
                                    f"• **Disponible sobre buffer**: `${withdrawable:,.2f}` | **Coixí MLL**: `${info['cushion']:,.2f}`\n"
                                    f"👉 Pots retirar ara (*Withdraw ASAP*) o deixar-lo córrer fins a la **Zona Cofre (`${info['vault_target_balance']:,.0f}`)**."
                                ),
                                "color": "blue",
                                "fields": {
                                    "Compte": f"`{info['label']}`",
                                    "Saldo Actual": f"${bal:,.2f}",
                                    "Sobre Buffer": f"+${withdrawable:,.2f}",
                                },
                            })
                    elif bal < info["min_payout_balance"] - 100.0:
                        active_ms.pop("MIN_PAYOUT_READY", None)

            # -----------------------------------------------------------------
            # 4) ⏰ AVÍS ANTI-CADUCITAT (INACTIVITAT)
            # -----------------------------------------------------------------
            if days_inactive >= info["inactivity_warn_days"]:
                if st_entry.get("last_inactivity_alert_date") != today_str:
                    st_entry["last_inactivity_alert_date"] = today_str
                    days_left = max(0, info["inactivity_hard_days"] - days_inactive)
                    alerts.append({
                        "code": "INACTIVITY_WARNING",
                        "account": name,
                        "title": f"⏰ AVÍS ANTI-CADUCITAT: {info['label']} ({days_inactive} dies inactiu)",
                        "message": (
                            f"⚠️ El compte **`{name}`** (`{info['firm']} {info['size_k']}K {info['phase']}`) porta **`{days_inactive} dies`** sense cap operació registrada.\n\n"
                            f"• **Límit normatiu `{info['firm']}`**: `{info['inactivity_hard_days']} dies` (falten **`{days_left} dies`**).\n"
                            "👉 Si el tens pausat expressament (ex: Cofre congelat), fes un micro-trade d'`1 MNQ` abans del límit per renovar 30 dies més de vigència."
                        ),
                        "color": "warning",
                        "fields": {
                            "Compte": f"`{info['label']}`",
                            "Dies sense trade": f"{days_inactive}d / {info['inactivity_hard_days']}d",
                            "Saldo": f"${bal:,.2f}",
                        },
                    })
            else:
                st_entry["last_inactivity_alert_date"] = None

        state["updated_at"] = now.isoformat()
        save_fleet_alerts_state(state, state_path=state_path)

    enriched_snapshot = {
        "captured_at": snapshot.get("captured_at") or now.isoformat(),
        "received_at": now.isoformat(),
        "accounts": classified_list,
    }
    save_latest_fleet_snapshot(enriched_snapshot, snapshot_path=snapshot_cache_path)

    return {
        "alerts": alerts,
        "classified_accounts": classified_list,
        "evaluated_at": now.isoformat(),
    }


def format_private_fleet_summary(
    classified_accounts: List[Dict[str, Any]],
    date_label: Optional[str] = None,
) -> Optional[Tuple[str, str, Dict[str, str]]]:
    """
    Construeix el quadre resum diari post-sessió (`12:35 NY`) per al canal privat.
    Retorna `(title, description, fields)` o `None` si no hi ha cap compte monitoritzat.
    """
    if not classified_accounts:
        return None

    d_lbl = date_label or datetime.date.today().isoformat()
    total_pnl = sum(float(a.get("realized_pnl_today") or 0.0) for a in classified_accounts)
    funded_cnt = sum(1 for a in classified_accounts if a.get("phase") == "FUNDED" and a.get("cushion", 1.0) > 0)
    eval_cnt = sum(1 for a in classified_accounts if a.get("phase") == "EVAL" and a.get("cushion", 1.0) > 0)
    liq_cnt = sum(1 for a in classified_accounts if a.get("cushion", 1.0) <= 0 or a.get("liquidated_flag"))

    rows: List[str] = [
        f"{'COMPTE':<15} {'FASE':<6} {'SALDO':>10} {'COIXÍ':>9} {'ESTAT'}",
        "-" * 54,
    ]
    for a in sorted(classified_accounts, key=lambda x: (x.get("phase") != "FUNDED", -float(x.get("balance", 0.0)))):
        lbl = str(a.get("label") or a.get("name"))[:15]
        ph = "FUND" if a.get("phase") == "FUNDED" else "EVAL"
        bal = float(a.get("balance", 0.0))
        cush = float(a.get("cushion", 0.0))
        if cush <= 0 or a.get("liquidated_flag"):
            st = "💥 LIQ"
        elif a.get("phase") == "EVAL" and bal >= float(a.get("eval_target", 53000.0)):
            st = "🎉 PASS"
        elif a.get("phase") == "FUNDED" and bal >= float(a.get("vault_target_balance", 55500.0)):
            st = "🏦 COFRE"
        elif a.get("phase") == "FUNDED" and bal >= float(a.get("min_payout_balance", 52600.0)):
            st = "💵 PAYOUT"
        elif int(a.get("days_inactive", 0)) >= int(a.get("inactivity_warn_days", 22)):
            st = f"⏰ {a.get('days_inactive')}d"
        else:
            st = "✅ OK"
        rows.append(f"{lbl:<15} {ph:<6} ${bal:>9,.0f} ${cush:>8,.0f} {st}")

    table_block = "```\n" + "\n".join(rows) + "\n```"
    pnl_sign = "+" if total_pnl >= 0 else ""
    title = f"📊 RESUM PRIVAT DE FLOTA ({d_lbl})"
    desc = (
        f"Quadre de tancament dels **{len(classified_accounts)} comptes** connectats a NinjaTrader 8:\n"
        f"{table_block}"
    )
    fields = {
        "💼 Flota Activa": f"{funded_cnt} Funded · {eval_cnt} Eval" + (f" · {liq_cnt} Liq" if liq_cnt else ""),
        "📈 P&L Realitzat Avui": f"{pnl_sign}${total_pnl:,.2f}",
    }
    return title, desc, fields
