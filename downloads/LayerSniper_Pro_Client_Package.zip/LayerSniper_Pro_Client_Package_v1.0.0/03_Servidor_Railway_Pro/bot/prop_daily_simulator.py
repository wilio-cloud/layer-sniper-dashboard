"""
Motor de Simulació Diària en Viu per a Prop Firms (50K @ 10 MNQ & 150K @ 30 MNQ).
Rastreja dia a dia des de l'inici d'execució (Dilluns 19/10/2026) què hauria passat
exactament en 6 comptes simultanis:
  1) LucidDaily 50K (10 MNQ · Intraday 1s MFE · $2,000 DD · Payout Diari ASAP)
  2) Apex 3.0 50K   (10 MNQ · Intraday 1s MFE · $2,500 DD · Cicle 8d/5d W)
  3) Estàndard EOD 50K (10 MNQ · EOD Trailing · $2,000 DD · Sense erosió en BE)
  4) LucidDaily 150K (30 MNQ · Intraday 1s MFE · $4,500 DD · Payout Diari ASAP)
  5) Apex 3.0 150K   (30 MNQ · Intraday 1s MFE · $5,000 DD · Cicle 8d/5d W)
  6) Estàndard EOD 150K (30 MNQ · EOD Trailing · $4,500 DD · Sense erosió en BE)

Inclou:
- Comissions reals per contracte Round-Turn ($1.24/MNQ -> -$12.40 a 10 MNQ / -$37.20 a 30 MNQ).
- Erosió real del Trailing Drawdown Intraday durant els Breakevens i SLs (segons el pic MFE 1s).
- Detecció automàtica de:
    * Drawdown tocat (MLL) -> Compra de compte nou i registre de despesa.
    * Límit de pèrdua diària (DLL) tocat.
    * Avaluació superada (Eval -> Funded PA) i cost d'activació.
    * Elegibilitat i cobrament de Payouts (amb split 90% o 100% i buffer obligatori).
"""

import os
import json
import datetime
import logging
from typing import Dict, Any, List, Optional, Tuple
from bot.config import config

logger = logging.getLogger("PropDailySimulator")

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_START_DATE = "2026-10-19"
_DEFAULT_STATE_FILE_PATH = os.path.join(ROOT_DIR, "config", "prop_live_simulation_state.json")
STATE_FILE_PATH = _DEFAULT_STATE_FILE_PATH
WEEKLY_SIGNALS_CACHE = os.path.join(ROOT_DIR, "config", "live_week_signals_cache.json")

COMMISSION_RT_PER_MNQ = 1.24  # $1.24 USD Round-Turn All-In per contracte MNQ
POINT_VALUE_MNQ = 2.0         # $2.00 USD per punt d'MNQ

DAYS_CATALAN = {
    0: "Dilluns",
    1: "Dimarts",
    2: "Dimecres",
    3: "Dijous",
    4: "Divendres",
    5: "Dissabte",
    6: "Diumenge"
}

ACCOUNT_PROFILES: List[Dict[str, Any]] = [
    # --- BLOC 50K (10 MNQ = $20/punt | Comissió -$12.40/bala) ---
    {
        "profile_id": "LUCID_50K",
        "label": "LucidDaily 50K (Intraday)",
        "short_label": "LucidDaily 50K",
        "group": "50K",
        "contracts": 10,
        "start_balance": 50000.0,
        "eval_target_balance": 53000.0,
        "max_dd": 2000.0,
        "dll": 1200.0,
        "dll_is_soft_lock": True,
        "trailing_type": "INTRADAY_1S_MFE",
        "lock_mll_eval": 50100.0,
        "lock_mll_funded": 50100.0,
        "eval_cost": 56.40,
        "activation_fee": 0.0,
        "payout_mode": "DAILY_BUFFER",
        "funded_buffer_balance": 52100.0,
        "min_payout_withdrawal": 500.0,
        "payout_cap": 8000.0,
        "payout_split": 0.90,
        "min_days_for_payout": 1,
        "min_win_days_for_payout": 1,
        "win_day_threshold": 50.0,
    },
    {
        "profile_id": "APEX_50K",
        "label": "Apex 3.0 50K (Intraday +DD)",
        "short_label": "Apex 3.0 50K",
        "group": "50K",
        "contracts": 10,
        "start_balance": 50000.0,
        "eval_target_balance": 53000.0,
        "max_dd": 2500.0,
        "dll": None,
        "dll_is_soft_lock": False,
        "trailing_type": "INTRADAY_1S_MFE",
        "lock_mll_eval": 50100.0,
        "lock_mll_funded": 50100.0,
        "eval_cost": 35.00,
        "activation_fee": 125.0,
        "payout_mode": "CYCLE_8D_5W",
        "funded_buffer_balance": 52600.0,
        "min_payout_withdrawal": 500.0,
        "payout_cap": 2000.0,
        "payout_split": 1.00,
        "min_days_for_payout": 8,
        "min_win_days_for_payout": 5,
        "win_day_threshold": 50.0,
    },
    {
        "profile_id": "EOD_50K",
        "label": "Estàndard EOD 50K (Topstep/Alpha)",
        "short_label": "Estàndard EOD 50K",
        "group": "50K",
        "contracts": 10,
        "start_balance": 50000.0,
        "eval_target_balance": 53000.0,
        "max_dd": 2000.0,
        "dll": 1000.0,
        "dll_is_soft_lock": True,
        "trailing_type": "EOD",
        "lock_mll_eval": 50100.0,
        "lock_mll_funded": 50100.0,
        "eval_cost": 49.00,
        "activation_fee": 149.0,
        "payout_mode": "CYCLE_5W",
        "funded_buffer_balance": 52100.0,
        "min_payout_withdrawal": 500.0,
        "payout_cap": 2000.0,
        "payout_split": 0.90,
        "min_days_for_payout": 5,
        "min_win_days_for_payout": 5,
        "win_day_threshold": 150.0,
    },

    # --- BLOC 150K (30 MNQ = $60/punt | Comissió -$37.20/bala) ---
    {
        "profile_id": "LUCID_150K",
        "label": "LucidDaily 150K (Intraday)",
        "short_label": "LucidDaily 150K",
        "group": "150K",
        "contracts": 30,
        "start_balance": 150000.0,
        "eval_target_balance": 159000.0,
        "max_dd": 4500.0,
        "dll": 2700.0,
        "dll_is_soft_lock": True,
        "trailing_type": "INTRADAY_1S_MFE",
        "lock_mll_eval": 150100.0,
        "lock_mll_funded": 150100.0,
        "eval_cost": 137.40,
        "activation_fee": 0.0,
        "payout_mode": "DAILY_BUFFER",
        "funded_buffer_balance": 154600.0,
        "min_payout_withdrawal": 500.0,
        "payout_cap": 12000.0,
        "payout_split": 0.90,
        "min_days_for_payout": 1,
        "min_win_days_for_payout": 1,
        "win_day_threshold": 50.0,
    },
    {
        "profile_id": "APEX_150K",
        "label": "Apex 3.0 150K (Intraday +DD)",
        "short_label": "Apex 3.0 150K",
        "group": "150K",
        "contracts": 30,
        "start_balance": 150000.0,
        "eval_target_balance": 159000.0,
        "max_dd": 5000.0,
        "dll": None,
        "dll_is_soft_lock": False,
        "trailing_type": "INTRADAY_1S_MFE",
        "lock_mll_eval": 150100.0,
        "lock_mll_funded": 150100.0,
        "eval_cost": 40.00,
        "activation_fee": 105.0,
        "payout_mode": "CYCLE_8D_5W",
        "funded_buffer_balance": 155100.0,
        "min_payout_withdrawal": 500.0,
        "payout_cap": 3000.0,
        "payout_split": 1.00,
        "min_days_for_payout": 8,
        "min_win_days_for_payout": 5,
        "win_day_threshold": 50.0,
    },
    {
        "profile_id": "EOD_150K",
        "label": "Estàndard EOD 150K (Topstep/Alpha)",
        "short_label": "Estàndard EOD 150K",
        "group": "150K",
        "contracts": 30,
        "start_balance": 150000.0,
        "eval_target_balance": 159000.0,
        "max_dd": 4500.0,
        "dll": 3000.0,
        "dll_is_soft_lock": True,
        "trailing_type": "EOD",
        "lock_mll_eval": 150100.0,
        "lock_mll_funded": 150100.0,
        "eval_cost": 149.00,
        "activation_fee": 149.0,
        "payout_mode": "CYCLE_5W",
        "funded_buffer_balance": 154600.0,
        "min_payout_withdrawal": 500.0,
        "payout_cap": 5000.0,
        "payout_split": 0.90,
        "min_days_for_payout": 5,
        "min_win_days_for_payout": 5,
        "win_day_threshold": 150.0,
    },
]

PROFILES_BY_ID = {p["profile_id"]: p for p in ACCOUNT_PROFILES}


def _create_fresh_account_state(profile: Dict[str, Any], seq_num: int = 1, phase: str = "EVAL") -> Dict[str, Any]:
    start_bal = float(profile["start_balance"])
    max_dd = float(profile["max_dd"])
    prefix = "EV" if phase == "EVAL" else "PA"
    return {
        "profile_id": profile["profile_id"],
        "account_tag": f"{prefix}#{seq_num}",
        "seq_num": seq_num,
        "phase": phase,  # "EVAL" o "FUNDED"
        "balance": start_bal,
        "peak_balance": start_bal,
        "mll_floor": start_bal - max_dd,
        "mll_locked": False,
        "days_traded_in_phase": 0,
        "win_days_in_phase": 0,
        "total_evals_bought": 1 if seq_num == 1 and phase == "EVAL" else seq_num,
        "total_blown_evals": 0,
        "total_blown_funded": 0,
        "total_passed_evals": 0,
        "total_eval_fees_usd": float(profile["eval_cost"]) if phase == "EVAL" else 0.0,
        "total_activation_fees_usd": 0.0,
        "total_payouts_count": 0,
        "total_payouts_gross_usd": 0.0,
        "total_payouts_net_usd": 0.0,
        "last_day_events": [],
        "last_day_net_pnl": 0.0,
        "last_day_commissions": 0.0,
        "last_day_mfe_erosion": 0.0,
    }


def create_initial_simulation_state(start_date: str = "2026-10-19") -> Dict[str, Any]:
    accounts = {}
    for prof in ACCOUNT_PROFILES:
        accounts[prof["profile_id"]] = _create_fresh_account_state(prof, seq_num=1, phase="EVAL")
    return {
        "start_date": start_date,
        "last_processed_date": None,
        "sessions_count": 0,
        "accounts": accounts,
        "daily_history": []
    }


def load_simulation_state(path: Optional[str] = None) -> Dict[str, Any]:
    target_path = path or STATE_FILE_PATH
    if os.path.exists(target_path):
        try:
            with open(target_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"Error carregant estat de simulació: {e}")
    return create_initial_simulation_state()


def save_simulation_state(state: Dict[str, Any], path: Optional[str] = None) -> None:
    target_path = path or STATE_FILE_PATH
    if "PYTEST_CURRENT_TEST" in os.environ and os.path.abspath(target_path) == os.path.abspath(_DEFAULT_STATE_FILE_PATH):
        return
    os.makedirs(os.path.dirname(target_path), exist_ok=True)
    with open(target_path, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


def step_account_for_day(
    acc: Dict[str, Any],
    profile: Dict[str, Any],
    date_str: str,
    executed_trades: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Processa les bales del dia `date_str` sobre el compte `acc` seguint les regles exactes de `profile`.
    Retorna el resum detallat del que ha passat avui en aquest compte.
    """
    contracts = int(profile["contracts"])
    comm_per_trade = round(COMMISSION_RT_PER_MNQ * contracts, 2)
    start_bal = float(profile["start_balance"])
    max_dd = float(profile["max_dd"])
    dll = profile["dll"]
    is_intraday = (profile["trailing_type"] == "INTRADAY_1S_MFE")

    bal_start_of_day = float(acc["balance"])
    mll_start_of_day = float(acc["mll_floor"])
    phase_start_of_day = acc["phase"]
    tag_start_of_day = acc["account_tag"]

    day_gross_pnl = 0.0
    day_commissions = 0.0
    day_net_pnl = 0.0
    day_mfe_erosion = 0.0
    events_today: List[str] = []
    bullet_logs: List[Dict[str, Any]] = []

    dll_locked_today = False
    current_acc_traded_today = False
    current_acc_day_net_pnl = 0.0

    for t in executed_trades:
        if dll_locked_today:
            events_today.append(f"⏸️ Bala #{t['bullet_num']} omesa per bloqueig de Límit Diari (DLL)")
            break

        current_acc_traded_today = True
        pts = float(t["points"])
        mfe_pts = float(t.get("mfe_pts", max(0.0, pts)))
        outcome = t.get("outcome", "BE")
        slot = t.get("slot", "LAYER")

        gross_dlr = round(pts * POINT_VALUE_MNQ * contracts, 2)
        net_dlr = round(gross_dlr - comm_per_trade, 2)
        mfe_dlr = round(mfe_pts * POINT_VALUE_MNQ * contracts, 2)

        is_funded = (acc["phase"] == "FUNDED")
        lock_cap = float(profile["lock_mll_funded"] if is_funded else profile["lock_mll_eval"])

        mll_before_trade = float(acc["mll_floor"])

        # 1. En comptes Intraday Trailing: el pic d'equitat puja durant el trade amb el MFE d'1 segon!
        if is_intraday and mfe_dlr > 0:
            intra_peak = round(acc["balance"] + mfe_dlr, 2)
            if intra_peak > acc["peak_balance"]:
                acc["peak_balance"] = intra_peak
                new_mll = round(min(lock_cap, acc["peak_balance"] - max_dd), 2)
                if new_mll > acc["mll_floor"]:
                    acc["mll_floor"] = new_mll
                if acc["mll_floor"] >= lock_cap - 1e-6:
                    acc["mll_locked"] = True

        mll_after_mfe = float(acc["mll_floor"])
        mfe_floor_raise = round(mll_after_mfe - mll_before_trade, 2)

        # 2. Aplicar el resultat tancat i la comissió
        acc["balance"] = round(acc["balance"] + net_dlr, 2)
        day_gross_pnl = round(day_gross_pnl + gross_dlr, 2)
        day_commissions = round(day_commissions + comm_per_trade, 2)
        day_net_pnl = round(day_net_pnl + net_dlr, 2)
        current_acc_day_net_pnl = round(current_acc_day_net_pnl + net_dlr, 2)

        # Si és un BE o SL en Intraday i el MFE ha apujat el MLL sense guanyar el trade:
        if is_intraday and outcome in ("BE", "SL") and mfe_floor_raise > 0:
            day_mfe_erosion = round(day_mfe_erosion + mfe_floor_raise, 2)
            events_today.append(
                f"⚠️ Erosió Intraday a Bala #{t['bullet_num']} ({outcome}): el pic de +{mfe_pts:.1f}p (+${mfe_dlr:,.0f}) "
                f"ha pujat el terra MLL en +${mfe_floor_raise:,.2f} (fins a ${acc['mll_floor']:,.2f}) abans de girar!"
            )

        bullet_logs.append({
            "bullet_num": t["bullet_num"],
            "slot": slot,
            "outcome": outcome,
            "points": pts,
            "mfe_pts": mfe_pts,
            "gross_usd": gross_dlr,
            "commission_usd": comm_per_trade,
            "net_usd": net_dlr,
            "mll_raised_by_mfe_usd": mfe_floor_raise,
            "balance_after": acc["balance"],
            "mll_after": acc["mll_floor"],
        })

        # 3. Comprovar si hem tocat el Max Loss Limit (Drawdown MLL) -> COMPTE PETAT!
        hit_mll = acc["balance"] <= acc["mll_floor"] + 1e-6
        hit_hard_dll = (dll is not None) and (not profile.get("dll_is_soft_lock", True)) and (current_acc_day_net_pnl <= -float(dll) + 1e-6)

        if hit_mll or hit_hard_dll:
            blown_phase = acc["phase"]
            blown_tag = acc["account_tag"]
            blown_bal = acc["balance"]
            blown_mll = acc["mll_floor"]
            cause = "Drawdown MLL" if hit_mll else f"Límit Diari DLL (-${dll:,.0f})"

            if blown_phase == "FUNDED":
                acc["total_blown_funded"] += 1
            else:
                acc["total_blown_evals"] += 1

            new_seq = int(acc["seq_num"]) + 1
            eval_cost = float(profile["eval_cost"])
            acc["seq_num"] = new_seq
            acc["phase"] = "EVAL"
            acc["account_tag"] = f"EV#{new_seq}"
            acc["balance"] = start_bal
            acc["peak_balance"] = start_bal
            acc["mll_floor"] = start_bal - max_dd
            acc["mll_locked"] = False
            acc["days_traded_in_phase"] = 0
            acc["win_days_in_phase"] = 0
            acc["total_evals_bought"] += 1
            acc["total_eval_fees_usd"] = round(acc["total_eval_fees_usd"] + eval_cost, 2)

            current_acc_traded_today = False
            current_acc_day_net_pnl = 0.0

            events_today.append(
                f"💥 **DRAWNDOWN TOCAT ({blown_tag} PETAT per {cause}):** Saldo ${blown_bal:,.2f} <= Terra ${blown_mll:,.2f}. "
                f"🔄 **Comprat Compte Nou `{acc['account_tag']}`** (-${eval_cost:.2f}) reiniciat a ${start_bal:,.0f}."
            )
            break

        # 4. Comprovar Soft DLL (bloqueig per avui però compte viu)
        if dll is not None and profile.get("dll_is_soft_lock", True) and current_acc_day_net_pnl <= -float(dll) + 1e-6:
            dll_locked_today = True
            events_today.append(
                f"🛑 **Límit Diari (DLL -${dll:,.0f}) assolit:** Sessió aturada en aquest compte però sobreviu (Saldo ${acc['balance']:,.2f} > MLL ${acc['mll_floor']:,.2f})."
            )

    # --- TANCAMENT DE SESSIÓ (EOD) ---
    if current_acc_traded_today:
        is_funded = (acc["phase"] == "FUNDED")
        lock_cap = float(profile["lock_mll_funded"] if is_funded else profile["lock_mll_eval"])

        # En comptes EOD Trailing: el terra MLL només s'actualitza al final del dia segons el balanç net tancat!
        if not is_intraday:
            if acc["balance"] > acc["peak_balance"]:
                acc["peak_balance"] = acc["balance"]
                new_mll = round(min(lock_cap, acc["peak_balance"] - max_dd), 2)
                if new_mll > acc["mll_floor"]:
                    acc["mll_floor"] = new_mll
                if acc["mll_floor"] >= lock_cap - 1e-6:
                    acc["mll_locked"] = True

        acc["days_traded_in_phase"] += 1
        if current_acc_day_net_pnl >= float(profile["win_day_threshold"]):
            acc["win_days_in_phase"] += 1

        # A) Comprovar si acabem de PASSAR L'AVALUACIÓ (EVAL -> FUNDED PA)
        if not is_funded and acc["balance"] >= float(profile["eval_target_balance"]) - 1e-6:
            passed_tag = acc["account_tag"]
            passed_bal = acc["balance"]
            act_fee = float(profile["activation_fee"])

            acc["total_passed_evals"] += 1
            acc["total_activation_fees_usd"] = round(acc["total_activation_fees_usd"] + act_fee, 2)
            acc["phase"] = "FUNDED"
            acc["account_tag"] = f"PA#{acc['seq_num']}"
            acc["balance"] = start_bal
            acc["peak_balance"] = start_bal
            acc["mll_floor"] = start_bal - max_dd
            acc["mll_locked"] = False
            acc["days_traded_in_phase"] = 0
            acc["win_days_in_phase"] = 0

            fee_str = f"Quota Activació -${act_fee:.0f}" if act_fee > 0 else "Activació $0 GRATUÏTA"
            events_today.append(
                f"🎉 **COMPTE APROVAT AVUI (`{passed_tag}` amb ${passed_bal:,.2f} >= ${profile['eval_target_balance']:,.0f})!** "
                f"Passa a **FUNDED (`{acc['account_tag']}`)** ({fee_str})."
            )

        # B) Si ja estàvem en FUNDED: comprovar si podem DEMANAR PAYOUT avui mateix!
        elif is_funded:
            buf_bal = float(profile["funded_buffer_balance"])
            min_w = float(profile["min_payout_withdrawal"])
            withdrawable = round(acc["balance"] - buf_bal, 2)
            days_ok = acc["days_traded_in_phase"] >= int(profile["min_days_for_payout"])
            wins_ok = acc["win_days_in_phase"] >= int(profile["min_win_days_for_payout"])

            if days_ok and wins_ok and withdrawable >= min_w:
                gross_payout = round(min(float(profile["payout_cap"]), withdrawable), 2)
                net_payout = round(gross_payout * float(profile["payout_split"]), 2)
                acc["balance"] = round(acc["balance"] - gross_payout, 2)
                acc["total_payouts_count"] += 1
                acc["total_payouts_gross_usd"] = round(acc["total_payouts_gross_usd"] + gross_payout, 2)
                acc["total_payouts_net_usd"] = round(acc["total_payouts_net_usd"] + net_payout, 2)
                acc["days_traded_in_phase"] = 0
                acc["win_days_in_phase"] = 0

                events_today.append(
                    f"💰 **PAYOUT #{acc['total_payouts_count']} COBRAT AVUI:** Retirats **+${net_payout:,.2f} nets** "
                    f"(${gross_payout:,.2f} bruts al {int(profile['payout_split']*100)}%). Nou saldo PA: ${acc['balance']:,.2f}."
                )

    acc["last_day_events"] = events_today
    acc["last_day_net_pnl"] = day_net_pnl
    acc["last_day_commissions"] = day_commissions
    acc["last_day_mfe_erosion"] = day_mfe_erosion

    remaining_dd_buffer = round(acc["balance"] - acc["mll_floor"], 2)
    total_spend = round(acc["total_eval_fees_usd"] + acc["total_activation_fees_usd"], 2)
    net_cashflow = round(acc["total_payouts_net_usd"] - total_spend, 2)

    if acc["phase"] == "EVAL":
        dist_to_target = round(max(0.0, float(profile["eval_target_balance"]) - acc["balance"]), 2)
        goal_status_str = f"Falten **${dist_to_target:,.2f}** per aprovar Eval (${profile['eval_target_balance']:,.0f})"
    else:
        buf_bal = float(profile["funded_buffer_balance"])
        dist_to_payout_bal = round(max(0.0, (buf_bal + float(profile["min_payout_withdrawal"])) - acc["balance"]), 2)
        rem_days = max(0, int(profile["min_days_for_payout"]) - acc["days_traded_in_phase"])
        rem_wins = max(0, int(profile["min_win_days_for_payout"]) - acc["win_days_in_phase"])
        if dist_to_payout_bal == 0 and rem_days == 0 and rem_wins == 0:
            goal_status_str = "✅ **Llest per retirar Payout!**"
        else:
            parts = []
            if dist_to_payout_bal > 0:
                parts.append(f"+${dist_to_payout_bal:,.2f} sobre buffer")
            if rem_days > 0:
                parts.append(f"{rem_days}d operats")
            if rem_wins > 0:
                parts.append(f"{rem_wins}d verds")
            goal_status_str = "Payout: falten " + " + ".join(parts)

    return {
        "profile_id": profile["profile_id"],
        "label": profile["label"],
        "short_label": profile["short_label"],
        "group": profile["group"],
        "contracts": contracts,
        "trailing_type": profile["trailing_type"],
        "account_tag": acc["account_tag"],
        "phase": acc["phase"],
        "balance_start": bal_start_of_day,
        "balance_end": acc["balance"],
        "peak_balance": acc["peak_balance"],
        "mll_start": mll_start_of_day,
        "mll_end": acc["mll_floor"],
        "mll_locked": acc["mll_locked"],
        "remaining_dd_buffer": remaining_dd_buffer,
        "day_gross_pnl": day_gross_pnl,
        "day_commissions": day_commissions,
        "day_net_pnl": day_net_pnl,
        "day_mfe_erosion": day_mfe_erosion,
        "goal_status_str": goal_status_str,
        "events_today": events_today,
        "bullets": bullet_logs,
        "totals": {
            "evals_bought": acc["total_evals_bought"],
            "blown_evals": acc["total_blown_evals"],
            "blown_funded": acc["total_blown_funded"],
            "passed_evals": acc["total_passed_evals"],
            "payouts_count": acc["total_payouts_count"],
            "payouts_net_usd": acc["total_payouts_net_usd"],
            "total_spend_usd": total_spend,
            "net_cashflow_usd": net_cashflow,
        }
    }


def _infer_live_signal_outcome(sig: Dict[str, Any]) -> Tuple[str, float, float]:
    """
    Infereix `(outcome, points, mfe_pts)` d'un senyal de `LiveSniperEngine` en cas d'emergència
    quan ni Databento ni yfinance estiguin accessibles.
    """
    explicit_out = str(sig.get("outcome") or "").upper()
    be_app = bool(sig.get("be_applied", False))
    action = str(sig.get("action", "Buy")).lower()
    is_long = (action == "buy")
    entry_px = float(sig.get("price") or 0.0)
    tp_px = float(sig.get("tp_price") or 0.0)
    pts_bracket = round(abs(tp_px - entry_px), 2) if (entry_px > 0 and tp_px > 0) else 30.0

    if explicit_out == "TP":
        return "TP", +pts_bracket, pts_bracket
    if explicit_out == "SL":
        return "SL", -pts_bracket, 0.0
    if explicit_out == "BE":
        return "BE", 0.0, 22.0

    exit_px = sig.get("exit_price")
    if exit_px is not None and entry_px > 0:
        try:
            raw_pts = (float(exit_px) - entry_px) if is_long else (entry_px - float(exit_px))
            if raw_pts >= pts_bracket - 2.0:
                return "TP", +pts_bracket, pts_bracket
            if raw_pts <= -(pts_bracket - 2.0) and not be_app:
                return "SL", -pts_bracket, 0.0
            if abs(raw_pts) <= 2.5 or be_app:
                return "BE", 0.0, 22.0
        except (TypeError, ValueError):
            pass

    if be_app:
        return "BE", 0.0, 22.0
    return "TP", +pts_bracket, pts_bracket


def _get_expected_trading_dates(start_date: str, end_date: str) -> List[str]:
    """Retorna tots els dies feiners CME no festius entre `start_date` i `end_date` (inclosos)."""
    import pandas as pd
    if end_date < start_date:
        return []
    try:
        from scripts.update_databento_week import is_us_holiday_or_xmas
    except Exception:
        is_us_holiday_or_xmas = lambda _d: False  # noqa: E731

    out: List[str] = []
    for dt_ts in pd.bdate_range(start=start_date, end=end_date):
        d_obj = dt_ts.date()
        if not is_us_holiday_or_xmas(d_obj):
            out.append(d_obj.isoformat())
    return out


def get_session_signals_for_date(date_str: str, force_refresh: bool = False) -> Dict[str, Any]:
    """
    Obté els senyals d'1m + 1s de `date_str` des del cau o `scripts/update_databento_week.py`
    (que usa Databento 1m+1s i fallback automàtic `yfinance` MNQ=F 1m durant l'embargo T-8h del mateix dia).
    Si una entrada antiga del cau provenia d'un fallback provisional (`yfinance_1m` / `live_engine_fallback`
    o `anchor_price is None`), intenta actualitzar-la a `databento_1s` quan ja és un dia passat.
    """
    today_ny_str = datetime.datetime.now(config.tz_ny).date().isoformat()
    cached_entry: Optional[Dict[str, Any]] = None

    if not force_refresh and os.path.exists(WEEKLY_SIGNALS_CACHE):
        try:
            with open(WEEKLY_SIGNALS_CACHE, "r", encoding="utf-8") as f:
                cache = json.load(f)
            if date_str in cache.get("days", {}):
                cached_entry = cache["days"][date_str]
                src = cached_entry.get("data_source", "databento_1s")
                has_anchor = cached_entry.get("anchor_price") is not None or not cached_entry.get("is_trading_day", True)
                is_provisional_past = (src in ("yfinance_1m", "live_engine_fallback")) and (date_str < today_ny_str)
                if has_anchor and not is_provisional_past and src != "live_engine_fallback":
                    return cached_entry
        except Exception:
            cached_entry = None

    try:
        from scripts.update_databento_week import analyze_session_sniper_combo_elite
        res = analyze_session_sniper_combo_elite(date_str)
        if res.get("anchor_price") is not None or not res.get("is_trading_day", True):
            cache = {"days": {}}
            if os.path.exists(WEEKLY_SIGNALS_CACHE):
                try:
                    with open(WEEKLY_SIGNALS_CACHE, "r", encoding="utf-8") as f:
                        cache = json.load(f)
                except Exception:
                    cache = {"days": {}}
            cache.setdefault("days", {})[date_str] = res
            cache["updated_at"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            with open(WEEKLY_SIGNALS_CACHE, "w", encoding="utf-8") as f:
                json.dump(cache, f, indent=2, ensure_ascii=False)
        return res
    except Exception as e:
        if cached_entry and cached_entry.get("anchor_price") is not None:
            return cached_entry
        logger.warning(f"Fallback a LiveEngine per a {date_str} (Databento/yfinance no disponible: {e})")
        try:
            from bot.live_engine import live_unified_engine
            dt_target = datetime.date.fromisoformat(date_str)
            trades = []
            anchor_val = None
            if live_unified_engine.current_date == dt_target:
                anchor_val = live_unified_engine.anchor_price
                for idx, sig in enumerate(live_unified_engine.signal_history_today, start=1):
                    be_app = bool(sig.get("be_applied", False))
                    outcome, pts, mfe_val = _infer_live_signal_outcome(sig)
                    trades.append({
                        "bullet_num": idx,
                        "slot": sig.get("slot", "LAYER"),
                        "is_continuation": "cont" in str(sig.get("slot", "")).lower(),
                        "direction": "LONG" if str(sig.get("action", "")).lower() == "buy" else "SHORT",
                        "action": str(sig.get("action", "BUY")).upper(),
                        "entry_time_ny": sig.get("time_ny", "10:00")[:5],
                        "exit_time_ny": sig.get("exit_time_ny") or "12:00:00",
                        "entry_price": float(sig.get("price") or 0.0),
                        "tp_price": float(sig.get("tp_price") or 0.0),
                        "sl_price": float(sig.get("sl_price") or 0.0),
                        "anchor_price": float(anchor_val or 0.0),
                        "dev_at_entry": 50.0,
                        "outcome": outcome,
                        "points": pts,
                        "mfe_pts": mfe_val,
                        "mae_pts": 0.0 if pts >= 0 else 30.0,
                        "be_applied": be_app,
                        "be_time_ny": None,
                        "double_sl": False,
                        "databento_1s_cost_usd": 0.0,
                    })
            return {
                "date": date_str,
                "is_trading_day": True,
                "anchor_price": anchor_val,
                "executed_trades": trades,
                "databento_cost_usd": 0.0,
                "data_source": "live_engine_fallback",
            }
        except Exception:
            return {
                "date": date_str,
                "is_trading_day": True,
                "anchor_price": None,
                "executed_trades": [],
                "databento_cost_usd": 0.0,
                "data_source": "live_engine_fallback",
            }


def _append_single_session_day(date_str: str, state: Dict[str, Any], force_refresh: bool = False) -> Dict[str, Any]:
    """Aplica estrictament una única sessió `date_str` al final de `state`."""
    session_info = get_session_signals_for_date(date_str, force_refresh=force_refresh)
    if not session_info.get("is_trading_day", True) and session_info.get("data_source") == "holiday_or_weekend":
        dt_obj = datetime.date.fromisoformat(date_str)
        day_name_ca = DAYS_CATALAN.get(dt_obj.weekday(), date_str)
        return {
            "session_num": state.get("sessions_count", 0),
            "date": date_str,
            "date_formatted": f"{day_name_ca} {dt_obj.strftime('%d/%m/%Y')}",
            "anchor_price": None,
            "databento_cost_usd": 0.0,
            "data_source": "holiday_or_weekend",
            "executed_trades": [],
            "accounts": state["daily_history"][-1]["accounts"] if state.get("daily_history") else {},
        }

    executed_trades = session_info.get("executed_trades", [])

    state["sessions_count"] = int(state.get("sessions_count", 0)) + 1
    state["last_processed_date"] = date_str

    account_reports: Dict[str, Any] = {}
    for prof in ACCOUNT_PROFILES:
        pid = prof["profile_id"]
        acc_state = state["accounts"][pid]
        rep = step_account_for_day(acc_state, prof, date_str, executed_trades)
        account_reports[pid] = rep

    dt_obj = datetime.date.fromisoformat(date_str)
    day_name_ca = DAYS_CATALAN.get(dt_obj.weekday(), date_str)

    day_summary = {
        "session_num": state["sessions_count"],
        "date": date_str,
        "date_formatted": f"{day_name_ca} {dt_obj.strftime('%d/%m/%Y')}",
        "anchor_price": session_info.get("anchor_price"),
        "databento_cost_usd": session_info.get("databento_cost_usd", 0.0),
        "data_source": session_info.get("data_source", "databento_1s"),
        "executed_trades": executed_trades,
        "accounts": account_reports,
    }
    state.setdefault("daily_history", []).append(day_summary)
    return day_summary


def process_session_day(
    date_str: str,
    state: Optional[Dict[str, Any]] = None,
    save: bool = True,
    force_refresh: bool = False,
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Processa una sessió diària sobre l'estat acumulat:
    - Auto-backfill: si faltaven dies feiners intermedis entre `start_date` i `date_str`
      (p. ex. després d'un redeploy en un contenidor efímer), els processa automàticament en ordre cronològic.
    - Auto-reparació: si `date_str` o un dia previ s'havia guardat amb `anchor_price: None` per un error
      temporal de xarxa o si `force_refresh=True`, reconstrueix netament la cadena des de `start_date`
      sense duplicar mai cap operació.
    """
    if state is None:
        state = load_simulation_state()

    start_date = state.get("start_date", DEFAULT_START_DATE)
    history = state.get("daily_history", [])
    hist_by_date = {d["date"]: d for d in history if "date" in d}

    expected_dates = _get_expected_trading_dates(start_date, date_str)
    max_existing_date = max(hist_by_date.keys()) if hist_by_date else None

    # Comprovar si hi ha forats intermedis abans d'una data ja processada o registres buits (`anchor_price is None`)
    has_internal_gap = False
    if max_existing_date:
        for exp_d in expected_dates:
            if exp_d < max_existing_date and exp_d not in hist_by_date:
                has_internal_gap = True
                break

    has_broken_entry = any(d.get("anchor_price") is None for d in history)
    needs_full_rebuild = has_internal_gap or has_broken_entry or (force_refresh and date_str in hist_by_date)

    if needs_full_rebuild:
        target_end = max(date_str, max_existing_date) if max_existing_date else date_str
        fresh_state = create_initial_simulation_state(start_date=start_date)
        for exp_d in _get_expected_trading_dates(start_date, target_end):
            _append_single_session_day(exp_d, fresh_state, force_refresh=(force_refresh and exp_d == date_str))
        state.clear()
        state.update(fresh_state)
        if save:
            save_simulation_state(state)
        for d in state.get("daily_history", []):
            if d.get("date") == date_str:
                return d, state
        return state["daily_history"][-1], state

    if date_str in hist_by_date:
        return hist_by_date[date_str], state

    # Auto-backfill seqüencial de qualsevol dia hàbil pendent abans de `date_str`
    for exp_d in expected_dates:
        if exp_d < date_str and exp_d not in hist_by_date:
            _append_single_session_day(exp_d, state, force_refresh=False)
            hist_by_date[exp_d] = state["daily_history"][-1]

    day_summary = _append_single_session_day(date_str, state, force_refresh=force_refresh)

    if save:
        save_simulation_state(state)

    return day_summary, state


def rebuild_simulation_from_start(start_date: str = "2026-10-19", end_date: str = "2026-10-23") -> Dict[str, Any]:
    """
    Reinicia l'estat des de `start_date` i simula totes les sessions hàbils
    fins a `end_date` en ordre cronològic.
    """
    state = create_initial_simulation_state(start_date=start_date)
    for d_str in _get_expected_trading_dates(start_date, end_date):
        _append_single_session_day(d_str, state, force_refresh=False)
    save_simulation_state(state)
    return state


def _progress_bar(pct: float, width: int = 6) -> str:
    """Genera una barra de progrés visual compacta que no trenca línia en columnes inline de Discord."""
    clamped = max(0.0, min(100.0, pct))
    filled = int(round((clamped / 100.0) * width))
    return "🟩" * filled + "⬜" * (width - filled)


def format_account_inline_field(rep: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    """
    Genera una targeta en columna (`inline: True`) per a un compte Prop Firm.
    Dissenyada amb línies curtes (<26 caràcters) perquè les 3 columnes quedin
    perfectament alineades en horitzontal a Discord sense embolcall de línia.
    """
    is_funded = (rep["phase"] == "FUNDED")
    phase_badge = "💎 **FUNDED**" if is_funded else "🔥 **EVAL**"
    trail_icon = "⚡" if rep["trailing_type"] == "INTRADAY_1S_MFE" else "🛡️"
    trail_short = "Intra 1s" if rep["trailing_type"] == "INTRADAY_1S_MFE" else "EOD Pur"

    start_bal = float(profile["start_balance"])
    if not is_funded:
        target_profit = float(profile["eval_target_balance"]) - start_bal
        curr_profit = max(0.0, rep["balance_end"] - start_bal)
        pct = min(100.0, (curr_profit / target_profit) * 100.0) if target_profit > 0 else 0.0
        dist = max(0.0, float(profile["eval_target_balance"]) - rep["balance_end"])
        bar = _progress_bar(pct, width=6)
        goal_line_1 = f"🎯 {bar} **{pct:.0f}%**"
        goal_line_2 = f"↳ *Falten **${dist:,.2f}***"
    else:
        buf_target = float(profile["funded_buffer_balance"]) + float(profile["min_payout_withdrawal"])
        target_profit = buf_target - start_bal
        curr_profit = max(0.0, rep["balance_end"] - start_bal)
        pct = min(100.0, (curr_profit / target_profit) * 100.0) if target_profit > 0 else 100.0
        bar = _progress_bar(pct, width=6)
        goal_line_1 = f"🎯 {bar} **{pct:.0f}%**"
        goal_line_2 = f"↳ *{rep['goal_status_str'].replace('Payout: ', '')}*"

    lock_icon = " 🔒" if rep.get("mll_locked") else ""

    if rep["day_mfe_erosion"] > 0:
        be_line = f"⚠️ *BE avui: `-${rep['day_mfe_erosion']:,.0f}` MLL*"
    elif rep["trailing_type"] == "EOD" and any(b["outcome"] == "BE" for b in rep["bullets"]):
        be_line = "✅ *BE avui: `$0` erosió*"
    elif rep["bullets"]:
        be_line = "✅ *Coixí sense erosió BE*"
    else:
        be_line = "⚪ *Sense operacions avui*"

    tots = rep["totals"]
    blown_total = tots["blown_evals"] + tots["blown_funded"]
    if tots["payouts_net_usd"] > 0:
        fin_line = f"💵 *Retirat: `+$${tots['payouts_net_usd']:,.0f}`*"
    else:
        fin_line = f"💳 *Cost: `-${tots['total_spend_usd']:,.2f}`*"

    lines = [
        f"`{rep['account_tag']}` · {phase_badge} *({trail_short})*",
        f"💰 **Saldo:** **`${rep['balance_end']:,.2f}`**",
        goal_line_1,
        goal_line_2,
        f"🛡️ **Coixí:** **`${rep['remaining_dd_buffer']:,.2f}`**",
        f"↳ *MLL: `${rep['mll_end']:,.2f}`{lock_icon}*",
        be_line,
        f"📦 `{tots['evals_bought']}`C · `{blown_total}`💥 · `{tots['passed_evals']}`🎉 · `{tots['payouts_count']}`💰",
        fin_line,
    ]

    for ev in rep["events_today"]:
        if "💥" in ev:
            lines.append("🚨 **PETAT AVUI ➔ Nou Eval!**")
        elif "🎉" in ev:
            lines.append("🎉 **APROVAT AVUI ➔ PA!**")
        elif "💰" in ev:
            lines.append("💰 **PAYOUT COBRAT AVUI!**")
        elif "🛑" in ev:
            lines.append("🛑 **DLL Tocat (Pausa avui)**")

    return {
        "name": f"{trail_icon} {rep['short_label']}",
        "value": "\n".join(lines),
        "inline": True,
    }


def build_discord_daily_simulation_embeds(day_summary: Dict[str, Any], state: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Construeix 3 Embeds ultra-visuals i fàcils d'escanejar en 3 segons:
    - Embed 1 (Verd/Blau/Vermell): Resum d'avui en 2 columnes + Taula setmanal alineada en bloc monoespaiat.
    - Embed 2 (Blau 50K): 3 Targetes en paral·lel (`inline: True`) per a LucidDaily 50K, Apex 3.0 50K i Estàndard EOD 50K.
    - Embed 3 (Taronja 150K): 3 Targetes en paral·lel (`inline: True`) per a LucidDaily 150K, Apex 3.0 150K i Estàndard EOD 150K.
    """
    trades = day_summary.get("executed_trades", [])
    date_fmt = day_summary.get("date_formatted", day_summary.get("date"))
    sess_num = day_summary.get("session_num", 1)
    anchor_px = day_summary.get("anchor_price")

    total_pts = sum(float(t["points"]) for t in trades)
    wins = sum(1 for t in trades if t["outcome"] == "TP")
    bes = sum(1 for t in trades if t["outcome"] == "BE")
    losses = sum(1 for t in trades if t["outcome"] == "SL")

    # Columna 1 d'Embed 1: Bales d'Avui
    if not trades:
        col_bales = "⚪ **Cap bala avui**\n*Sense senyal LAYER a 09:30–12:00 NY*\n• Comissions: `$0.00`"
        col_caixa = (
            "🟦 **50K (`10 MNQ`):** `$0.00`\n"
            "🟧 **150K (`30 MNQ`):** `$0.00`\n"
            "🛡️ **Erosió BE:** `$0.00`"
        )
    else:
        b_lines = []
        for t in trades:
            out_icon = "✅ **TP**" if t["outcome"] == "TP" else ("🛡️ **BE**" if t["outcome"] == "BE" else "❌ **SL**")
            be_extra = f" *(pic `+{t['mfe_pts']:.0f}p`)*" if t["outcome"] == "BE" else ""
            b_lines.append(
                f"• **#{t['bullet_num']} `{t['slot']}`** ({t['action']} `{t['entry_time_ny']}`): {out_icon} `{t['points']:+.0f}p`{be_extra}"
            )
        col_bales = "\n".join(b_lines)

        gross_10 = sum(t["points"] * 20.0 for t in trades)
        comm_10 = len(trades) * 12.40
        net_10 = gross_10 - comm_10

        gross_30 = sum(t["points"] * 60.0 for t in trades)
        comm_30 = len(trades) * 37.20
        net_30 = gross_30 - comm_30

        be_mfe_pts = sum(t["mfe_pts"] for t in trades if t["outcome"] == "BE")
        if be_mfe_pts > 0:
            erosion_str = f"⚠️ **Pic BE Intra:** `+{be_mfe_pts:.0f}p` (`+${be_mfe_pts*20:,.0f}` / `+${be_mfe_pts*60:,.0f}`)"
        else:
            erosion_str = "✅ **Erosió BE Intra:** `$0` *(0 BE avui)*"

        col_caixa = (
            f"🟦 **50K (`10 MNQ`):** **`{net_10:+.2f}$`** *(com. `-${comm_10:.2f}`)*\n"
            f"🟧 **150K (`30 MNQ`):** **`{net_30:+.2f}$`** *(com. `-${comm_30:.2f}`)*\n"
            f"{erosion_str}"
        )

    # Taula monoespaiada d'evolució setmanal (50 caràcters d'amplada màxima perquè mai trenqui línia)
    day_abbr_map = {"Dilluns": "Dl", "Dimarts": "Dt", "Dimecres": "Dc", "Dijous": "Dj", "Divendres": "Dv"}
    target_date_str = day_summary.get("date", state.get("last_processed_date", DEFAULT_START_DATE))
    target_dt = datetime.date.fromisoformat(target_date_str)
    monday_dt = target_dt - datetime.timedelta(days=target_dt.weekday())
    monday_str = monday_dt.isoformat()

    all_up_to_target = [h for h in state.get("daily_history", []) if h.get("date", "") <= target_date_str]
    week_rows = [h for h in all_up_to_target if h.get("date", "") >= monday_str]
    if not week_rows:
        week_rows = all_up_to_target[-5:]
    has_prior_weeks = len(all_up_to_target) > len(week_rows)

    table_rows = [
        "DIA     BALES        PTS      NET 50K    NET 150K",
        "──────────────────────────────────────────────────",
    ]
    tot_w, tot_be, tot_l = 0, 0, 0
    tot_pts_wk = 0.0
    tot_net10_wk = 0.0
    tot_net30_wk = 0.0

    for h in week_rows:
        ht = h.get("executed_trades", [])
        d_parts = h.get("date_formatted", h["date"]).split()
        d_short = f"{day_abbr_map.get(d_parts[0], d_parts[0][:2])} {h['date'][8:10]}"
        if not ht:
            b_summary = "—"
            pts_str = "0p"
            n10_str = "$0.00"
            n30_str = "$0.00"
        else:
            w_d = sum(1 for x in ht if x["outcome"] == "TP")
            be_d = sum(1 for x in ht if x["outcome"] == "BE")
            l_d = sum(1 for x in ht if x["outcome"] == "SL")
            tot_w += w_d
            tot_be += be_d
            tot_l += l_d
            parts_b = []
            if w_d:
                parts_b.append(f"{w_d}TP")
            if be_d:
                parts_b.append(f"{be_d}BE")
            if l_d:
                parts_b.append(f"{l_d}SL")
            b_summary = " + ".join(parts_b)

            pts_d = sum(float(x["points"]) for x in ht)
            n10_d = sum(float(x["points"]) * 20.0 - 12.40 for x in ht)
            n30_d = sum(float(x["points"]) * 60.0 - 37.20 for x in ht)
            tot_pts_wk += pts_d
            tot_net10_wk += n10_d
            tot_net30_wk += n30_d

            pts_str = f"{pts_d:+.0f}p"
            n10_str = f"{n10_d:+.2f}$"
            n30_str = f"{n30_d:+.2f}$"

        mark = "▸" if h["date"] == target_date_str else " "
        table_rows.append(f"{mark}{d_short:<6} {b_summary:<11} {pts_str:>6} {n10_str:>11} {n30_str:>11}")

    table_rows.append("──────────────────────────────────────────────────")
    tot_b_str = f"{tot_w}W·{tot_be}BE·{tot_l}L"
    tot_pts_str = f"{tot_pts_wk:+.0f}p"
    tot_10_str = f"{tot_net10_wk:+.2f}$"
    tot_30_str = f"{tot_net30_wk:+.2f}$"
    wk_label = "SETM. " if has_prior_weeks else "TOTAL "
    table_rows.append(f" {wk_label} {tot_b_str:<11} {tot_pts_str:>6} {tot_10_str:>11} {tot_30_str:>11}")

    if has_prior_weeks:
        g_w = sum(sum(1 for x in h.get("executed_trades", []) if x["outcome"] == "TP") for h in all_up_to_target)
        g_be = sum(sum(1 for x in h.get("executed_trades", []) if x["outcome"] == "BE") for h in all_up_to_target)
        g_l = sum(sum(1 for x in h.get("executed_trades", []) if x["outcome"] == "SL") for h in all_up_to_target)
        g_pts = sum(sum(float(x["points"]) for x in h.get("executed_trades", [])) for h in all_up_to_target)
        g_n10 = sum(sum(float(x["points"]) * 20.0 - 12.40 for x in h.get("executed_trades", [])) for h in all_up_to_target)
        g_n30 = sum(sum(float(x["points"]) * 60.0 - 37.20 for x in h.get("executed_trades", [])) for h in all_up_to_target)
        g_b_str = f"{g_w}W·{g_be}BE·{g_l}L"
        g_pts_str = f"{g_pts:+.0f}p"
        g_10_str = f"{g_n10:+.2f}$"
        g_30_str = f"{g_n30:+.2f}$"
        table_rows.append(f" GLOBAL {g_b_str:<11} {g_pts_str:>6} {g_10_str:>11} {g_30_str:>11}")
        scoreboard_title = (
            f"📅 Marcador Setmanal (Setmana {monday_dt.strftime('%d/%m')} · "
            f"Acumulat des de {state.get('start_date', DEFAULT_START_DATE)})"
        )
    else:
        scoreboard_title = f"📅 Marcador Setmanal (des de Dilluns {state.get('start_date', DEFAULT_START_DATE)})"

    weekly_table_block = "```text\n" + "\n".join(table_rows) + "\n```"

    accs = day_summary["accounts"]
    fields_50k = [format_account_inline_field(accs[pid], PROFILES_BY_ID[pid]) for pid in ["LUCID_50K", "APEX_50K", "EOD_50K"]]
    fields_150k = [format_account_inline_field(accs[pid], PROFILES_BY_ID[pid]) for pid in ["LUCID_150K", "APEX_150K", "EOD_150K"]]

    l50, a50, e50 = accs["LUCID_50K"], accs["APEX_50K"], accs["EOD_50K"]
    l150, a150, e150 = accs["LUCID_150K"], accs["APEX_150K"], accs["EOD_150K"]
    diff_50k = round(e50["remaining_dd_buffer"] - l50["remaining_dd_buffer"], 2)
    diff_150k = round(e150["remaining_dd_buffer"] - l150["remaining_dd_buffer"], 2)

    color_session = 0x10B981 if total_pts > 0 else (0x3B82F6 if total_pts == 0 else 0xEF4444)

    embed_1 = {
        "title": f"📊 SIMULACIÓ PROP FIRMS · DIA #{sess_num} ({date_fmt})",
        "description": (
            f"🎯 **`SNIPER_COMBO_ELITE`** · Àncora 09:30 NY: `{anchor_px}` · Comissió: `$1.24/MNQ RT`"
        ),
        "fields": [
            {
                "name": f"🔫 Bales d'Avui ({wins}W · {bes}BE · {losses}L = {total_pts:+.0f}p)",
                "value": col_bales,
                "inline": True,
            },
            {
                "name": "💵 Resultat Net d'Avui (post-comissions)",
                "value": col_caixa,
                "inline": True,
            },
            {
                "name": scoreboard_title,
                "value": weekly_table_block,
                "inline": False,
            },
        ],
        "color": color_session,
    }

    # Esdeveniments destacats 50K (si algun compte ha petat, aprovat o cobrat avui)
    ev_50k = []
    for pid in ["LUCID_50K", "APEX_50K", "EOD_50K"]:
        for ev in accs[pid]["events_today"]:
            if any(k in ev for k in ("💥", "🎉", "💰", "🛑")):
                ev_50k.append(f"• **{accs[pid]['short_label']}:** {ev}")
    extra_50k = ("\n" + "\n".join(ev_50k)) if ev_50k else ""

    if l50.get("mll_locked") and a50.get("mll_locked") and e50.get("mll_locked"):
        comp_50k = (
            f"🔒 **Tots 3 comptes 50K ja tenen el Drawdown MLL travat al sostre (`$50,100.00`)!** "
            f"Coixí viu idèntic de **`${e50['remaining_dd_buffer']:,.2f}`**."
        )
    else:
        comp_50k = (
            f"💡 **Comparativa Coixí Viu:** EOD conserva **`+${diff_50k:,.2f}`** més de coixí que Lucid Intraday "
            f"(`$${e50['remaining_dd_buffer']:,.2f}` vs `$${l50['remaining_dd_buffer']:,.2f}`) perquè el BE no puja el MLL."
        ).replace("$$", "$")

    embed_2 = {
        "title": "🟦 COMPTES 50K (`10 MNQ` · `$20/pt` · `-$12.40` comissió/bala)",
        "description": f"{comp_50k}{extra_50k}",
        "fields": fields_50k,
        "color": 0x3B82F6,
    }

    ev_150k = []
    for pid in ["LUCID_150K", "APEX_150K", "EOD_150K"]:
        for ev in accs[pid]["events_today"]:
            if any(k in ev for k in ("💥", "🎉", "💰", "🛑")):
                ev_150k.append(f"• **{accs[pid]['short_label']}:** {ev}")
    extra_150k = ("\n" + "\n".join(ev_150k)) if ev_150k else ""

    if l150.get("mll_locked") and e150.get("mll_locked"):
        comp_150k = (
            f"🔒 **Tots 3 comptes 150K ja tenen el Drawdown MLL travat al sostre (`$150,100.00`)!** "
            f"Coixí viu idèntic de **`${e150['remaining_dd_buffer']:,.2f}`**."
        )
    else:
        comp_150k = (
            f"💡 **Comparativa Coixí Viu:** EOD 150K conserva **`+${diff_150k:,.2f}`** més de marge que Lucid Intraday "
            f"(`$${e150['remaining_dd_buffer']:,.2f}` vs `$${l150['remaining_dd_buffer']:,.2f}`)."
        ).replace("$$", "$")

    embed_3 = {
        "title": "🟧 COMPTES 150K (`30 MNQ` · `$60/pt` · `-$37.20` comissió/bala)",
        "description": f"{comp_150k}{extra_150k}",
        "fields": fields_150k,
        "color": 0xF59E0B,
        "footer": {
            "text": (
                f"JJ Layer Sniper Pro 2026 · Llegenda: C=Comprats 💥=Petats 🎉=Aprovats 💰=Payouts · "
                f"Databento 1s (${day_summary.get('databento_cost_usd', 0.0):.4f})"
            )
        },
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }

    return [embed_1, embed_2, embed_3]
