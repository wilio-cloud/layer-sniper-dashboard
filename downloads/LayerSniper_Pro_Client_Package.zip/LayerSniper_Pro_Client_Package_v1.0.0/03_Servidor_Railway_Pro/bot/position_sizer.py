"""
Mòdul de gestió i dimensionament de posició segons el perfil de compte:
- Prop Master: Quantitat fixa o dictada pel preset de l'estratègia (ex: 5 MNQ consolidació o 10 MNQ JJ Bloc A) per a Replikanto / Prop API.
- Live: Quantitat dinàmica adaptada al capital net / drawdown (Model 1: Capital per tram), doblant si el mode és CLOSE (15p) per mantenir el risc en dòlars constant.
"""
import logging
from typing import Optional
from bot.config import config

logger = logging.getLogger("PositionSizer")


class PositionSizer:
    def __init__(self, cfg=None):
        self._cfg = cfg

    @property
    def cfg(self):
        return self._cfg or config

    def calculate_qty(
        self,
        balance: Optional[float] = None,
        role: Optional[str] = None,
        strategy_name: Optional[str] = None,
        incoming_qty: Optional[int] = None,
        sl_points: Optional[float] = None,
        trade_mode: Optional[str] = None
    ) -> int:
        target_role = (role or getattr(self.cfg, "account_role", "prop_master") or "prop_master").lower()
        mode_clean = (trade_mode or "FAR").upper()

        # 1. Perfil Prop Master (Comptes fondejats via Replikanto Leader o Prop API)
        if target_role == "prop_master":
            max_allowed = getattr(self.cfg, "max_contracts", 20)
            if incoming_qty and incoming_qty > 0 and incoming_qty <= max_allowed:
                logger.info(f"📐 PositionSizer [PROP MASTER]: Aplicant mida de senyal TradingView: {incoming_qty} {self.cfg.symbol_base} ({mode_clean}).")
                return incoming_qty

            strat = (strategy_name or "").lower()
            if "bloca" in strat or "bloc_a" in strat:
                base_qty = getattr(self.cfg, "prop_bloc_a_contracts", getattr(self.cfg, "prop_master_contracts", 5))
            elif "blocb" in strat or "bloc_b" in strat:
                base_qty = getattr(self.cfg, "prop_bloc_b_contracts", getattr(self.cfg, "prop_master_contracts", 5))
            else:
                base_qty = getattr(self.cfg, "prop_master_contracts", 5)

            if mode_clean == "CLOSE" and (sl_points is not None and sl_points <= 16.0):
                base_qty = min(base_qty * 2, max_allowed)

            logger.info(f"📐 PositionSizer [PROP MASTER]: Mida de {base_qty} {self.cfg.symbol_base} per a Replikanto / Prop Firm.")
            return base_qty

        # 2. Perfil Live (Capital propi amb gestió de Drawdown per tram)
        step = getattr(self.cfg, "live_capital_step", 1000.0)
        if step <= 0:
            step = 1000.0
        min_c = getattr(self.cfg, "live_min_contracts", 1)
        max_c = getattr(self.cfg, "live_max_contracts", None) or getattr(self.cfg, "max_contracts", 10)

        try:
            bal_float = float(balance)
        except (TypeError, ValueError):
            bal_float = 0.0

        if balance is None or bal_float <= 0:
            logger.warning(
                f"⚠️ PositionSizer [LIVE]: Saldo no disponible o nul ({balance}). "
                f"Aplicant mida mínima de seguretat: {min_c} {self.cfg.symbol_base}."
            )
            return min_c

        calculated = int(bal_float // step)
        bounded = max(min_c, min(calculated, max_c))

        # Si el senyal és CLOSE (15p SL en lloc de 30p), doblem contractes (dins del límit absolut) per mantenir el mateix risc en $
        if mode_clean == "CLOSE" or (sl_points is not None and 0 < sl_points <= 16.0):
            bounded = min(bounded * 2, max_c * 2)

        logger.info(
            f"📐 PositionSizer [LIVE]: Saldo: {bal_float:.2f}$ | Pas: {step:.0f}$ | "
            f"Mode: {mode_clean} | Mida final: {bounded} {self.cfg.symbol_base}"
        )
        return bounded


position_sizer = PositionSizer()
