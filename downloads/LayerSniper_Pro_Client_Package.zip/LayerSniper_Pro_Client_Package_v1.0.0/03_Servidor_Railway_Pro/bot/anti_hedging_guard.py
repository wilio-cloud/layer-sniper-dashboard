import logging
from typing import Dict, Any, List, Tuple

logger = logging.getLogger("AntiHedgingGuard")


class AntiHedgingGuard:
    """
    Guardià de compliment normatiu per a Prop Firms (Apex, MFFU, Lucid, Tradeify, Topstep).
    Garanteix que MAI s'executin ordres oposades ni s'obrin posicions en conflicte
    de Hedging sobre el mateix actiu (MNQ / NQ).
    """

    def validate_order(
        self,
        proposed_action: str,  # "Buy" o "Sell"
        symbol: str,
        price: float,
        existing_positions: List[Dict[str, Any]],
        existing_orders: List[Dict[str, Any]],
        strategy_source: str = ""
    ) -> Tuple[bool, str]:
        prop_action = proposed_action.strip().capitalize()
        opposing_action = "Sell" if prop_action == "Buy" else "Buy"

        # 1. Comprovació de posicions obertes oposades
        for pos in existing_positions:
            net_pos = pos.get("netPos", 0)
            if net_pos > 0 and prop_action == "Sell":
                msg = f"⛔ VIOLACIÓ HEDGING: Hi ha una posició LONG activa ({net_pos} ctrs). Es bloqueja l'ordre de venda ({strategy_source})."
                logger.error(msg)
                return False, msg
            elif net_pos < 0 and prop_action == "Buy":
                msg = f"⛔ VIOLACIÓ HEDGING: Hi ha una posició SHORT activa ({abs(net_pos)} ctrs). Es bloqueja l'ordre de compra ({strategy_source})."
                logger.error(msg)
                return False, msg

        # 2. Comprovació d'ordres pare pendents en sentit oposat
        for order in existing_orders:
            ord_status = order.get("ordStatus", "").lower()
            if ord_status in ("working", "accepted", "pending"):
                ord_action = order.get("action", "").strip().capitalize()
                if ord_action == opposing_action:
                    order_type = order.get("orderType", "").lower()
                    if order_type in ("limit", "stop"):
                        parent_id = order.get("parentId") or order.get("parentOrderId")
                        oco_id = order.get("ocoId")
                        if not parent_id and not oco_id:
                            msg = f"⛔ VIOLACIÓ HEDGING: Ja existeix una ordre pare pendent {ord_action} ID {order.get('id')}. Bloquejant {prop_action} ({strategy_source})."
                            logger.error(msg)
                            return False, msg

        price_str = f"{float(price):.2f}" if isinstance(price, (int, float)) else str(price)
        logger.info(f"✅ Anti-Hedging Guard: Ordre {prop_action} {symbol} @ {price_str} ({strategy_source}) AUTORITZADA.")
        return True, "AUTORITZADA_SENSE_HEDGING"


anti_hedging_guard = AntiHedgingGuard()
