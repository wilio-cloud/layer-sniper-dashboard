import os
import datetime
import logging
import threading
from typing import Optional, Dict, Any
import requests
from bot.config import config

logger = logging.getLogger("Notifier")

COLOR_MAP = {
    "green": 0x10B981,
    "success": 0x10B981,
    "blue": 0x3B82F6,
    "orange": 0xF59E0B,
    "warning": 0xF59E0B,
    "danger": 0xEF4444,
    "red": 0xEF4444,
    "purple": 0x8B5CF6,
}

PSYCH_MORNING_QUOTES = [
    "«L'estratègia ja té un 60% d'encert i +$80.000/any demostrades al segon. La teva única feina avui no és ser més llest que el mercat: és executar amb fredor de cirurgià només quan l'indicador ho digui i saber parar.»",
    "«Un franctirador d'elit no dispara al matí per avorriment. Guarda les teves 2 bales de plata per a la finestra de Nova York (15:30h). Mentrestant, comptes tancats amb clau i ment 100% en pau.»",
    "«La diferència entre qui només aprova Evals i qui cobra Payouts cada mes és una sola: no regalar ni un sol dòlar fora d'hores ni fora de les 2 bales de l'indicador.»",
    "«Avui la matemàtica ja treballa a favor teu. No intentis forçar res abans de les 15:00h: el teu èxit es construeix respectant el cadenat i arribant a les 15:30h amb el cap fred.»",
    "«No necessites fer més trades; necessites no fallar mentalment ni un sol dia. L'indicador et donarà el teu avantatge a la tarda; ara protegeix el teu capital i la teva energia.»",
    "«El mercat premia la paciència extrema i castiga l'impuls. Comptes bloquejats fins a les 15:00h = zero desgast mental i 100% de força quan obri Nova York.»",
    "«Recorda: un dia perfecte no es mesura pel P&L d'un sol trade, es mesura per haver seguit les normes al 100% sense regalar cap clic a l'emoció.»"
]

PSYCH_CLOSING_QUOTES = [
    "«Sessió complerta. Tant si avui ha tocat TP, BE o SL, si has respectat les 2 bales de l'indicador i ara poses el cadenat fins demà a les 15:00h, avui has guanyat com a professional.»",
    "«El 3r trade i operar fora d'hores tenen més d'un 83% de probabilitat de pèrdua. Posar el cadenat ara mateix fins demà a les 15:00h és l'escut que protegeix els teus Payouts.»",
    "«L'estratègia és una màquina sòlida quan es mira en blocs de 20 sessions. Tanca els comptes amb clau fins demà a les 15:00h, desconnecta de les pantalles i deixa que l'estadística faci la seva feina.»",
    "«Saber parar a temps val més que qualsevol entrada. Bloqueja tots els comptes fins demà a les 15:00h: el diner que no regales per impuls és el Payout que cobraràs a final de cicle.»",
    "«Un veritable trader institucional sap quan s'ha acabat la seva feina del dia. Cadenat posat fins demà a les 15:00h, cap net i orgull d'haver complert el pla sense fisures.»",
    "«Recorda: l'escut de Breakeven i el límit de 2 bales et salven desenes de milers de dòlars l'any. Ara posa el cadenat fins demà a les 15:00h i gaudeix de la resta del dia!»",
    "«Cap emoció del tancament d'avui té permís per tocar els teus comptes. Bloqueja-ho tot fins demà a les 15:00h: demà a les 15:30h tornem a disparar amb avantatge matemàtic pur.»"
]


def get_psychologist_quote(phase: str = "morning", dt: Optional[datetime.date] = None) -> str:
    d = dt or datetime.datetime.now(config.tz_madrid).date()
    pool = PSYCH_MORNING_QUOTES if phase == "morning" else PSYCH_CLOSING_QUOTES
    idx = (d.toordinal()) % len(pool)
    q = pool[idx]
    ref_d = d if phase == "morning" else (d + datetime.timedelta(days=1))
    naive_900 = datetime.datetime(ref_d.year, ref_d.month, ref_d.day, 9, 0)
    ny_900 = config.tz_ny.localize(naive_900) if hasattr(config.tz_ny, "localize") else naive_900.replace(tzinfo=config.tz_ny)
    if ny_900.astimezone(config.tz_madrid).hour == 14:
        q = q.replace("15:00h", "14:00h").replace("15:30h", "14:30h")
    return q


class MasterNotifier:
    def __init__(self):
        self.discord_url = config.discord_webhook_url
        self.discord_diari_comptes_url = config.discord_webhook_url_diari_comptes or config.discord_webhook_url
        # Aïllament estricte: MAI fa fallback als canals públics/compartits
        self.discord_private_alerts_url = config.discord_webhook_url_private_alerts
        self.telegram_token = config.telegram_bot_token
        self.telegram_chat_id = config.telegram_chat_id

    def send_private_alert(
        self,
        title: str,
        message: str,
        color: str = "purple",
        fields: Optional[Dict[str, str]] = None,
        sync: bool = False,
        allow_weekend: bool = True,
    ) -> bool:
        """
        Envia un avís del Fleet Safety Pack EXCLUSIVAMENT al canal privat (`DISCORD_WEBHOOK_URL_PRIVATE_ALERTS`).
        Per seguretat i privacitat, mai fa fallback a `DISCORD_WEBHOOK_URL` ni a `DISCORD_WEBHOOK_URL_DIARI_COMPTES`.
        """
        private_url = (self.discord_private_alerts_url or getattr(config, "discord_webhook_url_private_alerts", None) or "").strip()
        if not private_url:
            logger.info(f"🔒 [FLEET SAFETY PRIVAT NO CONFIGURAT] Ignorant enviament sense fallback públic: [{title}]")
            return False

        if self.is_weekend() and not allow_weekend:
            logger.info(f"🔇 [FLEET SAFETY SILENCIAT CAP DE SETMANA] Ignorat: [{title}]")
            return False

        def _do_private_post() -> bool:
            if os.environ.get("PYTEST_CURRENT_TEST") and not os.environ.get("ALLOW_LIVE_DISCORD_IN_TESTS"):
                return False
            hex_color = COLOR_MAP.get(color.lower(), 0x8B5CF6)
            embed: Dict[str, Any] = {
                "title": f"🛡️ Fleet Safety Privat | {title}",
                "description": message,
                "color": hex_color,
                "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }
            if fields:
                embed["fields"] = [{"name": k, "value": str(v), "inline": True} for k, v in fields.items()]
            payload = {
                "username": "Layer Sniper Pro [FLEET SAFETY PRIVAT]",
                "embeds": [embed],
            }
            try:
                resp = requests.post(private_url, json=payload, timeout=6)
                if resp.status_code not in (200, 204):
                    logger.warning(f"Discord Private Alert retornat {resp.status_code}: {resp.text}")
                    return False
                return True
            except Exception as e:
                logger.error(f"Error enviant Discord Private Alert: {e}")
                return False

        if sync:
            return _do_private_post()
        threading.Thread(target=_do_private_post, daemon=True).start()
        return True

    def is_weekend(self) -> bool:
        now_madrid = datetime.datetime.now(config.tz_madrid)
        now_ny = datetime.datetime.now(config.tz_ny)
        return now_madrid.weekday() >= 5 or now_ny.weekday() >= 5

    def send(
        self,
        title: str,
        message: str,
        color: str = "blue",
        fields: Optional[Dict[str, str]] = None,
        sync: bool = False,
        allow_weekend: bool = False
    ):
        logger.info(f"[NOTIFICACIÓ] [{title}] {message.replace(chr(10), ' ')}")

        if self.is_weekend() and not allow_weekend:
            logger.info(f"🔇 [DISCORD SILENCIAT] Cap de setmana detectat. Bloquejat enviament de: [{title}]")
            return

        def _do_send():
            self._send_discord(title, message, color, fields, allow_weekend=allow_weekend)
            self._send_telegram(title, message)

        if sync:
            _do_send()
        else:
            threading.Thread(target=_do_send, daemon=True).start()

    def _send_discord(self, title: str, message: str, color_name: str, fields: Optional[Dict[str, str]] = None, allow_weekend: bool = False):
        if os.environ.get("PYTEST_CURRENT_TEST") and not os.environ.get("ALLOW_LIVE_DISCORD_IN_TESTS"):
            return
        if not self.discord_url:
            return
        if self.is_weekend() and not allow_weekend:
            return

        hex_color = COLOR_MAP.get(color_name.lower(), 0x3B82F6)
        role_tag = "[LIVE]" if getattr(config, "account_role", "prop_master") == "live" else "[PROP MASTER]"
        embed: Dict[str, Any] = {
            "title": f"🎯 Layer Sniper Pro {role_tag} | {title}",
            "description": message,
            "color": hex_color,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat()
        }

        if fields:
            embed["fields"] = [{"name": k, "value": str(v), "inline": True} for k, v in fields.items()]

        payload = {
            "username": f"Layer Sniper Pro {role_tag}",
            "embeds": [embed]
        }

        try:
            resp = requests.post(self.discord_url, json=payload, timeout=5)
            if resp.status_code not in (200, 204):
                logger.debug(f"Discord webhook retornat {resp.status_code}: {resp.text}")
        except Exception as e:
            logger.debug(f"Error enviant webhook Discord: {e}")

    def _send_telegram(self, title: str, message: str):
        if os.environ.get("PYTEST_CURRENT_TEST") and not os.environ.get("ALLOW_LIVE_DISCORD_IN_TESTS"):
            return
        if not self.telegram_token or not self.telegram_chat_id:
            return

        role_tag = "[LIVE]" if getattr(config, "account_role", "prop_master") == "live" else "[PROP MASTER]"
        url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
        text = f"<b>🎯 Layer Sniper Pro {role_tag} | {title}</b>\n\n{message}"
        payload = {
            "chat_id": self.telegram_chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True
        }

        try:
            resp = requests.post(url, json=payload, timeout=5)
            if resp.status_code != 200:
                logger.debug(f"Telegram API retornat {resp.status_code}: {resp.text}")
        except Exception as e:
            logger.debug(f"Error enviant missatge Telegram: {e}")

    def send_morning_0800_lockout_reminder(self, now_madrid: Optional[datetime.datetime] = None, sync: bool = False):
        from bot.macro_calendar import get_seasonality_and_account_timing_advice

        now_m = now_madrid or datetime.datetime.now(config.tz_madrid)
        today_dt = now_m.date()
        naive_900 = datetime.datetime(today_dt.year, today_dt.month, today_dt.day, 9, 0)
        ny_900 = config.tz_ny.localize(naive_900) if hasattr(config.tz_ny, "localize") else naive_900.replace(tzinfo=config.tz_ny)
        bcn_lock_hr = ny_900.astimezone(config.tz_madrid).hour
        lock_time_str = f"{bcn_lock_hr:02d}:00:00 BCN"
        open_time_str = f"{bcn_lock_hr:02d}:30h BCN" + (" ⚠️ Setmana DST!" if bcn_lock_hr == 14 else "")

        quote = get_psychologist_quote("morning", today_dt)
        advice = get_seasonality_and_account_timing_advice(today_dt)
        hist = advice.get("historical_pattern") or {}
        hist_lines = hist.get("discord_lines", "")

        if advice["is_holiday_today"]:
            title = f"🛑 AVUI ÉS FESTIU USA / NADAL ({advice['holiday_name_today']}) — NO OPERAR!"
            color = "danger"
        elif advice["week4_status"] in ("DANGER_SLOW", "PRE_WARNING_SLOW"):
            title = f"⚠️ AVÍS MATINAL (08:00H) + ALERTA 4a SETMANA LENTA ({advice['avg_5d_range_pts']:.0f}p)"
            color = "warning"
        else:
            title = f"🔒 AVÍS MATINAL (08:00H): CADENAT {bcn_lock_hr}:00H + RADAR ESTACIONAL I COMPTES"
            color = "purple"

        # Sempre mostrem els festius de la setmana si som Dilluns o si hi ha algun festiu aquesta setmana
        show_week_holidays = (today_dt.weekday() == 0) or bool(advice["week_holidays"])
        holidays_block = f"\n{advice['holidays_summary']}\n" if show_week_holidays else ""
        hist_block = (
            f"🔬 **3. Patró Històric d'Avui (Anys Anteriors · 3A 1m + 2A 1s):**\n"
            f"{hist_lines}\n\n"
        ) if hist_lines else ""

        msg = (
            "☀️ **Bon dia, equip! Recordatori obligatori de disciplina i radar operatiu d'avui:**\n\n"
            f"🔒 **1. Cadenat Anti-Tilt fins a les `{lock_time_str}`:**\n"
            f"• TOTS els comptes (Tradovate / Prop Firms) han d'estar **BLOQUEJATS fins a les `{lock_time_str}`** "
            "(des de `/psicoleg` i a *Tradovate ➔ Risk Settings ➔ Lock Out*).\n"
            f"{holidays_block}\n"
            "📊 **2. Radar d'Estacionalitat i Volatilitat (Últims 5 dies `09:30–11:00 NY`):**\n"
            f"• {advice['week4_headline']}\n\n"
            f"{hist_block}"
            "🎯 **4. Semàfor per Estrenar / Comprar Comptes Nous Avui:**\n"
            f"• {advice['new_account_advice']}\n\n"
            f"⚡ **5. Regles d'Or per a la Sessió (`{open_time_str} / 09:30h NY`):**\n"
            "• **Màxim absolut de 2 Bales (`LAYER`)** en tot el dia. Zero entrades en l'explorador (`PRIMARY`).\n"
            "• Si el 1r trade fa **Doble SL (`P:SL + L:SL`)**, s'atura el dia a l'instant (`86.7%` de risc de fallada).\n"
            "• Escut d'`SL` a **Breakeven automàtic al primer tick (`+0.5p`)** quan el `PRIMARY` toqui `TP 1`.\n\n"
            f"🧠 **Missatge del Psicòleg per avui:**\n> *{quote}*"
        )
        fields = {
            "📅 Dia i Setmana": f"{advice['day_name']} {advice['date_str']} (Setmana {advice['week_of_month']})",
            "📈 Rang 5 Dies (9:30-11h)": f"{advice['avg_5d_range_pts']:.0f} pts ({'🐢 Lent <220p' if advice['is_slow_regime'] else '🔥 Volàtil >=220p'})",
            "🔬 Arquetip Històric": hist.get("short_field", "Sessió Estàndard"),
            "🆕 Estrenar Comptes Avui?": (
                "🚫 NO (Evitar)" if advice["new_account_status"].startswith(("AVOID", "BLOCKED"))
                else ("🔥 SÍ (Dia Òptim)" if advice["new_account_status"] == "OPTIMAL_DAY" else "✅ Apte")
            ),
        }
        self.send(title, msg, color=color, fields=fields, sync=sync)
        return advice

    def send_end_of_session_lockout_reminder(
        self,
        now_madrid: Optional[datetime.datetime] = None,
        reason: str = "Fi de la finestra operativa de Nova York",
        sync: bool = False
    ):
        now_m = now_madrid or datetime.datetime.now(config.tz_madrid)
        quote = get_psychologist_quote("closing", now_m.date())
        title = "🏁 SESSIÓ FINALITZADA: BLOQUEGEU TOTS ELS COMPTES FINS DEMÀ A LES 15:00H!"
        msg = (
            "🛑 **La sessió operativa d'avui s'ha acabat. És l'hora de posar el cadenat!**\n\n"
            "🔒 **TOTHOM ha de bloquejar ara mateix TOTS els seus comptes fins demà a les `15:00:00 BCN`:**\n"
            "1️⃣ Premeu el botó **`🔒 Cadenat 15:00h`** a la consola `/psicoleg` o al HUD.\n"
            "2️⃣ Activeu el **`Lock Out`** a *Tradovate ➔ Application Settings (⚙️) ➔ Risk Settings* fins demà a les 15:00h.\n"
            f"📋 **Motiu de tancament**: `{reason}`\n\n"
            f"🧠 **Missatge del Psicòleg de Tancament:**\n> *{quote}*"
        )
        self.send(title, msg, color="blue", sync=sync)

    def send_daily_prop_simulation_report(
        self,
        date_str: Optional[str] = None,
        sync: bool = False,
        allow_weekend: bool = False,
        force_refresh: bool = False,
    ) -> Dict[str, Any]:
        """
        Calcula i envia a Discord l'informe diari de simulació en viu dels 6 comptes Prop Firm
        (50K @ 10 MNQ i 150K @ 30 MNQ: LucidDaily, Apex 3.0 i Estàndard EOD) amb comissions reals
        i erosió d'Intraday Trailing Drawdown per MFE d'1 segon.
        """
        from bot.prop_daily_simulator import (
            process_session_day,
            load_simulation_state,
            build_discord_daily_simulation_embeds
        )

        target_date = date_str or datetime.datetime.now(config.tz_ny).date().isoformat()
        state = load_simulation_state()
        day_summary, state = process_session_day(
            target_date,
            state=state,
            save=True,
            force_refresh=force_refresh,
        )
        embeds = build_discord_daily_simulation_embeds(day_summary, state)

        logger.info(f"[NOTIFICACIÓ PROP SIM] Enviant informe diari de simulació per a {target_date} ({len(embeds)} embeds)...")

        if self.is_weekend() and not allow_weekend:
            logger.info(f"🔇 [DISCORD SILENCIAT] Cap de setmana detectat. Bloquejat enviament de Prop Sim ({target_date}).")
            return {"status": "SKIPPED_WEEKEND", "date": target_date, "day_summary": day_summary}

        def _do_post():
            if os.environ.get("PYTEST_CURRENT_TEST") and not os.environ.get("ALLOW_LIVE_DISCORD_IN_TESTS"):
                return
            target_webhook = self.discord_diari_comptes_url or self.discord_url
            if not target_webhook:
                return
            payload = {
                "username": "Layer Sniper Pro [DIARI COMPTES]",
                "embeds": embeds
            }
            try:
                resp = requests.post(target_webhook, json=payload, timeout=8)
                if resp.status_code not in (200, 204):
                    logger.warning(f"Discord Prop Sim retornat {resp.status_code}: {resp.text}")
                else:
                    logger.info(f"✅ Informe Prop Sim ({target_date}) enviat al canal DIARI COMPTES correctament!")
            except Exception as e:
                logger.error(f"Error enviant Prop Sim a Discord: {e}")

        if sync:
            _do_post()
        else:
            threading.Thread(target=_do_post, daemon=True).start()

        return {"status": "SENT", "date": target_date, "day_summary": day_summary}


notifier = MasterNotifier()
