import datetime
import logging
import time
import requests
from typing import Dict, Any, Optional
from bot.config import config
from bot.notifier import notifier
from bot.tradovate_master import tradovate_master
from bot.live_engine import live_unified_engine
from bot.emergency_killswitch import kill_switch
from bot.macro_calendar import get_day_trading_status, get_seasonality_and_account_timing_advice
from bot.news_guardian import news_guardian

logger = logging.getLogger("Sentinel")


class LayerSniperSentinel:
    def __init__(self):
        self.tz_madrid = config.tz_madrid
        self.tz_ny = config.tz_ny
        self.running: bool = False

        self.remote_bot_healthy: bool = True
        self.remote_bot_last_check: Optional[str] = None
        self.remote_bot_data: Dict[str, Any] = {}
        self.remote_failures_count: int = 0

        self.last_cycle_time: Optional[str] = None
        self.daily_events_dispatched: Dict[str, bool] = {
            "morning_0800_madrid_reminder": False,
            "session_cutoff_1130_ny": False,
            "daily_prop_sim_report_sent": False,
            "private_fleet_summary_sent": False,
            "rollover_post_close_alert_sent": False,
            "rollover_pre_open_alert_sent": False,
            "eod_close_1655_ny": False,
        }
        self.current_day: Optional[datetime.date] = None
        self.last_unprotected_alert_ts: float = 0.0
        self.dispatched_news_flattens: set = set()

    def reset_daily_dispatch(self, today: datetime.date):
        self.current_day = today
        for k in self.daily_events_dispatched:
            self.daily_events_dispatched[k] = False
        self.dispatched_news_flattens.clear()
        logger.info(f"🔄 Sentinel: Esdeveniments diaris reiniciats per a {today}")

    def _relay_flatten_to_nt8_bridge(self, reason: str) -> bool:
        """Envia ordre d'aplanat d'emergència al Bridge ATI de ChartVPS (Sim103 -> Replikanto LayerSniper) si està configurat."""
        forward_url = getattr(config, "forward_webhook_url", None)
        if not forward_url:
            return False
        secret = getattr(config, "forward_webhook_secret", None) or getattr(config, "webhook_secret", "layersniper2026")
        target_acct = getattr(config, "nt8_bot_account", "Sim103")
        payload = {
            "secret": secret,
            "account": target_acct,
            "strategy": "Sentinel_News_Shield",
            "action": "flatten",
            "reason": reason,
        }
        any_ok = False
        for url in [u.strip() for u in str(forward_url).split(",") if u.strip()]:
            try:
                resp = requests.post(url, json=payload, timeout=4.0)
                if resp.status_code == 200:
                    any_ok = True
                logger.info(f"🛡️ Sentinel NT8 Flatten Relay enviat a {url} -> HTTP {resp.status_code}")
            except Exception as e:
                logger.warning(f"⚠️ Error enviant NT8 Flatten Relay a {url}: {e}")
        return any_ok

    def check_news_emergency_shield(self, now_madrid: datetime.datetime, has_tradovate_api: bool = False):
        """
        Escut d'Emergència Red Folder USD (ex: 09:58 NY abans de notícies de les 10:00 NY).
        Funciona tant amb API directa de Tradovate com en mode Relay pur cap a NinjaTrader 8 (Sim101 + Replikanto).
        """
        if kill_switch.is_active:
            return
        now_ny = now_madrid.astimezone(self.tz_ny) if now_madrid.tzinfo else datetime.datetime.now(self.tz_ny)
        if now_madrid.weekday() >= 5 or now_ny.weekday() >= 5:
            return

        has_tradovate_pos = False
        if has_tradovate_api:
            pos = tradovate_master.get_positions()
            has_tradovate_pos = any(p.get("netPos", 0) != 0 for p in pos)

        has_nt8_potential_pos = bool(getattr(config, "forward_webhook_url", None)) and (
            live_unified_engine.trades_executed_today > 0
        )
        should_check = has_tradovate_pos or has_nt8_potential_pos
        should_flatten, emergency_reason = news_guardian.check_sentinel_emergency_flatten(should_check, now_madrid)
        if not should_flatten or not emergency_reason:
            return

        # Evitar disparar repetidament cada 15s dins la mateixa finestra (clau per data NY + hora NY)
        win_key = f"{now_ny.strftime('%Y-%m-%d')}_{now_ny.strftime('%H')}"
        if win_key in self.dispatched_news_flattens:
            return
        self.dispatched_news_flattens.add(win_key)

        logger.critical(f"🚨 SENTINEL HARD BREACH SHIELD: {emergency_reason}. Aplanant posicions automàtiques!")
        if has_tradovate_api and has_tradovate_pos:
            tradovate_master.cancel_all_pending_orders()
            tradovate_master.close_all_positions()

        nt8_relayed = False
        if has_nt8_potential_pos:
            nt8_relayed = self._relay_flatten_to_nt8_bridge(emergency_reason)

        nt8_acct_label = getattr(config, "nt8_bot_account", "Sim103")
        notifier.send(
            "🚨 AUTO-FLATTEN D'EMERGÈNCIA: NOTÍCIES RED FOLDER USD",
            f"🛑 **Escut Pre-Notícies activat abans del minut prohibit (`±1 min`).**\n"
            f"📋 **Motiu**: {emergency_reason}\n"
            f"🤖 **Flota Bot LayerSniper (`{nt8_acct_label}`)**: `{'FLATTEN ENVIAT A NT8' if nt8_relayed else ('APLANAT A TRADOVATE' if has_tradovate_pos else 'VERIFICAT')}`\n"
            f"🖱️ **AVÍS FLOTA MANUAL (`Sim102` / Apex / TPT)**: Assegura't d'estar **100% FLAT** i no obrir ordres fins passades les `10:02 NY`!",
            color="danger"
        )

    def check_remote_retest_bot(self) -> bool:
        if not config.retest_bot_url:
            self.remote_bot_healthy = True
            return True
        url = f"{config.retest_bot_url.rstrip('/')}/health"
        try:
            start_t = time.time()
            resp = requests.get(url, timeout=5)
            latency_ms = round((time.time() - start_t) * 1000)
            if resp.status_code == 200:
                self.remote_bot_data = resp.json()
                self.remote_bot_data["latency_ms"] = latency_ms
                self.remote_bot_healthy = True
                self.remote_failures_count = 0
                self.remote_bot_last_check = datetime.datetime.now(datetime.timezone.utc).isoformat()
                return True
        except Exception as e:
            logger.debug(f"Check remote endpoint: {e}")
        self.remote_failures_count += 1
        self.remote_bot_healthy = False
        return False

    def audit_tradovate_and_timings(self, now_madrid: datetime.datetime):
        if kill_switch.is_active:
            return

        now_ny = datetime.datetime.now(self.tz_ny)
        today = now_madrid.date()

        if today.weekday() >= 5 or now_ny.date().weekday() >= 5:
            return

        t_ny = now_ny.hour * 100 + now_ny.minute

        # 0. Vigilant del Cadenat Anti-Tilt Tradovate fins a les 15:00h BCN
        if tradovate_master.is_locked_out(now_madrid):
            tradovate_master._last_orders_time = 0.0
            tradovate_master._last_positions_time = 0.0
            orders = tradovate_master.get_open_orders()
            pos = tradovate_master.get_positions()
            has_pos = any(p.get("netPos", 0) != 0 for p in pos)
            has_orders = any(str(o.get("ordStatus", "")).lower() in ("working", "accepted", "pending") for o in orders)
            if has_pos or has_orders:
                lock_st = tradovate_master.get_lockout_status(now_madrid)
                enf = tradovate_master.enforce_lockout_across_all_accounts()
                logger.critical(
                    f"🔒 SENTINEL LOCKOUT GUARD: Detectada activitat manual durant el cadenat 15:00h BCN! "
                    f"Aplanant automàticament: {enf}"
                )
                notifier.send(
                    "🔒 CADENAT ANTI-TILT 15:00H: ORDRE MANUAL LIQUIDADA",
                    f"🛑 **Els comptes estan bloquejats fins a `{lock_st.get('locked_until_madrid_str')}`.**\n"
                    f"S'ha detectat una ordre o posició fora de sessió i s'ha liquidat a mercat automàticament.\n"
                    f"📋 **Motiu del cadenat**: {lock_st.get('reason')}",
                    color="danger"
                )
            return

        # 1. Verificació d'integritat de Brackets (Cap posició oberta sense Stop Loss)
        bracket_audit = tradovate_master.verify_bracket_integrity()
        if bracket_audit.get("status") == "UNPROTECTED_POSITION":
            now_ts = time.time()
            if now_ts - self.last_unprotected_alert_ts > 300:
                self.last_unprotected_alert_ts = now_ts
                notifier.send(
                    "🚨 ALERTA CRÍTICA: POSICIÓ SENSE STOP LOSS",
                    "S'ha detectat una posició oberta a Tradovate que NO disposa d'ordre Stop Loss associada.\n"
                    "Revisa el broker immediatament o executa el Kill-Switch.",
                    color="danger"
                )
        else:
            self.last_unprotected_alert_ts = 0.0

        # 2. Escut de Notícies Prop Firm (gestionat centralment per check_news_emergency_shield)
        self.check_news_emergency_shield(now_madrid, has_tradovate_api=True)

        # 3. Tall de Seguretat post-sessió matinal (12:30 NY per defecte) + Informe Diari Prop Sim
        self.check_session_cutoff_and_daily_report(now_madrid, has_tradovate_api=True)

        # 4. CME Globex EOD Hard Close (16:55 NY) sobre el compte dedicat Tradovate
        eod_ny = config.eod_close_hour_ny * 100 + config.eod_close_minute_ny
        if not self.daily_events_dispatched["eod_close_1655_ny"]:
            if t_ny >= eod_ny:
                self.daily_events_dispatched["eod_close_1655_ny"] = True
                logger.info("🛡️ Sentinel: CME EOD Hard Close (16:55 NY). Forçant aplanat complet...")
                tradovate_master.cancel_all_pending_orders()
                tradovate_master.close_all_positions()

    def check_session_cutoff_and_daily_report(self, now_madrid: datetime.datetime, has_tradovate_api: bool = False):
        """
        Gestiona el tall de les 12:30 NY (recordatori del cadenat + enviament de l'informe diari al canal DIARI COMPTES),
        tant si operem amb compte Tradovate dedicat com si operem 100% aïllats a Sim103 (NT8/ChartVPS).
        """
        now_ny = datetime.datetime.now(self.tz_ny)
        today = now_madrid.date()
        if today.weekday() >= 5 or now_ny.date().weekday() >= 5:
            return
        t_ny = now_ny.hour * 100 + now_ny.minute
        cutoff_ny = config.session_cutoff_hour_ny * 100 + config.session_cutoff_minute_ny

        if not self.daily_events_dispatched["session_cutoff_1130_ny"]:
            if cutoff_ny <= t_ny <= cutoff_ny + 5:
                self.daily_events_dispatched["session_cutoff_1130_ny"] = True
                if has_tradovate_api:
                    orders = tradovate_master.get_open_orders()
                    pos = tradovate_master.get_positions()
                    has_pos = any(p.get("netPos", 0) != 0 for p in pos)
                    for o in orders:
                        if o.get("ordStatus", "").lower() in ("working", "accepted", "pending") and not has_pos:
                            tradovate_master.cancel_order(o.get("id"))
                if getattr(config, "auto_lock_at_cutoff", True):
                    lock_res = tradovate_master.lock_accounts_until_15h(
                        reason="Tall automàtic de fi de sessió (12:30 NY -> Bloquejat fins demà 09:00 NY)",
                        now_madrid=now_madrid
                    )
                    notifier.send_end_of_session_lockout_reminder(
                        now_madrid=now_madrid,
                        reason=f"Tall automàtic de fi de sessió (12:30 NY -> Desbloqueig: {lock_res.get('locked_until_madrid_str')})"
                    )
                if not self.daily_events_dispatched.get("daily_prop_sim_report_sent", False):
                    self.daily_events_dispatched["daily_prop_sim_report_sent"] = True
                    notifier.send_daily_prop_simulation_report(date_str=now_ny.date().isoformat())
            elif t_ny > cutoff_ny + 5:
                self.daily_events_dispatched["session_cutoff_1130_ny"] = True

    def check_daily_discord_psych_reminders(self, now_madrid: datetime.datetime):
        if now_madrid.weekday() >= 5:
            return
        t_madrid = now_madrid.hour * 100 + now_madrid.minute
        if not self.daily_events_dispatched.get("morning_0800_madrid_reminder", False):
            if 800 <= t_madrid <= 810:
                self.daily_events_dispatched["morning_0800_madrid_reminder"] = True
                logger.info("☀️ Sentinel: Enviant avís matinal de les 08:00h BCN a Discord (Cadenat 15:00h + Psicòleg)...")
                notifier.send_morning_0800_lockout_reminder(now_madrid=now_madrid)
            elif t_madrid > 810:
                self.daily_events_dispatched["morning_0800_madrid_reminder"] = True

    def check_private_fleet_post_session_summary(self, now_madrid: datetime.datetime):
        """
        Envia a les 12:35 NY (Dl-Dv) el quadre resum diari de comptes NT8 EXCLUSIVAMENT al canal privat,
        si s'ha rebut telemetria recent del Fleet Safety Pack i DISCORD_WEBHOOK_URL_PRIVATE_ALERTS està configurat.
        """
        if not getattr(config, "discord_webhook_url_private_alerts", None):
            return
        now_ny = datetime.datetime.now(self.tz_ny)
        if now_madrid.weekday() >= 5 or now_ny.weekday() >= 5:
            return
        if self.daily_events_dispatched.get("private_fleet_summary_sent", False):
            return

        cutoff_dt = now_ny.replace(
            hour=config.session_cutoff_hour_ny,
            minute=config.session_cutoff_minute_ny,
            second=0,
            microsecond=0,
        )
        summary_start = cutoff_dt + datetime.timedelta(minutes=5)
        summary_end = summary_start + datetime.timedelta(minutes=15)

        if summary_start <= now_ny <= summary_end:
            self.daily_events_dispatched["private_fleet_summary_sent"] = True
            try:
                from bot.fleet_safety_monitor import load_latest_fleet_snapshot, format_private_fleet_summary
                latest = load_latest_fleet_snapshot()
                if not latest or not latest.get("accounts"):
                    return
                fmt = format_private_fleet_summary(latest["accounts"], date_label=now_ny.date().isoformat())
                if fmt:
                    title, desc, fields = fmt
                    notifier.send_private_alert(
                        title=title,
                        message=desc,
                        color="purple",
                        fields=fields,
                        allow_weekend=False,
                    )
            except Exception as e:
                logger.warning(f"Error enviant resum privat post-sessió de flota: {e}")
        elif now_ny > summary_end:
            self.daily_events_dispatched["private_fleet_summary_sent"] = True

    def check_private_rollover_reminders(self, now_madrid: datetime.datetime, state_path: Optional[str] = None):
        """
        Detecta el matí exacte en què `MNQ1!` a TradingView salta al nou contracte trimestral CME
        (sigui dijous, divendres o dilluns) i envia dos avisos EXCLUSIVAMENT al canal privat:
          1) `09:00 BCN` (`morning_0900`): avís matinal amb 6,5h de marge abans de l'obertura NY.
          2) `08:30 NY` (`14:30 BCN`, `pre_open`): recordatori de seguretat 1h abans d'obrir NY.
        """
        if not getattr(config, "discord_webhook_url_private_alerts", None):
            return
        now_ny = now_madrid.astimezone(self.tz_ny) if now_madrid.tzinfo else datetime.datetime.now(self.tz_ny)
        if now_madrid.weekday() >= 5 or now_ny.weekday() >= 5:
            return

        from bot.fleet_safety_monitor import evaluate_rollover_private_alert_due

        due = evaluate_rollover_private_alert_due(
            now_madrid=now_madrid,
            now_ny=now_ny,
            symbol_base=config.symbol_base,
            state_path=state_path,
        )
        if due is None:
            return

        title, msg, fields, phase = due
        if phase == "morning_0900":
            self.daily_events_dispatched["rollover_post_close_alert_sent"] = True
        else:
            self.daily_events_dispatched["rollover_pre_open_alert_sent"] = True

        notifier.send_private_alert(
            title=title,
            message=msg,
            color="warning",
            fields=fields,
            allow_weekend=False,
        )

    def run_cycle(self):
        now_madrid = datetime.datetime.now(self.tz_madrid)
        today = now_madrid.date()

        if self.current_day != today:
            self.reset_daily_dispatch(today)

        self.check_daily_discord_psych_reminders(now_madrid)
        self.check_private_fleet_post_session_summary(now_madrid)
        self.check_private_rollover_reminders(now_madrid)
        self.check_remote_retest_bot()

        tv_enabled = bool(getattr(config, "tradovate_direct_enabled", True))
        has_tv_api = tradovate_master.authenticate() if tv_enabled else False
        if has_tv_api:
            self.audit_tradovate_and_timings(now_madrid)
        else:
            # Mode Compte Aïllat (NT8 / Replikanto): sense connexió directa a l'API de Tradovate,
            # però manté actius l'Escut de Notícies (09:58 NY) i el Tancament + Diari Prop Sim (12:30 NY)!
            self.check_news_emergency_shield(now_madrid, has_tradovate_api=False)
            self.check_session_cutoff_and_daily_report(now_madrid, has_tradovate_api=False)

        live_unified_engine.tick(now_madrid)
        self.last_cycle_time = datetime.datetime.now(datetime.timezone.utc).isoformat()

    def get_snapshot(self) -> Dict[str, Any]:
        now_madrid = datetime.datetime.now(self.tz_madrid)
        now_ny = datetime.datetime.now(self.tz_ny)
        today = now_madrid.date()
        macro_info = get_day_trading_status(today)
        seasonality_info = get_seasonality_and_account_timing_advice(today)

        tv_enabled = bool(getattr(config, "tradovate_direct_enabled", True))
        has_creds = tv_enabled and bool(config.user and config.password)
        balance = tradovate_master.get_cash_balance() if has_creds else 50000.0
        positions = tradovate_master.get_positions() if has_creds else []
        working_orders = [
            o for o in (tradovate_master.get_open_orders() if has_creds else [])
            if o.get("ordStatus", "").lower() in ("working", "accepted", "pending")
        ]
        market_price = tradovate_master.get_current_market_price(config.symbol_base)

        t_ny = now_ny.hour * 100 + now_ny.minute
        if 930 <= t_ny < 1000:
            phase_label = "🎯 FINESTRA 1: OBERTURA SNIPER (09:30 - 09:59 NY · L9_1)"
        elif 1000 <= t_ny < 1100:
            phase_label = "🎯 FINESTRA 2: SNIPER 10AM + CONT >=55p (10:00 - 10:59 NY · L10_1 & L10_2)"
        elif 1100 <= t_ny < 1200:
            phase_label = "⚡ FINESTRA 3: EXTENSIÓ CONTINUACIÓ (11:00 - 11:59 NY · L11_1)"
        elif 1200 <= t_ny < 1230:
            phase_label = "🛡️ GESTIÓ POSICIONS OBERTES (Tancament 12:30 NY)"
        else:
            phase_label = "⏸️ FORA DE FINESTRA OPERATIVA (09:30 - 11:59 NY)"

        acct_label = (
            tradovate_master.account_spec or config.account_spec or "SENSE-COMPTE-API"
            if tv_enabled
            else f"{getattr(config, 'nt8_bot_account', 'Sim103')} (NT8 Dedicat)"
        )

        return {
            "service": "JJ Layer Sniper Pro 2026 Sentinel",
            "mode": config.engine_mode,
            "env": config.tradovate_env if tv_enabled else "nt8_relay_isolated",
            "account_role": config.account_role,
            "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "session_phase": phase_label,
            "clocks": {
                "barcelona_cest": now_madrid.strftime("%H:%M:%S"),
                "barcelona_tz": now_madrid.strftime("%Z"),
                "new_york_edt": now_ny.strftime("%H:%M:%S"),
                "new_york_tz": now_ny.strftime("%Z"),
                "date": today.strftime("%d/%m/%Y"),
                "dst_gap_hours": config.dst_gap_hours,
                "is_dst_divergence": config.is_dst_divergence,
                "dst_status_label": "⚠️ Desfasament DST (5h)" if config.is_dst_divergence else "Sincronitzat (6h)",
                "sniper_window_bcn": "14:30 - 17:59 BCN" if config.is_dst_divergence else "15:30 - 18:59 BCN"
            },
            "macro_status": macro_info,
            "seasonality_radar": seasonality_info,
            "account": {
                "account_spec": acct_label,
                "account_id": tradovate_master.account_id if tv_enabled else None,
                "balance": balance,
                "open_positions": positions,
                "open_orders": working_orders,
                "market_price": market_price,
                "active_contract": live_unified_engine.active_symbol
            },
            "sniper_stats": {
                "trades_today": live_unified_engine.trades_executed_today,
                "bloc_a_today": live_unified_engine.bloc_a_executed_today,
                "bloc_b_today": live_unified_engine.bloc_b_executed_today,
                "breakevens_today": live_unified_engine.breakevens_triggered_today,
                "last_signal": live_unified_engine.last_signal_info,
                "history_today": live_unified_engine.signal_history_today,
                "forward_webhook_url": config.forward_webhook_url,
            },
            "lockout": tradovate_master.get_lockout_status(now_madrid),
            "kill_switch_active": kill_switch.is_active
        }


sentinel = LayerSniperSentinel()
