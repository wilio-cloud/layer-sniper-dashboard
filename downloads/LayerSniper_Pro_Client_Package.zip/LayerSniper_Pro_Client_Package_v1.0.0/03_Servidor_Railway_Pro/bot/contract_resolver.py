import os
import time
import datetime
import logging
from typing import Optional, Dict, Any, List, Tuple
import requests

logger = logging.getLogger("ContractResolver")

# Mesos de venciment CME Equity Index: H=Març, M=Juny, U=Setembre, Z=Desembre
EXPIRATION_MONTH_CODES = {
    3: "H",
    6: "M",
    9: "U",
    12: "Z",
}

TV_SCANNER_FUTURES_URL = "https://scanner.tradingview.com/futures/scan"
_TV_CONTRACT_CACHE: Dict[Tuple[str, str], Tuple[float, Dict[str, Any]]] = {}
_TV_CACHE_TTL_SECONDS = 900.0  # 15 minuts


def _normalize_base_symbol(symbol_base: str = "MNQ") -> str:
    clean = str(symbol_base or "MNQ").upper().replace("!", "").strip()
    if "NQ" in clean and "MNQ" not in clean:
        return "NQ"
    if "ES" in clean and "MES" not in clean:
        return "ES"
    if "MES" in clean:
        return "MES"
    return "MNQ"


def get_rollover_quarter_pair(symbol_base: str = "MNQ", dt: Optional[datetime.date] = None) -> Optional[Dict[str, str]]:
    """
    Si `dt` cau dins la finestra de rollover trimestral (dies 4..21 de Març, Juny, Setembre o Desembre),
    retorna els identificadors exactes del contracte que venç i del següent tant per a TradingView com per a NT8.
    Fora d'aquesta finestra retorna None (cap ambigüitat de contracte).
    """
    d = dt or datetime.date.today()
    if d.month not in (3, 6, 9, 12) or not (4 <= d.day <= 21):
        return None

    base = _normalize_base_symbol(symbol_base)
    exp_q = d.month
    exp_y = d.year
    if exp_q == 12:
        nxt_q = 3
        nxt_y = d.year + 1
    else:
        nxt_q = exp_q + 3
        nxt_y = d.year

    exp_code = EXPIRATION_MONTH_CODES[exp_q]
    nxt_code = EXPIRATION_MONTH_CODES[nxt_q]

    return {
        "base": base,
        "tv_continuous": f"CME_MINI:{base}1!",
        "tv_expiring": f"CME_MINI:{base}{exp_code}{exp_y}",
        "tv_next": f"CME_MINI:{base}{nxt_code}{nxt_y}",
        "nt8_expiring": f"{base} {exp_q:02d}-{str(exp_y)[-2:]}",
        "nt8_next": f"{base} {nxt_q:02d}-{str(nxt_y)[-2:]}",
        "code_expiring": f"{base}{exp_code}{str(exp_y)[-1]}",
        "code_next": f"{base}{nxt_code}{str(nxt_y)[-1]}",
    }


def _fetch_tradingview_scanner_rows(tickers: List[str]) -> Dict[str, List[Any]]:
    """Consulta l'endpoint públic d'escàner de futurs de TradingView i retorna {ticker: [open, high, low, close, volume]}."""
    resp = requests.post(
        TV_SCANNER_FUTURES_URL,
        json={
            "symbols": {"tickers": tickers},
            "columns": ["open", "high", "low", "close", "volume"],
        },
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=4.0,
    )
    resp.raise_for_status()
    payload = resp.json()
    rows: Dict[str, List[Any]] = {}
    for item in payload.get("data") or []:
        if isinstance(item, dict) and item.get("s") and isinstance(item.get("d"), list):
            rows[str(item["s"])] = item["d"]
    return rows


_ORIG_FETCH_TV_SCANNER_ROWS = _fetch_tradingview_scanner_rows


def _match_tv_continuous_to_quarter(
    rows: Dict[str, List[Any]],
    pair: Dict[str, str],
) -> Optional[str]:
    """
    Compara l'OHLCV de `CME_MINI:<BASE>1!` amb el contracte actual i el següent.
    Retorna `'next'` si `1!` ja apunta al nou contracte, `'expiring'` si continua al vigent, o `None` si les dades són incompletes.
    """
    d_cont = rows.get(pair["tv_continuous"])
    d_exp = rows.get(pair["tv_expiring"])
    d_nxt = rows.get(pair["tv_next"])
    if not d_cont or len(d_cont) < 5 or not d_exp or len(d_exp) < 5 or not d_nxt or len(d_nxt) < 5:
        return None

    try:
        c_cont, v_cont = float(d_cont[3]), float(d_cont[4] or 0)
        c_exp, v_exp = float(d_exp[3]), float(d_exp[4] or 0)
        c_nxt, v_nxt = float(d_nxt[3]), float(d_nxt[4] or 0)
    except (TypeError, ValueError):
        return None

    # 1. Coincidència exacta d'àlies (preu + volum idèntics)
    if abs(c_cont - c_nxt) <= 0.50 and abs(v_cont - v_nxt) <= max(5.0, v_cont * 0.001):
        return "next"
    if abs(c_cont - c_exp) <= 0.50 and abs(v_cont - v_exp) <= max(5.0, v_cont * 0.001):
        return "expiring"

    # 2. Coincidència per distància de preu quan hi ha spread de carry (> 10p) entre venciments
    if abs(c_nxt - c_exp) >= 10.0:
        dist_nxt = abs(c_cont - c_nxt)
        dist_exp = abs(c_cont - c_exp)
        if dist_nxt < dist_exp and dist_nxt <= 5.0:
            return "next"
        if dist_exp < dist_nxt and dist_exp <= 5.0:
            return "expiring"

    return None


def get_nt8_contract_name_for_date(symbol_base: str = "MNQ", dt: Optional[datetime.date] = None) -> str:
    """
    Retorna el nom de contracte a NinjaTrader 8 / Replikanto per calendari pur (`dia < 12` als mesos 3, 6, 9 i 12).
    """
    base = _normalize_base_symbol(symbol_base)
    d = dt or datetime.date.today()
    year, month, day = d.year, d.month, d.day
    quarters = (3, 6, 9, 12)
    target_q = None
    target_y = year

    for q in quarters:
        if month < q or (month == q and day < 12):
            target_q = q
            break

    if target_q is None:
        target_q = 3
        target_y = year + 1

    return f"{base} {target_q:02d}-{str(target_y)[-2:]}"


def detect_tradingview_active_nt8_contract(
    symbol_base: str = "MNQ",
    dt: Optional[datetime.date] = None,
    force_refresh: bool = False,
) -> Dict[str, Any]:
    """
    Detecta quin contracte exacte porta `CME_MINI:<BASE>1!` a TradingView durant la finestra de rollover:
      - Fora dels dies 4..21 de Març/Juny/Setembre/Desembre: retorna directament el contracte de calendari (0 crides HTTP).
      - Dins la finestra de rollover: consulta `scanner.tradingview.com/futures/scan` (amb memòria cau de 15 min)
        i fa fallback net al calendari (`dia < 12`) si no hi ha xarxa.
    """
    base = _normalize_base_symbol(symbol_base)
    d = dt or datetime.date.today()
    cal_nt8 = get_nt8_contract_name_for_date(symbol_base=base, dt=d)
    pair = get_rollover_quarter_pair(symbol_base=base, dt=d)

    if pair is None:
        return {
            "date": d.isoformat(),
            "base": base,
            "active_nt8": cal_nt8,
            "in_rollover_window": False,
            "switched_to_next": False,
            "old_nt8": cal_nt8,
            "new_nt8": cal_nt8,
            "source": "calendar",
        }

    cache_key = (base, d.isoformat())
    now_ts = time.time()
    if not force_refresh and cache_key in _TV_CONTRACT_CACHE:
        cached_ts, cached_val = _TV_CONTRACT_CACHE[cache_key]
        if (now_ts - cached_ts) < _TV_CACHE_TTL_SECONDS:
            return dict(cached_val)

    # En tests unitaris sense mock explícit, evitar crides de xarxa reals
    is_unmocked_pytest = (
        "PYTEST_CURRENT_TEST" in os.environ
        and _fetch_tradingview_scanner_rows is _ORIG_FETCH_TV_SCANNER_ROWS
        and not force_refresh
    )

    matched_side: Optional[str] = None
    if not is_unmocked_pytest:
        try:
            rows = _fetch_tradingview_scanner_rows([
                pair["tv_continuous"],
                pair["tv_expiring"],
                pair["tv_next"],
            ])
            matched_side = _match_tv_continuous_to_quarter(rows, pair)
        except Exception as e:
            logger.debug(f"Info consultant TradingView scanner per a rollover ({base}): {e}")

    if matched_side == "next":
        active_nt8 = pair["nt8_next"]
        switched = True
        source = "tradingview_live"
    elif matched_side == "expiring":
        active_nt8 = pair["nt8_expiring"]
        switched = False
        source = "tradingview_live"
    else:
        active_nt8 = cal_nt8
        switched = (cal_nt8 == pair["nt8_next"])
        source = "calendar_fallback"

    result = {
        "date": d.isoformat(),
        "base": base,
        "active_nt8": active_nt8,
        "in_rollover_window": True,
        "switched_to_next": switched,
        "old_nt8": pair["nt8_expiring"],
        "new_nt8": pair["nt8_next"],
        "tv_continuous": pair["tv_continuous"],
        "source": source,
    }
    _TV_CONTRACT_CACHE[cache_key] = (now_ts, dict(result))
    return result


def get_current_front_month_code(symbol_base: str = "MNQ", now: Optional[datetime.datetime] = None) -> str:
    """
    Retorna el codi del contracte actiu (ex: MNQZ6 per a Desembre 2026 o MNQH7 un cop `MNQ1!` ha saltat).
    """
    base = _normalize_base_symbol(symbol_base)
    if now is None:
        now = datetime.datetime.now()

    pair = get_rollover_quarter_pair(symbol_base=base, dt=now.date())
    if pair is not None:
        tv_info = detect_tradingview_active_nt8_contract(symbol_base=base, dt=now.date())
        return pair["code_next"] if tv_info["switched_to_next"] else pair["code_expiring"]

    year = now.year
    month = now.month
    day = now.day

    quarters = [3, 6, 9, 12]
    target_month = None
    target_year = year

    for qm in quarters:
        if month < qm or (month == qm and day < 12):
            target_month = qm
            break

    if target_month is None:
        target_month = 3
        target_year = year + 1

    month_code = EXPIRATION_MONTH_CODES[target_month]
    year_digit = str(target_year)[-1]
    return f"{base}{month_code}{year_digit}"


def resolve_active_contract(client=None, symbol_base: str = "MNQ") -> str:
    """
    Resol el contracte actiu consultant directament Tradovate si hi ha client connectat,
    o sincronitzat amb `MNQ1!` de TradingView / calendari CME institucional.
    """
    if client:
        try:
            suggested = client.suggest_contract(symbol_base)
            if suggested:
                logger.info(f"Contracte actiu resolt per Tradovate API: {suggested}")
                return suggested
        except Exception as e:
            logger.debug(f"No s'ha pogut suggerir contracte per API: {e}")

    fallback_symbol = get_current_front_month_code(symbol_base=symbol_base)
    logger.info(f"Contracte actiu resolt: {fallback_symbol}")
    return fallback_symbol


def _next_weekday(d: datetime.date) -> datetime.date:
    nxt = d + datetime.timedelta(days=1)
    while nxt.weekday() >= 5:
        nxt += datetime.timedelta(days=1)
    return nxt


def _prev_weekday(d: datetime.date) -> datetime.date:
    prv = d - datetime.timedelta(days=1)
    while prv.weekday() >= 5:
        prv -= datetime.timedelta(days=1)
    return prv


def check_cme_rollover_transition(today_ny: datetime.date, symbol_base: str = "MNQ") -> Dict[str, Any]:
    """
    Retorna la transició per calendari pur (`dia < 12`) i també l'estat real de `MNQ1!` a TradingView.
    """
    cur_nt8 = get_nt8_contract_name_for_date(symbol_base=symbol_base, dt=today_ny)
    nxt_day = _next_weekday(today_ny)
    prv_day = _prev_weekday(today_ny)
    nxt_nt8 = get_nt8_contract_name_for_date(symbol_base=symbol_base, dt=nxt_day)
    prv_nt8 = get_nt8_contract_name_for_date(symbol_base=symbol_base, dt=prv_day)

    tv_status = detect_tradingview_active_nt8_contract(symbol_base=symbol_base, dt=today_ny)
    is_weekday = today_ny.weekday() < 5
    return {
        "date": today_ny.isoformat(),
        "current_nt8": cur_nt8,
        "next_trading_day": nxt_day.isoformat(),
        "next_nt8": nxt_nt8,
        "prev_trading_day": prv_day.isoformat(),
        "prev_nt8": prv_nt8,
        "is_last_day_before_switch": is_weekday and (cur_nt8 != nxt_nt8),
        "is_first_day_after_switch": is_weekday and (prv_nt8 != cur_nt8),
        "tv_active_nt8": tv_status["active_nt8"],
        "tv_switched_to_next": tv_status["switched_to_next"],
        "tv_old_nt8": tv_status["old_nt8"],
        "tv_new_nt8": tv_status["new_nt8"],
        "tv_source": tv_status["source"],
        "in_rollover_window": tv_status["in_rollover_window"],
    }
