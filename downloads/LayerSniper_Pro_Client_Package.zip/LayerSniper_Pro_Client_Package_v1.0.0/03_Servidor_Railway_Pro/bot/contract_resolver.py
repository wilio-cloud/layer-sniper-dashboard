import datetime
import logging
from typing import Optional, Dict, Any

logger = logging.getLogger("ContractResolver")

# Mesos de venciment CME Equity Index: H=Març, M=Juny, U=Setembre, Z=Desembre
EXPIRATION_MONTH_CODES = {
    3: "H",
    6: "M",
    9: "U",
    12: "Z"
}


def get_current_front_month_code(symbol_base: str = "MNQ", now: Optional[datetime.datetime] = None) -> str:
    """
    Retorna el codi del contracte actiu (ex: MNQZ6 per a Desembre 2026).
    El roll institucional es produeix al voltant del segon dijous del mes de venciment (dia ~10-14).
    """
    if now is None:
        now = datetime.datetime.now()

    year = now.year
    month = now.month
    day = now.day

    quarters = [3, 6, 9, 12]
    target_month = None
    target_year = year

    for qm in quarters:
        if month < qm:
            target_month = qm
            break
        elif month == qm:
            if day < 12:
                target_month = qm
            else:
                pass
            break

    if target_month is None:
        for qm in quarters:
            if qm > month:
                target_month = qm
                break
        if target_month is None:
            target_month = 3
            target_year = year + 1

    month_code = EXPIRATION_MONTH_CODES[target_month]
    year_digit = str(target_year)[-1]

    return f"{symbol_base}{month_code}{year_digit}"


def resolve_active_contract(client=None, symbol_base: str = "MNQ") -> str:
    """
    Resol el contracte actiu consultant directament Tradovate si hi ha client connectat,
    o calculant-lo automàticament per calendari CME institucional.
    """
    if client:
        try:
            suggested = client.suggest_contract(symbol_base)
            if suggested:
                logger.info(f"Contracte actiu resolt per Tradovate API: {suggested}")
                return suggested
        except Exception as e:
            logger.debug(f"No s'ha pogut suggerir contracte per API: {e}")

    fallback_symbol = get_current_front_month_code(symbol_base=symbol_base)
    logger.info(f"Contracte actiu per calendari: {fallback_symbol}")
    return fallback_symbol


def get_nt8_contract_name_for_date(symbol_base: str = "MNQ", dt: Optional[datetime.date] = None) -> str:
    """
    Retorna el nom exacte del contracte a NinjaTrader 8 / Replikanto (ex: 'MNQ 12-26' o 'MNQ 03-27')
    seguint la mateixa regla del Bridge (`dia < 12` als mesos trimestrals 3, 6, 9 i 12).
    """
    d = dt or datetime.date.today()
    year, month, day = d.year, d.month, d.day
    quarters = (3, 6, 9, 12)
    target_q = None
    target_y = year

    for q in quarters:
        if month < q or (month == q and day < 12):
            target_q = q
            break

    if target_q is None:
        target_q = 3
        target_y = year + 1

    return f"{symbol_base} {target_q:02d}-{str(target_y)[-2:]}"


def _next_weekday(d: datetime.date) -> datetime.date:
    nxt = d + datetime.timedelta(days=1)
    while nxt.weekday() >= 5:
        nxt += datetime.timedelta(days=1)
    return nxt


def _prev_weekday(d: datetime.date) -> datetime.date:
    prv = d - datetime.timedelta(days=1)
    while prv.weekday() >= 5:
        prv -= datetime.timedelta(days=1)
    return prv


def check_cme_rollover_transition(today_ny: datetime.date, symbol_base: str = "MNQ") -> Dict[str, Any]:
    """
    Detecta si `today_ny` (dia hàbil Dl-Dv) és:
      - `is_last_day_before_switch`: última sessió abans que el Bridge passi al nou contracte trimestral
        (ex: Divendres 11/12/2026 abans de passar de 'MNQ 12-26' a 'MNQ 03-27' pel Dilluns 14/12/2026).
      - `is_first_day_after_switch`: primera sessió on el Bridge ja opera amb el nou contracte trimestral
        (ex: Dilluns 14/12/2026 estrenant 'MNQ 03-27').
    """
    cur_nt8 = get_nt8_contract_name_for_date(symbol_base=symbol_base, dt=today_ny)
    nxt_day = _next_weekday(today_ny)
    prv_day = _prev_weekday(today_ny)
    nxt_nt8 = get_nt8_contract_name_for_date(symbol_base=symbol_base, dt=nxt_day)
    prv_nt8 = get_nt8_contract_name_for_date(symbol_base=symbol_base, dt=prv_day)

    is_weekday = today_ny.weekday() < 5
    return {
        "date": today_ny.isoformat(),
        "current_nt8": cur_nt8,
        "next_trading_day": nxt_day.isoformat(),
        "next_nt8": nxt_nt8,
        "prev_trading_day": prv_day.isoformat(),
        "prev_nt8": prv_nt8,
        "is_last_day_before_switch": is_weekday and (cur_nt8 != nxt_nt8),
        "is_first_day_after_switch": is_weekday and (prv_nt8 != cur_nt8),
    }
