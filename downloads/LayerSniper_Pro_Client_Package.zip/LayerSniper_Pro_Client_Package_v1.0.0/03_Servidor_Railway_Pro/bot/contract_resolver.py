import datetime
import logging
from typing import Optional

logger = logging.getLogger("ContractResolver")

# Mesos de venciment CME Equity Index: H=Març, M=Juny, U=Setembre, Z=Desembre
EXPIRATION_MONTH_CODES = {
    3: "H",
    6: "M",
    9: "U",
    12: "Z"
}


def get_current_front_month_code(symbol_base: str = "MNQ", now: Optional[datetime.datetime] = None) -> str:
    """
    Retorna el codi del contracte actiu (ex: MNQZ6 per a Desembre 2026).
    El roll institucional es produeix al voltant del segon dijous del mes de venciment (dia ~10-14).
    """
    if now is None:
        now = datetime.datetime.now()

    year = now.year
    month = now.month
    day = now.day

    quarters = [3, 6, 9, 12]
    target_month = None
    target_year = year

    for qm in quarters:
        if month < qm:
            target_month = qm
            break
        elif month == qm:
            if day < 12:
                target_month = qm
            else:
                pass
            break

    if target_month is None:
        for qm in quarters:
            if qm > month:
                target_month = qm
                break
        if target_month is None:
            target_month = 3
            target_year = year + 1

    month_code = EXPIRATION_MONTH_CODES[target_month]
    year_digit = str(target_year)[-1]

    return f"{symbol_base}{month_code}{year_digit}"


def resolve_active_contract(client=None, symbol_base: str = "MNQ") -> str:
    """
    Resol el contracte actiu consultant directament Tradovate si hi ha client connectat,
    o calculant-lo automàticament per calendari CME institucional.
    """
    if client:
        try:
            suggested = client.suggest_contract(symbol_base)
            if suggested:
                logger.info(f"Contracte actiu resolt per Tradovate API: {suggested}")
                return suggested
        except Exception as e:
            logger.debug(f"No s'ha pogut suggerir contracte per API: {e}")

    fallback_symbol = get_current_front_month_code(symbol_base=symbol_base)
    logger.info(f"Contracte actiu per calendari: {fallback_symbol}")
    return fallback_symbol
