import logging
import datetime
from typing import Dict, Any
from bot.tradovate_master import tradovate_master
from bot.notifier import notifier

logger = logging.getLogger("KillSwitch")


class EmergencyKillSwitch:
    """
    Protocol d'emergència i circuit breaker de màxima prioritat.
    Atura qualsevol bot, cancel·la totes les ordres pendents i liquida a mercat
    qualsevol posició oberta en qüestió de mil·lisegons.
    """
    def __init__(self):
        self._triggered: bool = False
        self._trigger_reason: str = ""
        self._triggered_at: str = ""

    @property
    def is_active(self) -> bool:
        return self._triggered

    @property
    def trigger_reason(self) -> str:
        return self._trigger_reason

    @property
    def triggered_at(self) -> str:
        return self._triggered_at

    def trigger(self, reason: str = "Pànic Manual / Botó d'Emergència") -> Dict[str, Any]:
        self._triggered = True
        self._trigger_reason = reason
        self._triggered_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

        logger.critical(f"🚨 EMERGENCY KILL-SWITCH ACTIVAT! Motiu: {reason}")

        canceled_count = tradovate_master.cancel_all_pending_orders()
        flatten_ok = tradovate_master.close_all_positions()

        msg = (
            f"🚨🚨 **EMERGENCY KILL-SWITCH EXECUTAT** 🚨🚨\n\n"
            f"⚠️ **Motiu**: `{reason}`\n"
            f"🛑 **Ordres cancel·lades**: `{canceled_count}`\n"
            f"⚡ **Posicions aplanades (Flatten)**: `{'ÈXIT' if flatten_ok else 'REVISAR BROKER'}`\n"
            f"🔒 **Estat del Sistema**: Bots en pausa forçada fins a reinici manual."
        )
        notifier.send("🚨 KILL-SWITCH D'EMERGÈNCIA ACTIVAT", msg, color="danger", sync=True)

        return {
            "status": "KILLSWITCH_TRIGGERED",
            "reason": reason,
            "canceled_orders": canceled_count,
            "positions_flattened": flatten_ok,
            "timestamp": self._triggered_at
        }

    def reset(self, notify: bool = True) -> Dict[str, Any]:
        was_active = self._triggered
        logger.info("🔄 Emergency Kill-Switch reiniciat per l'operador.")
        self._triggered = False
        self._trigger_reason = ""
        self._triggered_at = ""
        if notify and was_active:
            notifier.send("✅ KILL-SWITCH REINICIAT", "El sistema Layer Sniper ha tornat a l'estat operatiu normal.", color="blue")
        return {"status": "RESET_OK", "was_active": was_active}


kill_switch = EmergencyKillSwitch()
