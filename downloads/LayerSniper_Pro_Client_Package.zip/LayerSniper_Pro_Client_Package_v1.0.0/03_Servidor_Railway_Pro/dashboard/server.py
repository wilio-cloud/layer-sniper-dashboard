import os
import sys
import threading
import time
import datetime
import logging
import json
import hmac
import hashlib
import secrets
import urllib.parse
from typing import Dict, Any
from contextlib import asynccontextmanager
import requests
import io
import zipfile
from fastapi import FastAPI, Request, Depends, HTTPException, status
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response, RedirectResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import uvicorn

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from bot.config import config
from bot.sentinel import sentinel
from bot.emergency_killswitch import kill_switch
from bot.notifier import notifier
from bot.tradovate_master import tradovate_master
from bot.anti_hedging_guard import anti_hedging_guard
from bot.live_engine import live_unified_engine
from bot.position_sizer import position_sizer
from bot.news_guardian import news_guardian
from bot.contract_resolver import resolve_active_contract

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] (%(name)s) %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("bot.log", encoding="utf-8")
    ]
)
logger = logging.getLogger("DashboardServer")

sentinel_running = True
security = HTTPBasic(auto_error=False)


def verify_dashboard_auth(credentials: HTTPBasicCredentials = Depends(security)):
    """Protegeix el Dashboard Web i els botons de control amb Usuari i Contrasenya (HTTP Basic Auth)."""
    expected_user = getattr(config, "dashboard_user", "admin") or "admin"
    expected_pass = getattr(config, "dashboard_pass", "sniper2026!") or "sniper2026!"
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Accés restringit al Dashboard Layer Sniper Pro",
            headers={"WWW-Authenticate": 'Basic realm="Layer Sniper Pro"'},
        )
    correct_user = secrets.compare_digest(credentials.username.encode("utf8"), expected_user.encode("utf8"))
    correct_pass = secrets.compare_digest(credentials.password.encode("utf8"), expected_pass.encode("utf8"))
    if not (correct_user and correct_pass):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Credencials incorrectes",
            headers={"WWW-Authenticate": 'Basic realm="Layer Sniper Pro"'},
        )
    return credentials.username


PORTAL_COOKIE_NAME = "ls_portal_session"


def _portal_expected_pairs():
    p_user = getattr(config, "portal_user", "sniper") or "sniper"
    p_pass = getattr(config, "portal_pass", "sniperportal2026!") or "sniperportal2026!"
    d_user = getattr(config, "dashboard_user", "admin") or "admin"
    d_pass = getattr(config, "dashboard_pass", "sniper2026!") or "sniper2026!"
    return [(p_user, p_pass), (d_user, d_pass)]


def _check_portal_credentials(username: str, password: str) -> bool:
    u_bytes = (username or "").encode("utf-8")
    p_bytes = (password or "").encode("utf-8")
    for exp_u, exp_p in _portal_expected_pairs():
        if secrets.compare_digest(u_bytes, exp_u.encode("utf-8")) and secrets.compare_digest(p_bytes, exp_p.encode("utf-8")):
            return True
    return False


def _build_portal_session_token() -> str:
    p_user = getattr(config, "portal_user", "sniper") or "sniper"
    p_pass = getattr(config, "portal_pass", "sniperportal2026!") or "sniperportal2026!"
    key = f"ls-portal-v1:{p_user}:{p_pass}".encode("utf-8")
    return hmac.new(key, b"authorized-portal-member", hashlib.sha256).hexdigest()


def _is_portal_authenticated(request: Request, credentials: HTTPBasicCredentials = None) -> bool:
    cookie_val = request.cookies.get(PORTAL_COOKIE_NAME, "")
    expected_token = _build_portal_session_token()
    if cookie_val and secrets.compare_digest(cookie_val.encode("utf-8"), expected_token.encode("utf-8")):
        return True
    if credentials and _check_portal_credentials(credentials.username, credentials.password):
        return True
    return False


def verify_portal_auth(request: Request, credentials: HTTPBasicCredentials = Depends(security)):
    """Protegeix els endpoints del Portal d'Instal·lació (aïllat del HUD d'administrador)."""
    if _is_portal_authenticated(request, credentials):
        return True
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Accés restringit al Portal d'Instal·lació Layer Sniper Pro",
        headers={"WWW-Authenticate": 'Basic realm="Layer Sniper Pro Portal"'},
    )


def _render_portal_login_html(error_msg: str = "") -> str:
    err_html = (
        f'<div class="mb-5 px-4 py-3 rounded-lg bg-[#F43F5E]/10 border border-[#F43F5E]/35 text-xs text-[#FDA4AF] font-mono tracking-tight flex items-center gap-2.5">'
        f'<span class="w-1.5 h-1.5 rounded-full bg-[#F43F5E] shrink-0"></span><span>{error_msg}</span></div>'
        if error_msg else ""
    )
    return f"""<!DOCTYPE html>
<html lang="ca" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>LAYER SNIPER PRO // Private Deployment Vault</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    :root {{
      --bg-void: #050506;
      --gold: #D4AF37;
      --gold-bright: #F3DC99;
    }}
    body {{
      background-color: var(--bg-void);
      color: #F4F4F6;
      font-family: 'Inter', sans-serif;
      background-image:
        radial-gradient(ellipse 65% 45% at 50% 0%, rgba(212, 175, 55, 0.11), transparent 72%),
        linear-gradient(to right, rgba(255, 255, 255, 0.022) 1px, transparent 1px),
        linear-gradient(to bottom, rgba(255, 255, 255, 0.022) 1px, transparent 1px);
      background-size: 100% 100%, 48px 48px, 48px 48px;
      overflow: hidden;
    }}
    .font-display {{ font-family: 'Space Grotesk', sans-serif; letter-spacing: -0.03em; }}
    .font-mono-tech {{ font-family: 'JetBrains Mono', monospace; }}
    @keyframes slowOrbit {{
      from {{ transform: translate(-50%, -50%) rotate(0deg); }}
      to   {{ transform: translate(-50%, -50%) rotate(360deg); }}
    }}
    .reticle-orbit {{
      position: fixed;
      top: 50%;
      left: 50%;
      width: 660px;
      height: 660px;
      pointer-events: none;
      animation: slowOrbit 110s linear infinite;
      opacity: 0.55;
    }}
    .vault-card {{
      position: relative;
      background: linear-gradient(180deg, rgba(16, 16, 20, 0.88) 0%, rgba(8, 8, 11, 0.95) 100%);
      backdrop-filter: blur(28px);
      border: 1px solid rgba(255, 255, 255, 0.075);
      box-shadow: 0 30px 90px rgba(0, 0, 0, 0.85), inset 0 1px 0 rgba(243, 220, 153, 0.25);
    }}
    .vault-input {{
      background: rgba(4, 4, 6, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.09);
      transition: all 0.22s ease;
    }}
    .vault-input:focus {{
      border-color: rgba(212, 175, 55, 0.65);
      box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.12);
      outline: none;
    }}
    .gold-cta {{
      background: linear-gradient(135deg, #F5E1A4 0%, #D4AF37 52%, #A67F1E 100%);
      color: #050506;
      box-shadow: 0 10px 30px -8px rgba(212, 175, 55, 0.45), inset 0 1px 0 rgba(255, 255, 255, 0.55);
      transition: transform 0.18s ease, box-shadow 0.22s ease, filter 0.22s ease;
    }}
    .gold-cta:hover {{
      filter: brightness(1.06);
      transform: translateY(-1px);
      box-shadow: 0 16px 36px -8px rgba(212, 175, 55, 0.6);
    }}
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-5 antialiased">

  <!-- Precision Architectural SVG Reticle Background -->
  <svg class="reticle-orbit" viewBox="0 0 600 600" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="300" cy="300" r="285" stroke="rgba(255,255,255,0.04)" stroke-width="1"/>
    <circle cx="300" cy="300" r="235" stroke="rgba(212,175,55,0.14)" stroke-width="1" stroke-dasharray="3 9"/>
    <circle cx="300" cy="300" r="175" stroke="rgba(255,255,255,0.035)" stroke-width="1"/>
    <line x1="300" y1="0" x2="300" y2="600" stroke="rgba(212,175,55,0.07)" stroke-width="1"/>
    <line x1="0" y1="300" x2="600" y2="300" stroke="rgba(212,175,55,0.07)" stroke-width="1"/>
    <polygon points="300,52 306,64 294,64" fill="rgba(212,175,55,0.45)"/>
  </svg>

  <div class="vault-card w-full max-w-[430px] rounded-2xl p-8 sm:p-9 z-10">
    <!-- Top Specular Gold Hairline -->
    <div class="flex items-center justify-between text-[10px] font-mono-tech uppercase tracking-[0.18em] text-[#8E929F] pb-5 mb-6 border-b border-white/[0.06]">
      <span class="flex items-center gap-2 text-[#E5C158]">
        <span class="w-1.5 h-1.5 rounded-full bg-[#E5C158]"></span>
        PRIVATE VAULT
      </span>
      <span>CME // MNQ QUANT</span>
    </div>

    <div class="mb-7">
      <div class="flex items-center gap-3.5 mb-3">
        <!-- Bespoke Geometric Reticle Emblem -->
        <div class="w-11 h-11 rounded-xl bg-gradient-to-b from-[#D4AF37]/20 to-transparent border border-[#D4AF37]/40 flex items-center justify-center shrink-0">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <polygon points="12,2 22,12 12,22 2,12" stroke="#F3DC99" stroke-width="1.4"/>
            <circle cx="12" cy="12" r="3" fill="#D4AF37"/>
            <line x1="12" y1="2" x2="12" y2="6" stroke="#D4AF37" stroke-width="1.4"/>
            <line x1="12" y1="18" x2="12" y2="22" stroke="#D4AF37" stroke-width="1.4"/>
          </svg>
        </div>
        <div>
          <h1 class="font-display text-2xl font-bold text-white leading-none">Layer Sniper Pro</h1>
          <p class="font-mono-tech text-[11px] text-[#8E929F] mt-1.5">DEPLOYMENT &amp; EXECUTION CONSOLE</p>
        </div>
      </div>
      <p class="text-xs text-[#9CA3AF] leading-relaxed">
        Introdueix les credencials autoritzades per accedir a l'arquitectura d'instal·lació interactiva i al cofre d'actualitzacions oficials.
      </p>
    </div>

    {err_html}

    <form method="POST" action="/portal/login" class="space-y-4">
      <div>
        <label class="block font-mono-tech text-[10px] uppercase tracking-[0.14em] text-[#A1A1AA] mb-2">Identificador d'Usuari</label>
        <input type="text" name="username" required autofocus autocomplete="username" placeholder="usuari"
          class="vault-input w-full rounded-xl px-4 py-3 text-sm text-white font-mono-tech placeholder:text-zinc-600">
      </div>
      <div>
        <label class="block font-mono-tech text-[10px] uppercase tracking-[0.14em] text-[#A1A1AA] mb-2">Clau d'Accés</label>
        <input type="password" name="password" required autocomplete="current-password" placeholder="••••••••••••"
          class="vault-input w-full rounded-xl px-4 py-3 text-sm text-white font-mono-tech placeholder:text-zinc-600">
      </div>
      <div class="pt-2">
        <button type="submit" class="gold-cta w-full py-3.5 rounded-xl font-display font-bold text-sm tracking-wide flex items-center justify-center gap-2">
          <span>DESBLOQUEJAR CONSOLA</span>
          <span class="font-mono-tech text-xs">&rarr;</span>
        </button>
      </div>
    </form>

    <div class="mt-6 pt-4 border-t border-white/[0.05] flex items-center justify-between text-[10px] font-mono-tech text-zinc-500">
      <span>ISOLATED SESSION // TLS</span>
      <span>ZERO-LEAK AUDITED</span>
    </div>
  </div>
</body>
</html>"""

# Comptador d'execucions per estratègia i dia: { date: { strat_key: count } }
executed_counts_today: Dict[datetime.date, Dict[str, int]] = {}
# Registre compatibilitat llista d'estratègies executades avui
executed_strategies_today: Dict[datetime.date, set] = {}


def sentinel_daemon_worker():
    logger.info("🛡️ Daemon Sentinel Layer Sniper engegat en segon pla...")
    while sentinel_running:
        try:
            sentinel.run_cycle()
        except Exception as e:
            logger.error(f"Error en cicle Sentinel: {e}", exc_info=True)
        # Quan el Cadenat 15:00h està actiu sobre un compte Tradovate dedicat, vigila cada 4 segons
        poll_sec = 4 if (getattr(config, "tradovate_direct_enabled", True) and tradovate_master.is_locked_out()) else config.sentinel_poll_interval
        time.sleep(poll_sec)


def _relay_webhook_payload(payload: dict, target_url: str):
    """Reenvia de forma asíncrona el payload de TradingView als serveis configurats (Live / ChartVPS NT8 Bridge)."""
    urls = [u.strip() for u in target_url.split(",") if u.strip()]
    relay_headers = {"Content-Type": "application/json"}
    f_payload = dict(payload)
    forward_secret = getattr(config, "forward_webhook_secret", None)
    if forward_secret:
        f_payload["secret"] = forward_secret
    if not f_payload.get("account"):
        f_payload["account"] = getattr(config, "nt8_bot_account", "Sim103")

    # Respectar el qty enviat per TradingView (ex: 10 MNQ) o usar prop_master_contracts (10 MNQ per defecte)
    if str(f_payload.get("action", "")).lower() in ("buy", "sell"):
        raw_qty = payload.get("qty")
        try:
            f_payload["qty"] = int(raw_qty) if raw_qty is not None and int(raw_qty) > 0 else getattr(config, "prop_master_contracts", 10)
        except (TypeError, ValueError):
            f_payload["qty"] = getattr(config, "prop_master_contracts", 10)

    for url in urls:
        try:
            logger.info(f"🔄 Webhook Relay: Reenviant alerta ({f_payload.get('action')} | qty={f_payload.get('qty')}) cap a {url}...")
            resp = requests.post(url, json=f_payload, headers=relay_headers, timeout=4.0)
            logger.info(f"✅ Webhook Relay retornat HTTP {resp.status_code} des de {url}")
        except Exception as re_err:
            logger.warning(f"⚠️ Error en Webhook Relay cap a {url}: {re_err}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    t = threading.Thread(target=sentinel_daemon_worker, daemon=True)
    t.start()
    role_str = getattr(config, "account_role", "prop_master").upper()
    logger.info(f"🌐 Servidor Web Layer Sniper actiu [{role_str}] a http://{config.host}:{config.port}")
    yield


app = FastAPI(title="Layer Sniper Pro Sentinel HUD", version="2026.2", lifespan=lifespan)
app.add_middleware(GZipMiddleware, minimum_size=1000)


@app.api_route("/health", methods=["GET", "HEAD"])
def health_check():
    return {
        "status": "healthy",
        "service": "Layer Sniper Pro",
        "mode": config.engine_mode,
        "env": config.tradovate_env,
        "account_role": getattr(config, "account_role", "prop_master"),
        "kill_switch_active": kill_switch.is_active,
        "forward_relay_active": bool(getattr(config, "forward_webhook_url", None))
    }


@app.get("/api/status", dependencies=[Depends(verify_dashboard_auth)])
def api_status():
    snapshot = sentinel.get_snapshot()
    snapshot["account_role"] = getattr(config, "account_role", "prop_master")
    snapshot["prop_master_contracts"] = getattr(config, "prop_master_contracts", 5)
    snapshot["live_capital_step"] = getattr(config, "live_capital_step", 1000.0)
    now_today = datetime.datetime.now(config.tz_madrid).date()
    snapshot["executed_strategies_today"] = list(executed_strategies_today.get(now_today, set()))
    snapshot["executed_counts_today"] = executed_counts_today.get(now_today, {})
    return snapshot


@app.get("/setup.ps1", response_class=PlainTextResponse, dependencies=[Depends(verify_dashboard_auth)])
def get_vps_setup_script():
    script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "setup_vps.ps1")
    if os.path.exists(script_path):
        with open(script_path, "r", encoding="utf-8") as f:
            return f.read()
    return "# setup_vps.ps1 not found"


@app.get("/download/bridge", response_class=PlainTextResponse)
def get_vps_bridge_script():
    bridge_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "vps_ninjatrader_bridge.py")
    if os.path.exists(bridge_path):
        with open(bridge_path, "r", encoding="utf-8") as f:
            return f.read()
    return "# vps_ninjatrader_bridge.py not found"


@app.get("/download/replikanto/atm/{template_filename}", response_class=PlainTextResponse)
def get_replikanto_atm_template(template_filename: str):
    safe_name = os.path.basename(template_filename)
    if not safe_name.endswith(".xml"):
        safe_name += ".xml"
    atm_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "replikanto",
        "atm_templates",
        safe_name,
    )
    if not os.path.exists(atm_path):
        raise HTTPException(status_code=404, detail="ATM template not found")
    with open(atm_path, "r", encoding="utf-8") as f:
        return f.read()


@app.get("/download/replikanto/addon/{addon_filename}", response_class=PlainTextResponse)
def get_replikanto_addon_file(addon_filename: str):
    safe_name = os.path.basename(addon_filename)
    if not safe_name.endswith(".cs"):
        safe_name += ".cs"
    addon_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "replikanto",
        "nt8_addons",
        safe_name,
    )
    if not os.path.exists(addon_path):
        raise HTTPException(status_code=404, detail="NinjaScript addon not found")
    with open(addon_path, "r", encoding="utf-8") as f:
        return f.read()


@app.get("/install-replikanto.ps1", response_class=PlainTextResponse)
def get_replikanto_one_liner_ps1():
    """
    Instal·lador ràpid d'1 sola comanda per a PowerShell al Windows VPS:
    irm https://<el-teu-domini>.up.railway.app/install-replikanto.ps1 | iex
    Copia les 4 plantilles ATM XML, el botó C# BE +2t i el Bridge ATI blindat.
    """
    script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "setup_vps.ps1")
    if os.path.exists(script_path):
        with open(script_path, "r", encoding="utf-8") as f:
            return f.read()
    raise HTTPException(status_code=404, detail="Installer not found")


@app.get("/install-nt8-kit.ps1", response_class=PlainTextResponse)
def get_shareable_nt8_kit_ps1():
    """
    Instal·lador net per compartir amb tercers (NOMÉS 4 plantilles ATM + AddOn C# BE +2t & Auto-Qty; sense Bridge ni secrets).
    """
    script_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "scripts", "install_nt8_kit_only.ps1")
    if os.path.exists(script_path):
        with open(script_path, "r", encoding="utf-8") as f:
            return f.read()
    raise HTTPException(status_code=404, detail="NT8 kit installer not found")


def build_nt8_shareable_kit_zip_bytes() -> bytes:
    """Empaqueta en memòria un .zip autocontingut amb les 4 plantilles ATM, l'AddOn C# i un instal·lador offline d'1 clic (.bat)."""
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    atm_dir = os.path.join(root_dir, "replikanto", "atm_templates")
    addons_dir = os.path.join(root_dir, "replikanto", "nt8_addons")

    bat_installer = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "set \"KIT_SRC=%~dp0\"\r\n"
        "title Instal-lador Kit NinjaTrader 8 (ATM + Boto BE +2t)\r\n"
        "color 0A\r\n"
        "echo ===================================================================\r\n"
        "echo   INSTAL-LANT PLANTILLES ATM I BOTO [BE +2t] A NINJATRADER 8...\r\n"
        "echo ===================================================================\r\n"
        "echo.\r\n"
        "powershell -NoProfile -ExecutionPolicy Bypass -Command \""
        "$src = $env:KIT_SRC; "
        "$myDocs = [Environment]::GetFolderPath('MyDocuments'); "
        "$cands = @( (Join-Path $myDocs 'NinjaTrader 8'), (Join-Path $env:USERPROFILE 'Documents\\NinjaTrader 8'), (Join-Path $env:USERPROFILE 'OneDrive\\Documents\\NinjaTrader 8'), (Join-Path $env:USERPROFILE 'OneDrive\\Documentos\\NinjaTrader 8') ); "
        "$nt8 = $null; foreach ($c in $cands) { if ($c -and (Test-Path $c)) { $nt8 = $c; break } }; "
        "if (-not $nt8) { $nt8 = Join-Path $myDocs 'NinjaTrader 8' }; "
        "Write-Host ('Carpeta NinjaTrader 8: ' + $nt8) -ForegroundColor Cyan; "
        "$atmDst = Join-Path $nt8 'templates\\AtmStrategy'; "
        "$addDst = Join-Path $nt8 'bin\\Custom\\AddOns'; "
        "$indDst = Join-Path $nt8 'bin\\Custom\\Indicators'; "
        "foreach ($d in @($atmDst, $addDst, $indDst)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }; "
        "Copy-Item (Join-Path $src 'templates\\AtmStrategy\\*.xml') -Destination $atmDst -Force; "
        "Copy-Item (Join-Path $src 'bin\\Custom\\AddOns\\*.cs') -Destination $addDst -Force; "
        "Copy-Item (Join-Path $src 'bin\\Custom\\Indicators\\*.cs') -Destination $indDst -Force; "
        "Write-Host 'OK! 4 Plantilles ATM + AddOn [BE +2t / FLAT / Auto-Qty] copiats amb exit!' -ForegroundColor Green"
        "\"\r\n"
        "echo.\r\n"
        "echo ===================================================================\r\n"
        "echo   ULTIM PAS DINS NINJATRADER 8 (10 segons):\r\n"
        "echo   Obre Control Center -^> New -^> NinjaScript Editor i prem F5!\r\n"
        "echo ===================================================================\r\n"
        "echo.\r\n"
        "pause\r\n"
    )

    readme_txt = (
        "KIT NINJATRADER 8 — PLANTILLES ATM (30p TP / 30p SL) + BOTONS [BE +2t] I [FLAT] + AUTO-QTY\r\n"
        "=========================================================================================\r\n\r\n"
        "COM INSTAL·LAR-HO EN 15 SEGONS:\r\n"
        "1. Extreu (descomprimeix) tot aquest fitxer .zip en qualsevol carpeta.\r\n"
        "2. Fes doble clic a 'INSTALAR_KIT_NT8.bat' (copiarà sol els ATM i l'AddOn a la teva carpeta NinjaTrader 8).\r\n"
        "3. Dins de NinjaTrader 8, ves a: Control Center -> New -> NinjaScript Editor -> prem la tecla F5 per compilar.\r\n\r\n"
        "LLEST!\r\n"
        "- A qualsevol gràfic amb Chart Trader obert ja et sortiran automàticament els botons [BE +2t (+0.50p)] i [FLAT].\r\n"
        "- Al desplegable 'ATM Strategy' tindràs les 4 plantilles (3, 5, 10 i 30 MNQ amb 30p TP / 30p SL) i la casella 'Order qty' s'ajustarà sola!\r\n\r\n"
        "(Instal·lació manual alternativa si no vols usar el .bat):\r\n"
        "- Copia els .xml de 'templates\\AtmStrategy' dins de Documents\\NinjaTrader 8\\templates\\AtmStrategy\\\r\n"
        "- Copia 'LayerSniperChartTraderAddOn.cs' dins de Documents\\NinjaTrader 8\\bin\\Custom\\AddOns\\\r\n"
        "- Copia 'LayerSniperManualBEButton.cs' dins de Documents\\NinjaTrader 8\\bin\\Custom\\Indicators\\\r\n"
        "- Obre New -> NinjaScript Editor i prem F5.\r\n"
    )

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("INSTALAR_KIT_NT8.bat", bat_installer.encode("utf-8"))
        zf.writestr("INSTRUCCIONS.txt", readme_txt.encode("utf-8"))
        if os.path.isdir(atm_dir):
            for fname in sorted(os.listdir(atm_dir)):
                if fname.endswith(".xml"):
                    zf.write(os.path.join(atm_dir, fname), arcname=f"templates/AtmStrategy/{fname}")
        addon_cs = os.path.join(addons_dir, "LayerSniperChartTraderAddOn.cs")
        if os.path.exists(addon_cs):
            zf.write(addon_cs, arcname="bin/Custom/AddOns/LayerSniperChartTraderAddOn.cs")
        ind_cs = os.path.join(addons_dir, "LayerSniperManualBEButton.cs")
        if os.path.exists(ind_cs):
            zf.write(ind_cs, arcname="bin/Custom/Indicators/LayerSniperManualBEButton.cs")
    return buf.getvalue()


@app.get("/download/nt8-kit.zip")
def download_shareable_nt8_kit_zip():
    zip_bytes = build_nt8_shareable_kit_zip_bytes()
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="LayerSniper_NT8_Kit.zip"'},
    )


@app.post("/api/killswitch/trigger", dependencies=[Depends(verify_dashboard_auth)])
def api_trigger_killswitch():
    return kill_switch.trigger(reason="Accionat manualment des del Dashboard Web")


@app.post("/api/killswitch/reset", dependencies=[Depends(verify_dashboard_auth)])
def api_reset_killswitch():
    return kill_switch.reset()


@app.post("/api/engine/reset_today", dependencies=[Depends(verify_dashboard_auth)])
def api_reset_engine_today():
    now_madrid = datetime.datetime.now(config.tz_madrid)
    if tradovate_master.is_locked_out(now_madrid):
        lock_st = tradovate_master.get_lockout_status(now_madrid)
        return JSONResponse(
            status_code=423,
            content={
                "error": "TRADOVATE_LOCKED_UNTIL_15H",
                "message": f"🔒 Cadenat Anti-Tilt actiu fins a {lock_st.get('locked_until_madrid_str')}. No es pot reiniciar el comptador fins a les 15:00h.",
                "lockout": lock_st
            }
        )
    today = now_madrid.date()
    live_unified_engine.reset_day(today, reload_state=False)
    sentinel.reset_daily_dispatch(today)
    executed_strategies_today[today] = set()
    executed_counts_today[today] = {}
    return {
        "status": "RESET_TODAY_OK",
        "date": str(today),
        "trades_executed_today": live_unified_engine.trades_executed_today
    }


@app.get("/api/psicoleg/status")
def api_psicoleg_status():
    now_madrid = datetime.datetime.now(config.tz_madrid)
    now_ny = datetime.datetime.now(config.tz_ny)
    today = now_madrid.date()
    return {
        "status": "OK",
        "barcelona_time": now_madrid.strftime("%H:%M:%S"),
        "new_york_time": now_ny.strftime("%H:%M:%S"),
        "date": today.strftime("%d/%m/%Y"),
        "trades_executed_today": live_unified_engine.trades_executed_today,
        "max_daily_trades": getattr(config, "max_daily_trades", 2),
        "lockout": tradovate_master.get_lockout_status(now_madrid),
        "kill_switch_active": kill_switch.is_active
    }


@app.post("/api/psicoleg/lock_until_15h")
async def api_lock_tradovate_until_15h(request: Request):
    """
    🔒 Activa el Cadenat de tots els comptes a Tradovate fins al proper cicle de les 15:00h BCN:
    - Cancel·la totes les ordres pendents i liquida posicions a tots els comptes de Tradovate.
    - Envia senyal flatten al Bridge de NinjaTrader / Replikanto si està configurat.
    - Bloqueja l'operativa i el Reset Dia fins a l'endemà a les 15:00:00 BCN.
    """
    reason = "Cadenat de fi de sessió activat des del Psicòleg / HUD (Bloquejat fins 15:00h BCN)"
    try:
        body = await request.json()
        if isinstance(body, dict) and body.get("reason"):
            reason = str(body["reason"])
    except Exception:
        pass

    now_madrid = datetime.datetime.now(config.tz_madrid)
    lock_res = tradovate_master.lock_accounts_until_15h(reason=reason, now_madrid=now_madrid)

    # De moment NO enviem el bloqueig a NinjaTrader/Replikanto llevat que s'activi explícitament LOCKOUT_INCLUDE_NT8=true
    include_nt8 = os.getenv("LOCKOUT_INCLUDE_NT8", "false").lower() in ("true", "1", "yes")
    forward_url = getattr(config, "forward_webhook_url", None)
    if include_nt8 and forward_url:
        flatten_payload = {
            "secret": config.webhook_secret,
            "strategy": "Psicoleg_Lockout_15h",
            "action": "flatten",
            "reason": reason
        }
        threading.Thread(target=_relay_webhook_payload, args=(flatten_payload, forward_url), daemon=True).start()

    notifier.send_end_of_session_lockout_reminder(
        now_madrid=now_madrid,
        reason=reason
    )
    return lock_res


@app.post("/api/psicoleg/notify_morning_discord")
def api_notify_morning_discord():
    now_madrid = datetime.datetime.now(config.tz_madrid)
    notifier.send_morning_0800_lockout_reminder(now_madrid=now_madrid, sync=True)
    return {"status": "MORNING_DISCORD_SENT", "timestamp": now_madrid.isoformat()}


@app.get("/api/prop_sim/status")
def api_prop_sim_status():
    from bot.prop_daily_simulator import load_simulation_state
    return load_simulation_state()


@app.post("/api/prop_sim/send_discord")
async def api_prop_sim_send_discord(request: Request):
    date_str = None
    try:
        body = await request.json()
        if isinstance(body, dict) and body.get("date"):
            date_str = str(body["date"])
    except Exception:
        pass
    res = notifier.send_daily_prop_simulation_report(date_str=date_str, sync=True, allow_weekend=True)
    return res


@app.post("/api/psicoleg/log")
async def api_psicoleg_log(request: Request):
    """
    Registra el tancament de la sessió a DIARI_SESSIONS_SNIPER.md i opcionalment activa el cadenat fins a les 15:00h.
    """
    try:
        data = await request.json()
    except Exception:
        return JSONResponse(status_code=400, content={"error": "INVALID_JSON"})

    now_madrid = datetime.datetime.now(config.tz_madrid)
    date_str = str(data.get("date") or now_madrid.strftime("%d/%m/%Y"))
    pre_calm = str(data.get("pre_calm") or "8/10")
    bala1 = str(data.get("bala1") or "Cap")
    bala2 = str(data.get("bala2") or "Cap")
    faithful = bool(data.get("faithful", True))
    notes = str(data.get("notes") or "Sessió tancada segons protocol.").replace("\n", " ").replace("|", "/")
    auto_lock = bool(data.get("auto_lock_15h", True))

    lock_res = None
    if auto_lock:
        lock_res = tradovate_master.lock_accounts_until_15h(
            reason=f"Check-out Psicòleg ({date_str}) — Bloquejat fins 15:00h BCN",
            now_madrid=now_madrid
        )
        notifier.send_end_of_session_lockout_reminder(
            now_madrid=now_madrid,
            reason=f"Tancament de sessió registrat ({date_str}) · Disciplina: {'100% FIDEL' if faithful else 'DESVIACIÓ'}"
        )
        if not sentinel.daily_events_dispatched.get("daily_prop_sim_report_sent", False):
            sentinel.daily_events_dispatched["daily_prop_sim_report_sent"] = True
            now_ny = datetime.datetime.now(config.tz_ny)
            notifier.send_daily_prop_simulation_report(date_str=now_ny.date().isoformat())

    faith_str = "✅ 100% FIDEL" if faithful else "❌ DESVIACIÓ"
    lock_str = "🔒 Sí (15:00h)" if (auto_lock or tradovate_master.is_locked_out(now_madrid)) else "—"
    row_md = f"| {date_str} | `{pre_calm}` | `{bala1}` | `{bala2}` | **{faith_str}** | `{lock_str}` | {notes} |\n"

    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    journal_path = os.path.join(root_dir, "DIARI_SESSIONS_SNIPER.md")
    try:
        if os.path.exists(journal_path):
            with open(journal_path, "r", encoding="utf-8") as f:
                content = f.read()
        else:
            content = "# 📓 DIARI DE DISCIPLINA I SESSIONS — LAYER SNIPER PRO\n\n"
        content = content.rstrip() + "\n" + row_md
        with open(journal_path, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        logger.warning(f"No s'ha pogut escriure a DIARI_SESSIONS_SNIPER.md: {e}")

    return {
        "status": "LOGGED_OK",
        "date": date_str,
        "faithful": faithful,
        "lockout": lock_res or tradovate_master.get_lockout_status(now_madrid)
    }


@app.post("/api/breakeven/manual", dependencies=[Depends(verify_dashboard_auth)])
def api_manual_breakeven():
    """Permet forçar el moviment de l'Stop Loss a Breakeven des del botó del Dashboard."""
    forward_url = getattr(config, "forward_webhook_url", None)
    be_payload = {
        "secret": config.webhook_secret,
        "strategy": "Manual_HUD_Breakeven",
        "action": "breakeven",
        "symbol": config.symbol_base,
        "be_price": tradovate_master.last_entry_price,
        "entry_price": tradovate_master.last_entry_price,
        "be_offset_points": getattr(config, "be_offset_points", 0.5)
    }
    if forward_url:
        threading.Thread(target=_relay_webhook_payload, args=(be_payload, forward_url), daemon=True).start()

    if getattr(config, "tradovate_direct_enabled", True):
        res = tradovate_master.move_stop_to_breakeven()
    else:
        res = {"status": "NT8_RELAY_ONLY_ISOLATED", "modified": bool(forward_url), "be_price": tradovate_master.last_entry_price or 0.0}
    if res.get("modified"):
        live_unified_engine.record_breakeven(res.get("be_price", 0.0))
    return res


@app.post("/api/test_alert", dependencies=[Depends(verify_dashboard_auth)])
def api_test_alert():
    notifier.send("TEST DE CONNEXIÓ", "Connexió operativa amb Layer Sniper Pro (Railway).", color="blue", sync=True)
    return {"status": "TEST_ALERT_SENT"}


@app.post("/api/webhook/tradingview")
async def api_tradingview_webhook(request: Request):
    """
    Receptor central de Webhooks de TradingView per a Layer Sniper Pro:
    - Suporta: 'Buy', 'Sell', 'breakeven', 'cancel', 'flatten'.
    - Encamina cap a:
      1) Tradovate API directe (Comptes Live / Prop API amb OSO Brackets i modifyOrder a BE)
      2) NinjaTrader 8 + Replikanto (via FORWARD_WEBHOOK_URL cap al Bridge ATI del VPS)
    """
    body_bytes = b""
    try:
        data = await request.json()
    except Exception:
        try:
            body_bytes = await request.body()
            data = json.loads(body_bytes.decode("utf-8"))
        except Exception:
            raw_str = body_bytes.decode("utf-8", errors="ignore").strip()
            logger.info(f"ℹ️ Webhook rebut de TradingView (text): {raw_str[:120]}")
            return {"status": "ACK_NON_JSON", "received": raw_str[:120]}

    # 1. Validació estricta de Secret (sense bypass hardcoded)
    secret = str(data.get("secret") or "")
    expected_secret = str(getattr(config, "webhook_secret", None) or "layersniper2026")
    if not secrets.compare_digest(secret.encode("utf-8"), expected_secret.encode("utf-8")):
        logger.warning("⚠️ Intent de Webhook no autoritzat (secret invàlid).")
        return JSONResponse(status_code=401, content={"error": "UNAUTHORIZED"})

    # 2. Comprovació de Kill-Switch
    if kill_switch.is_active:
        logger.error("🛑 Kill-Switch actiu. Bloquejant senyal de TradingView.")
        return JSONResponse(status_code=403, content={"error": "KILL_SWITCH_ACTIVE", "reason": kill_switch.trigger_reason})

    action_raw = str(data.get("action", "Buy")).strip()
    action_lower = action_raw.lower()
    strategy_name = str(data.get("strategy", "JJ_Layer_Sniper_10AM")).strip()
    forward_url = getattr(config, "forward_webhook_url", None)

    tv_enabled = bool(getattr(config, "tradovate_direct_enabled", True))

    # 3. Gestió de Cancel·lació i Flatten (Tall de sessió 11:00 NY o EOD)
    if action_lower in ("cancel", "cancel_all"):
        if forward_url:
            threading.Thread(target=_relay_webhook_payload, args=(data, forward_url), daemon=True).start()
        count = tradovate_master.cancel_all_pending_orders() if tv_enabled else 0
        logger.info(f"🛑 Webhook TradingView: Cancel·lació d'ordres pendents ({count} cancel·lades a Tradovate | Relay NT8: {bool(forward_url)}).")
        return {"status": "ORDERS_CANCELLED", "cancelled_count": count, "relayed_to_nt8": bool(forward_url)}

    if action_lower in ("flatten", "close", "close_all"):
        if forward_url:
            threading.Thread(target=_relay_webhook_payload, args=(data, forward_url), daemon=True).start()
        if tv_enabled:
            tradovate_master.cancel_all_pending_orders()
            closed = tradovate_master.close_all_positions()
        else:
            closed = True
        logger.info(f"🛑 Webhook TradingView: Flatten total enviat (Tradovate dedicat: {tv_enabled} | Relay NT8: {bool(forward_url)}).")
        return {"status": "POSITIONS_FLATTENED", "closed": closed, "relayed_to_nt8": bool(forward_url)}

    if action_lower == "exit":
        logger.info("ℹ️ Webhook TradingView: 'exit' ignorat (els brackets OSO/OCO gestionen la sortida nativament).")
        return {"status": "EXIT_IGNORED_MANAGED_BY_BRACKETS"}

    # 4. Gestió de l'Escut de Breakeven Automàtic (Llei 2: TP 1 assolit -> SL 2 a Breakeven)
    if action_lower in ("breakeven", "be", "move_to_be"):
        be_price_raw = data.get("be_price")
        entry_price_raw = data.get("entry_price")
        direction_raw = data.get("direction")

        be_price = float(be_price_raw) if be_price_raw is not None else None
        entry_price = float(entry_price_raw) if entry_price_raw is not None else None

        if forward_url:
            threading.Thread(target=_relay_webhook_payload, args=(data, forward_url), daemon=True).start()

        if tv_enabled:
            be_res = tradovate_master.move_stop_to_breakeven(
                be_price=be_price,
                entry_price=entry_price,
                direction=direction_raw
            )
        else:
            nt8_acct = getattr(config, "nt8_bot_account", "Sim103")
            be_res = {"status": f"ISOLATED_NT8_ONLY ({nt8_acct})", "modified": False, "be_price": be_price or entry_price}
        final_be_px = be_res.get("be_price") or be_price or entry_price or 0.0
        live_unified_engine.record_breakeven(float(final_be_px))

        notifier.send(
            f"🛡️ ESCUT BREAKEVEN ACTIVAT ({strategy_name})",
            f"✅ **El PRIMARY ha tocat TP 1! Stop Loss del LAYER mogut a Breakeven (0p).**\n"
            f"🎯 **Nou Stop Loss (BE)**: `{float(final_be_px):.2f}`\n"
            f"📡 **Tradovate API**: `{be_res.get('status')}`\n"
            f"🔄 **Relay NT8/Replikanto (`{getattr(config, 'nt8_bot_account', 'Sim103')}`)**: `{'ENVIAT' if forward_url else 'NO CONFIGURAT'}`",
            color="orange"
        )
        return {
            "status": "BREAKEVEN_PROCESSED",
            "strategy": strategy_name,
            "be_price": final_be_px,
            "tradovate_result": be_res,
            "relayed_to_nt8": bool(forward_url)
        }

    # 5. Validació d'Ordre d'Entrada (Buy / Sell)
    action = action_raw.capitalize()
    if action not in ("Buy", "Sell"):
        return JSONResponse(status_code=400, content={"error": "INVALID_ACTION", "action": action_raw})

    # 5B. Comprovació del Cadenat Anti-Tilt Tradovate 15:00h BCN
    now_madrid_dt = datetime.datetime.now(config.tz_madrid)
    if tradovate_master.is_locked_out(now_madrid_dt):
        lock_st = tradovate_master.get_lockout_status(now_madrid_dt)
        logger.warning(f"🔒 REBUIG CADENAT 15:00H: Ordre '{strategy_name}' blocada fins a {lock_st.get('locked_until_madrid_str')}.")
        return JSONResponse(status_code=423, content={
            "error": "TRADOVATE_LOCKED_UNTIL_15H",
            "message": f"Comptes bloquejats fins a {lock_st.get('locked_until_madrid_str')}",
            "lockout": lock_st
        })

    clean_strat_key = strategy_name.lower()
    now_today = datetime.datetime.now(config.tz_madrid).date()
    for k in list(executed_counts_today.keys()):
        if k < now_today:
            del executed_counts_today[k]
            executed_strategies_today.pop(k, None)
    if now_today not in executed_counts_today:
        executed_counts_today[now_today] = {}
    if now_today not in executed_strategies_today:
        executed_strategies_today[now_today] = set()

    current_count = executed_counts_today[now_today].get(clean_strat_key, 0)
    is_bloc_a_only = "bloca" in clean_strat_key or "bloc_a" in clean_strat_key
    max_allowed_for_strat = getattr(config, "max_trades_per_day_bloc_a", 1) if is_bloc_a_only else getattr(config, "max_daily_trades", 6)

    if current_count >= max_allowed_for_strat:
        logger.warning(f"🛑 REBUIG LÍMIT DIARI: '{strategy_name}' ja ha executat {current_count}/{max_allowed_for_strat} trades avui ({now_today}).")
        notifier.send(
            f"🛡️ LÍMIT DIARI ASSOLIT: ORDRE REBUTJADA ({strategy_name})",
            f"⚠️ S'ha rebut un nou senyal per a `{strategy_name}`, però ja s'ha assolit el màxim de `{max_allowed_for_strat}` execucions avui (`{now_today}`).",
            color="warning"
        )
        return JSONResponse(status_code=429, content={
            "error": "STRATEGY_ALREADY_EXECUTED_TODAY",
            "message": f"L'estratègia '{strategy_name}' ha assolit el límit diari ({max_allowed_for_strat}).",
            "strategy": strategy_name,
            "date": str(now_today)
        })

    # 6. Escut de Notícies (News Guardian)
    is_news_blocked, news_reason = news_guardian.is_strategy_prohibited(strategy_name)
    if is_news_blocked:
        logger.error(f"🛑 REBUIG NEWS GUARDIAN: {strategy_name} blocada. {news_reason}")
        return JSONResponse(status_code=403, content={"error": "NEWS_RESTRICTED_WINDOW", "reason": news_reason})

    symbol_raw = str(data.get("symbol", "")).strip()
    if not symbol_raw or "!" in symbol_raw or symbol_raw.upper() in ("MNQ", "NQ"):
        symbol = resolve_active_contract(tradovate_master if (tv_enabled and config.user and config.password) else None, symbol_base="MNQ")
    else:
        symbol = symbol_raw

    order_type = str(data.get("order_type", "Market")).capitalize()

    incoming_price = None
    if "price" in data and data.get("price") is not None:
        try:
            incoming_price = float(data["price"])
        except (TypeError, ValueError):
            return JSONResponse(status_code=400, content={"error": "INVALID_PRICE"})

    if incoming_price is not None:
        price = incoming_price
    elif order_type.lower() == "market":
        mkt_p = tradovate_master.get_current_market_price(symbol)
        if isinstance(mkt_p, (int, float)):
            price = float(mkt_p)
        else:
            return JSONResponse(status_code=400, content={"error": "CANNOT_RESOLVE_MARKET_PRICE"})
    else:
        return JSONResponse(status_code=400, content={"error": "INVALID_PRICE"})

    tp_points = float(data.get("tp_points", config.tp_far_points))
    sl_points = float(data.get("sl_points", config.sl_far_points))
    trade_mode = str(data.get("mode", "FAR")).upper()
    slot_name = str(data.get("slot", "LAYER")).upper()

    # 7. Dimensionament de Posició:
    # - Rol 'live' (amb compte Tradovate dedicat actiu): Càlcul dinàmic segons saldo net a Tradovate
    # - Rol 'prop_master' (o mode aïllat NT8 Sim103): Lotatge fix / preset per a comptes fondejats
    incoming_qty = int(data["qty"]) if "qty" in data and str(data["qty"]).isdigit() else None
    if tv_enabled and getattr(config, "account_role", "prop_master") == "live":
        balance = tradovate_master.get_cash_balance()
        qty = position_sizer.calculate_qty(
            balance=balance,
            role="live",
            strategy_name=strategy_name,
            incoming_qty=incoming_qty,
            sl_points=sl_points,
            trade_mode=trade_mode
        )
    else:
        qty = position_sizer.calculate_qty(
            role="prop_master",
            strategy_name=strategy_name,
            incoming_qty=incoming_qty,
            sl_points=sl_points,
            trade_mode=trade_mode
        )

    tp_price = float(data["tp_price"]) if "tp_price" in data and data["tp_price"] is not None else round(price + tp_points if action == "Buy" else price - tp_points, 2)
    sl_price = float(data["sl_price"]) if "sl_price" in data and data["sl_price"] is not None else round(price - sl_points if action == "Buy" else price + sl_points, 2)

    # 8. Verificació d'Escut Anti-Hedging (només sobre compte Tradovate dedicat si està activat)
    if tv_enabled:
        positions = tradovate_master.get_positions()
        orders = tradovate_master.get_open_orders()
        allowed, reason = anti_hedging_guard.validate_order(
            proposed_action=action,
            symbol=symbol,
            price=price,
            existing_positions=positions,
            existing_orders=orders,
            strategy_source=strategy_name
        )
        if not allowed:
            logger.error(f"⛔ Webhook blocat per Anti-Hedging: {reason}")
            return JSONResponse(status_code=409, content={"error": "HEDGING_VIOLATION", "reason": reason})

    # 9. Execució a Tradovate API (només si té compte dedicat actiu) i/o Relay cap a NinjaTrader 8 (Sim103)
    should_exec_tradovate = tv_enabled and (
        getattr(config, "account_role", "prop_master") == "live"
        or getattr(config, "execute_tradovate_in_prop_mode", True)
    )

    order_res = None
    if should_exec_tradovate:
        order_res = tradovate_master.place_bracket_order(
            symbol=symbol,
            action=action,
            qty=qty,
            entry_price=price,
            tp_price=tp_price,
            sl_price=sl_price,
            order_type=order_type,
            allow_marketable=True
        )

    # Si l'ordre s'ha col·locat a Tradovate O si tenim relay actiu cap a NinjaTrader Bridge (ChartVPS)
    tradovate_ok = bool(order_res and order_res.get("orderId"))
    relay_only_ok = bool(forward_url)

    role_tag = "[LIVE]" if getattr(config, "account_role", "prop_master") == "live" else "[PROP MASTER]"

    if tradovate_ok or relay_only_ok:
        order_id = order_res.get("orderId") if order_res else f"NT8_RELAY_{int(time.time())}"
        executed_counts_today[now_today][clean_strat_key] = current_count + 1
        executed_strategies_today[now_today].add(clean_strat_key)

        if forward_url:
            threading.Thread(target=_relay_webhook_payload, args=(data, forward_url), daemon=True).start()

        live_unified_engine.record_trade_execution(data, qty, tp_price, sl_price, order_id)

        logger.info(
            f"✅ Webhook Layer Sniper {role_tag}: {slot_name} ({trade_mode}) {action.upper()} {order_type.upper()} "
            f"{qty} {symbol} @ {price:.2f} [TP: {tp_price:.2f} | SL: {sl_price:.2f}] (ID {order_id})."
        )
        notifier.send(
            f"🚀 SNIPER TRADE EXECUTAT ({strategy_name} • {slot_name})",
            f"🎯 **Acció**: `{action.upper()} {order_type.upper()} @ {price:.2f}` (`{trade_mode}`)\n"
            f"📦 **Mida**: `{qty} MNQ` | **Contracte**: `{symbol}`\n"
            f"🟢 **Take Profit**: `{tp_price:.2f}` (`+{tp_points:.1f} pts`)\n"
            f"🔴 **Stop Loss**: `{sl_price:.2f}` (`-{sl_points:.1f} pts`)\n"
            f"🛡️ **Escut Breakeven**: `Actiu (es mourà a 0p quan TP 1 es toqui)`\n"
            f"🆔 **Order ID**: `{order_id}`",
            color="success"
        )
        return {
            "status": "ORDER_PLACED",
            "strategy": strategy_name,
            "slot": slot_name,
            "mode": trade_mode,
            "action": action,
            "symbol": symbol,
            "qty": qty,
            "price": price,
            "tp_price": tp_price,
            "sl_price": sl_price,
            "order": order_res or {"orderId": order_id, "relayed": True}
        }
    else:
        logger.error("❌ Webhook Layer Sniper: Error o rebuig en col·locar ordre OSO a Tradovate.")
        notifier.send(
            f"⚠️ REBUIG D'ORDRE TRADOVATE ({strategy_name})",
            f"❌ **L'ordre no s'ha pogut col·locar a Tradovate**\n"
            f"🎯 Acció: `{action.upper()} @ {price:.2f}` | Símbol: `{symbol}` | Mida: `{qty}`",
            color="danger"
        )
        return JSONResponse(status_code=500, content={"error": "ORDER_FAILED_OR_REJECTED"})


@app.api_route("/", methods=["GET", "HEAD"], response_class=HTMLResponse, dependencies=[Depends(verify_dashboard_auth)])
def get_dashboard_html():
    template_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "templates", "index.html")
    if os.path.exists(template_path):
        with open(template_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h1>Layer Sniper Pro HUD actiu</h1>")


def _serve_visualizer_file(filename: str) -> HTMLResponse:
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    file_path = os.path.join(root_dir, "visualizer", filename)
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    raise HTTPException(status_code=404, detail=f"{filename} not found")


@app.api_route("/dashboard", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/backtest", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/visual_backtest.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/visualizer/visual_backtest.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
def get_public_visual_backtest():
    """Ruta pública del Dashboard Interactiu i Auditoria 1s per compartir a Discord."""
    return _serve_visualizer_file("visual_backtest.html")


@app.api_route("/playbook", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/propfirm", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/propfirm_dashboard.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/visualizer/propfirm_dashboard.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
def get_public_propfirm_dashboard():
    """Ruta pública del Playbook Executiu per compartir a Discord."""
    return _serve_visualizer_file("propfirm_dashboard.html")


@app.api_route("/manual", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/manual_operatiu_pro.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/visualizer/manual_operatiu_pro.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
def get_public_manual():
    """Ruta pública del Manual Operatiu Web."""
    return _serve_visualizer_file("manual_operatiu_pro.html")


@app.api_route("/psicoleg", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/psicoleg_sniper.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/visualizer/psicoleg_sniper.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
def get_public_psicoleg():
    """Consola Interactiva del Psicòleg d'Alt Rendiment, Gatekeeper de 2 Bales i Cadenat Tradovate 15:00h."""
    return _serve_visualizer_file("psicoleg_sniper.html")


@app.api_route("/montecarlo", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/montecarlo_2027.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
@app.api_route("/visualizer/montecarlo_2027.html", methods=["GET", "HEAD"], response_class=HTMLResponse)
def get_public_montecarlo_2027():
    """Dashboard Interactiu de Monte Carlo 2027 (10.000 Anys Sintètics, Con de Probabilitat i Matalàs de Risc)."""
    return _serve_visualizer_file("montecarlo_2027.html")


@app.get("/api/montecarlo")
def api_montecarlo_report():
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    mc_path = os.path.join(root_dir, "propfirm_sim", "monte_carlo_fleet_2027_report.json")
    if os.path.exists(mc_path):
        with open(mc_path, "r", encoding="utf-8") as f:
            return json.load(f)
    raise HTTPException(status_code=404, detail="monte_carlo_fleet_2027_report.json not found")


# =============================================================================
# PORTAL D'INSTAL·LACIÓ I ACTUALITZACIONS PER A USUARIS / TESTERS (/portal)
# Aïllat del HUD operatiu d'administrador (només dona accés a la guia i .zip nets)
# =============================================================================

@app.get("/portal", response_class=HTMLResponse)
def get_installation_portal(request: Request, credentials: HTTPBasicCredentials = Depends(security)):
    if not _is_portal_authenticated(request, credentials):
        return HTMLResponse(content=_render_portal_login_html(), status_code=200)
    return _serve_visualizer_file("portal_instalacio.html")


@app.post("/portal/login")
async def portal_login(request: Request):
    raw_body = (await request.body()).decode("utf-8", errors="ignore")
    ctype = (request.headers.get("content-type") or "").lower()
    username = ""
    password = ""
    is_json = "application/json" in ctype

    if is_json:
        try:
            payload = json.loads(raw_body)
            username = str(payload.get("username", "")).strip()
            password = str(payload.get("password", ""))
        except Exception:
            return JSONResponse(status_code=400, content={"error": "INVALID_JSON"})
    else:
        parsed = urllib.parse.parse_qs(raw_body, keep_blank_values=True)
        username = (parsed.get("username") or [""])[0].strip()
        password = (parsed.get("password") or [""])[0]

    if not _check_portal_credentials(username, password):
        if is_json:
            return JSONResponse(status_code=401, content={"error": "INVALID_CREDENTIALS"})
        return HTMLResponse(
            content=_render_portal_login_html("Usuari o contrasenya incorrectes."),
            status_code=401,
        )

    token = _build_portal_session_token()
    resp = JSONResponse(content={"status": "OK"}) if is_json else RedirectResponse(url="/portal", status_code=303)
    resp.set_cookie(
        key=PORTAL_COOKIE_NAME,
        value=token,
        max_age=30 * 24 * 3600,
        httponly=True,
        samesite="lax",
    )
    return resp


@app.get("/portal/logout")
def portal_logout():
    resp = RedirectResponse(url="/portal", status_code=303)
    resp.delete_cookie(key=PORTAL_COOKIE_NAME)
    return resp


@app.get("/portal/api/version", dependencies=[Depends(verify_portal_auth)])
def portal_get_version():
    try:
        from scripts.build_release_package import build_package_zip_bytes
        _, enriched_meta = build_package_zip_bytes()
        return enriched_meta
    except ImportError:
        return {"product_name": "Layer Sniper Pro", "version": "1.0.0", "updated_at": "2026-10-29", "changelog": []}


@app.get("/portal/download/full-package.zip", dependencies=[Depends(verify_portal_auth)])
def portal_download_full_package():
    try:
        from scripts.build_release_package import build_package_zip_bytes
    except ImportError:
        raise HTTPException(status_code=404, detail="Package builder module not installed on standalone node")
    zip_bytes, meta = build_package_zip_bytes()
    ver = meta.get("version", "1.0.0")
    filename = f"LayerSniper_Pro_Client_Package_v{ver}.zip"
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/portal/download/nt8-kit.zip", dependencies=[Depends(verify_portal_auth)])
def portal_download_nt8_kit():
    zip_bytes = build_nt8_shareable_kit_zip_bytes()
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": 'attachment; filename="LayerSniper_NT8_Kit.zip"'},
    )


@app.get("/portal/download/vps-bridge.zip", dependencies=[Depends(verify_portal_auth)])
def portal_download_vps_bridge():
    try:
        from scripts.build_release_package import build_vps_bridge_zip_bytes, load_release_metadata
    except ImportError:
        raise HTTPException(status_code=404, detail="Package builder module not installed on standalone node")
    zip_bytes = build_vps_bridge_zip_bytes()
    ver = load_release_metadata().get("version", "1.0.0")
    filename = f"LayerSniper_VPS_Update_v{ver}.zip"
    return Response(
        content=zip_bytes,
        media_type="application/zip",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


if __name__ == "__main__":
    uvicorn.run(app, host=config.host, port=config.port, log_level="info")
