#region Using declarations
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Windows;
using NinjaTrader.Gui.Chart;
using NinjaTrader.NinjaScript;
using NinjaTrader.NinjaScript.AddOns;
#endregion

// =================================================================================================
// 🛡️ JJ Layer Sniper Pro 2026 — Indicator Wrapper (Compatible amb espais de treball existents)
// =================================================================================================
// Nota: L'AddOn automàtic 'LayerSniperChartTraderAddOn' ja injecta [🛡️ BE +2t] + [🛑 FLAT] i
// sincronitza 'Order qty' a totes les finestres de gràfic sense necessitat d'afegir cap indicador.
// Mantenim també aquest indicador perquè qualsevol gràfic on ja s'hagi afegit continuï carregant
// netament i pugui personalitzar l'offset de ticks si cal.
// =================================================================================================

namespace NinjaTrader.NinjaScript.Indicators
{
    public class LayerSniperManualBEButton : Indicator
    {
        [NinjaScriptProperty]
        [Range(0, 20)]
        [Display(Name = "Breakeven Offset (Ticks)", Description = "Ticks de protecció a favor sobre el preu mitjà d'entrada (2 ticks = +0.50p en MNQ)", Order = 1, GroupName = "Layer Sniper Manual")]
        public int BreakevenOffsetTicks { get; set; }

        public override string DisplayName
        {
            get { return string.Empty; }
        }

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Botó manual d'1 clic al Chart Trader per moure l'Stop Loss a Breakeven +2 ticks (+0.50p).";
                Name = "LayerSniperManualBEButton";
                Calculate = Calculate.OnBarClose;
                IsOverlay = true;
                DisplayInDataBox = false;
                DrawOnPricePanel = true;
                PaintPriceMarkers = false;
                IsSuspendedWhileInactive = false;
                BreakevenOffsetTicks = 2;
            }
            else if (State == State.DataLoaded || State == State.Historical)
            {
                if (ChartControl != null)
                {
                    ChartControl.Dispatcher.InvokeAsync(() =>
                    {
                        Chart chartWindow = Window.GetWindow(ChartControl.Parent) as Chart;
                        if (chartWindow != null)
                            LayerSniperChartTraderAddOn.EnsureAttachedToWindow(chartWindow, BreakevenOffsetTicks);
                    });
                }
            }
        }

        protected override void OnBarUpdate()
        {
        }
    }
}
