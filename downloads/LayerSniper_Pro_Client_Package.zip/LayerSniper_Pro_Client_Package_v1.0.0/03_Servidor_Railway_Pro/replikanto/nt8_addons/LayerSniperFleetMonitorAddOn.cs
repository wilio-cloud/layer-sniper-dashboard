#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Timers;
using NinjaTrader.Cbi;
using NinjaTrader.Core;
using NinjaTrader.NinjaScript;
#endregion

// =================================================================================================
// Layer Sniper Pro — Passive Fleet Safety Monitor (AddOnBase, 100% Read-Only)
// =================================================================================================
// S'instal·la a: Documents\NinjaTrader 8\bin\Custom\AddOns\LayerSniperFleetMonitorAddOn.cs
//
// SEGURETAT I COMPLIANCE:
//   - 100% PASSIU / NOMÉS LECTURA: Aquest AddOn NO crea, NO modifica ni cancel·la MAI cap ordre.
//   - Únicament llegeix els saldos i l'última data d'execució de `Account.All` (excloent comptes
//     simulats interns `Sim*` i `Playback*`) i desa cada 30 segons una instantània JSON local a:
//       Documents\NinjaTrader 8\outgoing\fleet_telemetry_snapshot.json
//   - Això permet rebre avisos privats de:
//       1) Eval aprovada, 2) Payout / Zona Cofre disponible, 3) Compte liquidat, 4) Inactivitat.
// =================================================================================================

namespace NinjaTrader.NinjaScript.AddOns
{
    public class LayerSniperFleetMonitorAddOn : AddOnBase
    {
        private Timer snapshotTimer;
        private readonly object syncLock = new object();
        private readonly HashSet<string> subscribedAccountNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, string> lastTradeUtcByAccount = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private bool activityLoaded;

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Name = "LayerSniperFleetMonitorAddOn";
                Description = "Layer Sniper Pro: Telemetria passiva de només lectura per a avisos privats de flota (Eval, Payout/Cofre, Liquidació i Inactivitat).";
            }
            else if (State == State.Active)
            {
                StartPassiveMonitor();
            }
            else if (State == State.Terminated)
            {
                StopPassiveMonitor();
            }
        }

        private static bool IsSimulatedInternalAccount(string accountName)
        {
            if (string.IsNullOrWhiteSpace(accountName))
                return true;
            string trimmed = accountName.Trim();
            return trimmed.StartsWith("Sim", StringComparison.OrdinalIgnoreCase)
                || trimmed.StartsWith("Playback", StringComparison.OrdinalIgnoreCase)
                || trimmed.StartsWith("Backtest", StringComparison.OrdinalIgnoreCase);
        }

        private string GetOutgoingDir()
        {
            string baseDir = Globals.UserDataDir;
            if (string.IsNullOrWhiteSpace(baseDir))
            {
                string docs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                baseDir = Path.Combine(docs, "NinjaTrader 8");
            }
            return Path.Combine(baseDir, "outgoing");
        }

        private void StartPassiveMonitor()
        {
            lock (syncLock)
            {
                if (snapshotTimer != null)
                    return;

                LoadPersistedActivityTrackerSafe();
                EnsureExecutionSubscriptionsSafe();

                snapshotTimer = new Timer(30000.0);
                snapshotTimer.AutoReset = true;
                snapshotTimer.Elapsed += OnSnapshotTimerElapsed;
                snapshotTimer.Start();
            }

            WriteFleetSnapshotSafe();
        }

        private void StopPassiveMonitor()
        {
            lock (syncLock)
            {
                if (snapshotTimer != null)
                {
                    try
                    {
                        snapshotTimer.Stop();
                        snapshotTimer.Elapsed -= OnSnapshotTimerElapsed;
                        snapshotTimer.Dispose();
                    }
                    catch { }
                    snapshotTimer = null;
                }

                try
                {
                    Account[] allAccounts;
                    lock (Account.All)
                    {
                        allAccounts = Account.All.ToArray();
                    }
                    foreach (Account acct in allAccounts)
                    {
                        if (acct != null)
                            acct.ExecutionUpdate -= OnAccountExecutionUpdate;
                    }
                }
                catch { }

                subscribedAccountNames.Clear();
            }
        }

        private void OnSnapshotTimerElapsed(object sender, ElapsedEventArgs e)
        {
            EnsureExecutionSubscriptionsSafe();
            WriteFleetSnapshotSafe();
        }

        private void EnsureExecutionSubscriptionsSafe()
        {
            try
            {
                Account[] allAccounts;
                lock (Account.All)
                {
                    allAccounts = Account.All.ToArray();
                }

                lock (syncLock)
                {
                    foreach (Account acct in allAccounts)
                    {
                        if (acct == null || IsSimulatedInternalAccount(acct.Name))
                            continue;
                        if (subscribedAccountNames.Add(acct.Name))
                        {
                            acct.ExecutionUpdate += OnAccountExecutionUpdate;
                        }
                    }
                }
            }
            catch { }
        }

        private void OnAccountExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            try
            {
                Account acct = sender as Account ?? (e != null ? e.Execution?.Account : null);
                if (acct == null || IsSimulatedInternalAccount(acct.Name))
                    return;

                string nowIso = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
                lock (syncLock)
                {
                    lastTradeUtcByAccount[acct.Name] = nowIso;
                    SavePersistedActivityTrackerSafe();
                }
                WriteFleetSnapshotSafe();
            }
            catch { }
        }

        private void LoadPersistedActivityTrackerSafe()
        {
            if (activityLoaded)
                return;
            activityLoaded = true;
            try
            {
                string trackerPath = Path.Combine(GetOutgoingDir(), "fleet_activity_tracker.txt");
                if (!File.Exists(trackerPath))
                    return;

                foreach (string rawLine in File.ReadAllLines(trackerPath, Encoding.UTF8))
                {
                    if (string.IsNullOrWhiteSpace(rawLine))
                        continue;
                    int sep = rawLine.IndexOf('|');
                    if (sep <= 0 || sep >= rawLine.Length - 1)
                        continue;
                    string acctName = rawLine.Substring(0, sep).Trim();
                    string ts = rawLine.Substring(sep + 1).Trim();
                    if (!string.IsNullOrEmpty(acctName) && !string.IsNullOrEmpty(ts))
                        lastTradeUtcByAccount[acctName] = ts;
                }
            }
            catch { }
        }

        private void SavePersistedActivityTrackerSafe()
        {
            try
            {
                string outDir = GetOutgoingDir();
                Directory.CreateDirectory(outDir);
                string trackerPath = Path.Combine(outDir, "fleet_activity_tracker.txt");
                string tmpPath = trackerPath + ".tmp";

                StringBuilder sb = new StringBuilder();
                foreach (KeyValuePair<string, string> kv in lastTradeUtcByAccount)
                {
                    sb.Append(kv.Key).Append('|').Append(kv.Value).AppendLine();
                }
                File.WriteAllText(tmpPath, sb.ToString(), Encoding.UTF8);
                File.Copy(tmpPath, trackerPath, true);
                File.Delete(tmpPath);
            }
            catch { }
        }

        private static double GetAccountMetricSafe(Account acct, AccountItem item)
        {
            try
            {
                double val = acct.Get(item, Currency.UsDollar);
                if (Math.Abs(val) < 0.0001 && acct.Denomination != Currency.UsDollar)
                    val = acct.Get(item, acct.Denomination);
                if (double.IsNaN(val) || double.IsInfinity(val))
                    return 0.0;
                return val;
            }
            catch
            {
                return 0.0;
            }
        }

        private static string EscapeJson(string value)
        {
            if (string.IsNullOrEmpty(value))
                return string.Empty;
            return value
                .Replace("\\", "\\\\")
                .Replace("\"", "\\\"")
                .Replace("\r", " ")
                .Replace("\n", " ");
        }

        private void WriteFleetSnapshotSafe()
        {
            try
            {
                Account[] allAccounts;
                lock (Account.All)
                {
                    allAccounts = Account.All.ToArray();
                }

                string nowIso = DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ssZ", CultureInfo.InvariantCulture);
                bool trackerDirty = false;

                StringBuilder json = new StringBuilder(1024);
                json.AppendLine("{");
                json.Append("  \"captured_at\": \"").Append(nowIso).AppendLine("\",");
                json.AppendLine("  \"source\": \"LayerSniperFleetMonitorAddOn\",");
                json.AppendLine("  \"accounts\": [");

                int written = 0;
                foreach (Account acct in allAccounts)
                {
                    if (acct == null || IsSimulatedInternalAccount(acct.Name))
                        continue;

                    double cashVal = GetAccountMetricSafe(acct, AccountItem.CashValue);
                    if (cashVal <= 0.01)
                        continue;

                    double realizedPnl = GetAccountMetricSafe(acct, AccountItem.RealizedProfitLoss);
                    double trailingMaxDd = GetAccountMetricSafe(acct, AccountItem.TrailingMaxDrawdown);

                    string lastTradeIso = string.Empty;
                    lock (syncLock)
                    {
                        if (Math.Abs(realizedPnl) >= 0.50)
                        {
                            lastTradeUtcByAccount[acct.Name] = nowIso;
                            trackerDirty = true;
                        }
                        lastTradeUtcByAccount.TryGetValue(acct.Name, out lastTradeIso);
                    }

                    string connStatus = acct.ConnectionStatus.ToString();

                    if (written > 0)
                        json.AppendLine(",");

                    json.Append("    {");
                    json.Append("\"name\": \"").Append(EscapeJson(acct.Name)).Append("\", ");
                    json.Append("\"cash_value\": ").Append(cashVal.ToString("0.00", CultureInfo.InvariantCulture)).Append(", ");
                    json.Append("\"realized_pnl\": ").Append(realizedPnl.ToString("0.00", CultureInfo.InvariantCulture)).Append(", ");
                    json.Append("\"trailing_max_dd\": ").Append(trailingMaxDd.ToString("0.00", CultureInfo.InvariantCulture)).Append(", ");
                    json.Append("\"connection_status\": \"").Append(EscapeJson(connStatus)).Append("\", ");
                    json.Append("\"last_trade_utc\": \"").Append(EscapeJson(lastTradeIso ?? string.Empty)).Append("\"");
                    json.Append("}");
                    written++;
                }

                json.AppendLine();
                json.AppendLine("  ]");
                json.AppendLine("}");

                if (trackerDirty)
                {
                    lock (syncLock)
                    {
                        SavePersistedActivityTrackerSafe();
                    }
                }

                string outDir = GetOutgoingDir();
                Directory.CreateDirectory(outDir);
                string dstPath = Path.Combine(outDir, "fleet_telemetry_snapshot.json");
                string tmpPath = dstPath + ".tmp";

                File.WriteAllText(tmpPath, json.ToString(), new UTF8Encoding(false));
                File.Copy(tmpPath, dstPath, true);
                File.Delete(tmpPath);
            }
            catch { }
        }
    }
}
