#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using NinjaTrader.Cbi;
using NinjaTrader.Code;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.Tools;
using NinjaTrader.NinjaScript;
#endregion

// =================================================================================================
// 🛡️ JJ Layer Sniper Pro 2026 — Automatic Chart Trader Manual Kit (AddOnBase)
// =================================================================================================
// S'instal·la a: Documents\NinjaTrader 8\bin\Custom\AddOns\LayerSniperChartTraderAddOn.cs
//
// QUÈ FA AUTOMÀTICAMENT EN COMPILAR (F5 al NinjaScript Editor) — SENSE AFEGIR CAP INDICADOR:
//   1. Injecta els botons manuals d'1 clic [🛡️ BE +2t (+0.50p)] i [🛑 FLAT] tant dins del panell
//      Chart Trader (just sota ATM Strategy) com a la barra superior del gràfic (MainMenu).
//   2. Sincronitza automàticament 'Order qty' quan selecciones qualsevol plantilla ATM 'LS_*':
//        - LS_50K_10MNQ_30TP_30SL  -> Order qty = 10
//        - LS_50K_5MNQ_30TP_30SL   -> Order qty = 5
//        - LS_50K_3MNQ_30TP_30SL   -> Order qty = 3
//        - LS_150K_30MNQ_30TP_30SL -> Order qty = 30
//   3. 100% Manual Click Compliance: cap ordre ni modificació s'envia mai sola; només quan tu fas
//      clic físic amb el ratolí al botó.
// =================================================================================================

namespace NinjaTrader.NinjaScript.AddOns
{
    public class LayerSniperChartTraderAddOn : AddOnBase
    {
        private static readonly Dictionary<Chart, ChartWindowAttachment> ActiveAttachments =
            new Dictionary<Chart, ChartWindowAttachment>();

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "JJ Layer Sniper Pro 2026: Botó manual BE +2t (+0.50p), FLAT i sincronització automàtica d'Order qty per a plantilles ATM LS_*.";
                Name = "LayerSniperChartTraderAddOn";
            }
            else if (State == State.Terminated)
            {
                DetachAllWindows();
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            Chart chartWindow = window as Chart;
            if (chartWindow == null)
                return;

            EnsureAttachedToWindow(chartWindow, 2);
        }

        protected override void OnWindowDestroyed(Window window)
        {
            Chart chartWindow = window as Chart;
            if (chartWindow == null)
                return;

            ChartWindowAttachment attachment;
            lock (ActiveAttachments)
            {
                if (ActiveAttachments.TryGetValue(chartWindow, out attachment))
                    ActiveAttachments.Remove(chartWindow);
            }

            if (attachment != null)
            {
                chartWindow.Dispatcher.InvokeAsync(attachment.Detach);
            }
        }

        public static void EnsureAttachedToWindow(Chart chartWindow, int breakevenOffsetTicks)
        {
            if (chartWindow == null)
                return;

            chartWindow.Dispatcher.InvokeAsync(() =>
            {
                ChartWindowAttachment existing;
                lock (ActiveAttachments)
                {
                    if (ActiveAttachments.TryGetValue(chartWindow, out existing))
                    {
                        existing.UpdateOffset(breakevenOffsetTicks);
                        existing.TryInjectAndWire();
                        return;
                    }

                    existing = new ChartWindowAttachment(chartWindow, breakevenOffsetTicks);
                    ActiveAttachments[chartWindow] = existing;
                }

                existing.Start();
            });
        }

        private static void DetachAllWindows()
        {
            List<ChartWindowAttachment> snapshot;
            lock (ActiveAttachments)
            {
                snapshot = ActiveAttachments.Values.ToList();
                ActiveAttachments.Clear();
            }

            foreach (ChartWindowAttachment item in snapshot)
            {
                try
                {
                    if (item.ChartWindow != null && item.ChartWindow.Dispatcher != null)
                        item.ChartWindow.Dispatcher.InvokeAsync(item.Detach);
                }
                catch
                {
                }
            }
        }

        internal sealed class ChartWindowAttachment
        {
            private const string ChartTraderBarName = "LayerSniperChartTraderBar";
            private const string TopToolbarMenuName = "LayerSniperTopMenu";
            private static readonly Regex QtyFromTemplateRegex =
                new Regex(@"_(\d+)MNQ", RegexOptions.IgnoreCase | RegexOptions.Compiled);

            public readonly Chart ChartWindow;
            private int breakevenOffsetTicks;

            private Grid chartTraderParentGrid;
            private RowDefinition addedRowDef;
            private int insertedStarIndex = -1;
            private Grid customBarGrid;
            private Button ctBeButton;
            private Button ctFlatButton;

            private Menu topToolbarMenu;
            private Button topBeButton;
            private Button topFlatButton;

            private AccountSelector accountSelector;
            private InstrumentSelector ctInstrumentSelector;
            private InstrumentSelector windowInstrumentSelector;
            private QuantityUpDown qudSelector;
            private NinjaTrader.Gui.NinjaScript.AtmStrategy.AtmStrategySelector atmSelector;

            private DispatcherTimer retryTimer;
            private DispatcherTimer feedbackResetTimer;
            private int retryCount;
            private DateTime nextLayoutProbeUtc = DateTime.MinValue;
            private string lastSyncedAtmTemplate = string.Empty;

            public ChartWindowAttachment(Chart chartWindow, int offsetTicks)
            {
                ChartWindow = chartWindow;
                breakevenOffsetTicks = offsetTicks > 0 ? offsetTicks : 2;
            }

            public void UpdateOffset(int offsetTicks)
            {
                if (offsetTicks >= 0)
                {
                    breakevenOffsetTicks = offsetTicks;
                    ResetButtonLabels();
                }
            }

            public void Start()
            {
                TryInjectAndWire();

                ChartWindow.LayoutUpdated += OnChartWindowLayoutUpdated;

                retryTimer = new DispatcherTimer(DispatcherPriority.Background, ChartWindow.Dispatcher)
                {
                    Interval = TimeSpan.FromMilliseconds(350)
                };
                retryTimer.Tick += OnRetryTimerTick;
                retryTimer.Start();
            }

            private void OnRetryTimerTick(object sender, EventArgs e)
            {
                retryCount++;
                TryInjectAndWire();

                if (retryCount >= 12 || (customBarGrid != null && topToolbarMenu != null && atmSelector != null))
                {
                    if (retryTimer != null)
                        retryTimer.Stop();
                }
            }

            private void OnChartWindowLayoutUpdated(object sender, EventArgs e)
            {
                DateTime now = DateTime.UtcNow;
                if (now < nextLayoutProbeUtc)
                    return;

                nextLayoutProbeUtc = now.AddMilliseconds(900);

                bool needsChartTraderHook = customBarGrid == null || !customBarGrid.IsLoaded || atmSelector == null || !atmSelector.IsLoaded;
                if (needsChartTraderHook)
                {
                    TryInjectAndWire();
                }
                else
                {
                    SyncQuantityFromAtm(null);
                }
            }

            public void TryInjectAndWire()
            {
                try
                {
                    if (ChartWindow == null)
                        return;

                    if (windowInstrumentSelector == null || !windowInstrumentSelector.IsLoaded)
                        windowInstrumentSelector = FindVisualChild<InstrumentSelector>(ChartWindow);

                    // 1) Injectar botons compactes a la barra superior del gràfic (sempre visibles)
                    InjectTopToolbarButtons();

                    // 2) Localitzar Chart Trader i connectar tant botons grans com Order qty Auto-Sync
                    ChartTrader chartTrader = ChartWindow.FindFirst("ChartWindowChartTraderControl") as ChartTrader;
                    if (chartTrader == null)
                        return;

                    accountSelector = FindVisualChild<AccountSelector>(chartTrader)
                        ?? (ChartWindow.FindFirst("ChartTraderControlAccountSelector") as AccountSelector);
                    ctInstrumentSelector = FindVisualChild<InstrumentSelector>(chartTrader);
                    qudSelector = FindVisualChild<QuantityUpDown>(chartTrader);

                    NinjaTrader.Gui.NinjaScript.AtmStrategy.AtmStrategySelector foundAtm =
                        FindVisualChild<NinjaTrader.Gui.NinjaScript.AtmStrategy.AtmStrategySelector>(chartTrader);

                    if (foundAtm != null && !ReferenceEquals(foundAtm, atmSelector))
                    {
                        if (atmSelector != null)
                            atmSelector.SelectionChanged -= OnAtmSelectionChanged;

                        atmSelector = foundAtm;
                        atmSelector.SelectionChanged += OnAtmSelectionChanged;
                        lastSyncedAtmTemplate = string.Empty;
                    }

                    InjectChartTraderButtons(chartTrader);
                    SyncQuantityFromAtm(null);
                }
                catch (Exception ex)
                {
                    LogOutput("[LayerSniper] Avís inicialitzant Chart Trader UI: " + ex.Message);
                }
            }

            private void InjectTopToolbarButtons()
            {
                if (ChartWindow.MainMenu == null)
                    return;

                if (topToolbarMenu != null && ChartWindow.MainMenu.Contains(topToolbarMenu))
                    return;

                // Netejar qualsevol menú antic amb el mateix nom per evitar duplicats en recompilar
                for (int i = ChartWindow.MainMenu.Count - 1; i >= 0; i--)
                {
                    FrameworkElement fe = ChartWindow.MainMenu[i] as FrameworkElement;
                    if (fe != null && fe.Name == TopToolbarMenuName)
                        ChartWindow.MainMenu.RemoveAt(i);
                }

                topBeButton = new Button
                {
                    Content = string.Format("🛡️ BE +{0}t", breakevenOffsetTicks),
                    ToolTip = "Moure l'Stop Loss actiu del compte seleccionat al Chart Trader a Breakeven +" + breakevenOffsetTicks + " ticks (+0.50p)",
                    Height = 22,
                    Margin = new Thickness(4, 0, 2, 0),
                    Padding = new Thickness(8, 1, 8, 1),
                    FontSize = 11,
                    FontWeight = FontWeights.Bold,
                    Background = new SolidColorBrush(Color.FromRgb(16, 124, 65)),
                    Foreground = Brushes.White,
                    BorderBrush = new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                    BorderThickness = new Thickness(1),
                    Focusable = false
                };
                topBeButton.Click += OnBePlusButtonClick;

                topFlatButton = new Button
                {
                    Content = "🛑 FLAT",
                    ToolTip = "Tancar posició i cancel·lar ordres del compte seleccionat al Chart Trader",
                    Height = 22,
                    Margin = new Thickness(2, 0, 4, 0),
                    Padding = new Thickness(7, 1, 7, 1),
                    FontSize = 11,
                    FontWeight = FontWeights.Bold,
                    Background = new SolidColorBrush(Color.FromRgb(168, 36, 36)),
                    Foreground = Brushes.White,
                    BorderBrush = new SolidColorBrush(Color.FromRgb(239, 68, 68)),
                    BorderThickness = new Thickness(1),
                    Focusable = false
                };
                topFlatButton.Click += OnPanicFlattenClick;

                topToolbarMenu = new Menu
                {
                    Name = TopToolbarMenuName,
                    VerticalAlignment = VerticalAlignment.Center,
                    Background = Brushes.Transparent
                };
                topToolbarMenu.Items.Add(topBeButton);
                topToolbarMenu.Items.Add(topFlatButton);

                ChartWindow.MainMenu.Add(topToolbarMenu);
            }

            private void InjectChartTraderButtons(ChartTrader chartTrader)
            {
                if (customBarGrid != null && customBarGrid.IsLoaded && chartTraderParentGrid != null && chartTraderParentGrid.Children.Contains(customBarGrid))
                    return;

                Grid targetGrid = ResolveChartTraderRowsGrid(chartTrader);
                if (targetGrid == null)
                    return;

                // Netejar qualsevol barra antiga abans d'inserir
                for (int i = targetGrid.Children.Count - 1; i >= 0; i--)
                {
                    FrameworkElement fe = targetGrid.Children[i] as FrameworkElement;
                    if (fe != null && fe.Name == ChartTraderBarName)
                        targetGrid.Children.RemoveAt(i);
                }

                ctBeButton = new Button
                {
                    Content = string.Format("🛡️ BE +{0}t (+0.50p)", breakevenOffsetTicks),
                    ToolTip = "Moure l'Stop Loss actiu del compte seleccionat al Chart Trader a Breakeven +" + breakevenOffsetTicks + " ticks (+0.50p)",
                    Height = 30,
                    Margin = new Thickness(0, 0, 3, 0),
                    Padding = new Thickness(6, 2, 6, 2),
                    FontSize = 11.5,
                    FontWeight = FontWeights.Bold,
                    Background = new SolidColorBrush(Color.FromRgb(16, 124, 65)),
                    Foreground = Brushes.White,
                    BorderBrush = new SolidColorBrush(Color.FromRgb(34, 197, 94)),
                    BorderThickness = new Thickness(1),
                    Focusable = false
                };
                ctBeButton.Click += OnBePlusButtonClick;

                ctFlatButton = new Button
                {
                    Content = "🛑 FLAT",
                    ToolTip = "Tancar posició i cancel·lar ordres del compte seleccionat al Chart Trader",
                    Height = 30,
                    Margin = new Thickness(3, 0, 0, 0),
                    Padding = new Thickness(6, 2, 6, 2),
                    FontSize = 11.5,
                    FontWeight = FontWeights.Bold,
                    Background = new SolidColorBrush(Color.FromRgb(168, 36, 36)),
                    Foreground = Brushes.White,
                    BorderBrush = new SolidColorBrush(Color.FromRgb(239, 68, 68)),
                    BorderThickness = new Thickness(1),
                    Focusable = false
                };
                ctFlatButton.Click += OnPanicFlattenClick;

                customBarGrid = new Grid
                {
                    Name = ChartTraderBarName,
                    Margin = new Thickness(4, 8, 4, 6)
                };
                customBarGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(2.1, GridUnitType.Star) });
                customBarGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0, GridUnitType.Star) });

                Grid.SetColumn(ctBeButton, 0);
                Grid.SetColumn(ctFlatButton, 1);
                customBarGrid.Children.Add(ctBeButton);
                customBarGrid.Children.Add(ctFlatButton);

                addedRowDef = new RowDefinition { Height = GridLength.Auto };
                insertedStarIndex = -1;

                // Inserir JUST ABANS de qualsevol fila '*' espaiadora del final perquè quedi enganxat sota l'ATM Strategy
                int firstTrailingStar = -1;
                for (int r = targetGrid.RowDefinitions.Count - 1; r >= 0; r--)
                {
                    if (targetGrid.RowDefinitions[r].Height.IsStar)
                        firstTrailingStar = r;
                    else
                        break;
                }

                int targetRowIndex;
                if (firstTrailingStar >= 0)
                {
                    insertedStarIndex = firstTrailingStar;
                    targetGrid.RowDefinitions.Insert(insertedStarIndex, addedRowDef);
                    foreach (UIElement child in targetGrid.Children)
                    {
                        if (child != null && Grid.GetRow(child) >= insertedStarIndex)
                            Grid.SetRow(child, Grid.GetRow(child) + 1);
                    }
                    targetRowIndex = insertedStarIndex;
                }
                else
                {
                    targetGrid.RowDefinitions.Add(addedRowDef);
                    targetRowIndex = targetGrid.RowDefinitions.Count - 1;
                }

                Grid.SetRow(customBarGrid, targetRowIndex);
                Grid.SetColumn(customBarGrid, 0);
                Grid.SetColumnSpan(customBarGrid, Math.Max(1, targetGrid.ColumnDefinitions.Count));
                targetGrid.Children.Add(customBarGrid);
                chartTraderParentGrid = targetGrid;

                LogOutput("[LayerSniper] ✅ Kit Manual [🛡️ BE +2t] + [🛑 FLAT] + Auto-Qty actiu al Chart Trader.");
            }

            private Grid ResolveChartTraderRowsGrid(ChartTrader chartTrader)
            {
                if (atmSelector != null)
                {
                    DependencyObject curr = VisualTreeHelper.GetParent(atmSelector);
                    while (curr != null && !ReferenceEquals(curr, chartTrader))
                    {
                        Grid g = curr as Grid;
                        if (g != null && g.RowDefinitions != null && g.RowDefinitions.Count >= 5)
                            return g;
                        curr = VisualTreeHelper.GetParent(curr);
                    }
                }

                Grid namedGrid = chartTrader.FindName("grdMain") as Grid;
                if (namedGrid != null && namedGrid.RowDefinitions != null && namedGrid.RowDefinitions.Count >= 5)
                    return namedGrid;

                return FindMultiRowGrid(chartTrader);
            }

            private void OnAtmSelectionChanged(object sender, SelectionChangedEventArgs e)
            {
                object addedItem = (e != null && e.AddedItems != null && e.AddedItems.Count > 0)
                    ? e.AddedItems[0]
                    : null;

                // Forçar re-avaluació en canviar d'ATM encara que es torni a triar la mateixa plantilla
                lastSyncedAtmTemplate = string.Empty;
                SyncQuantityFromAtm(addedItem);

                if (ChartWindow != null && ChartWindow.Dispatcher != null)
                {
                    ChartWindow.Dispatcher.BeginInvoke(
                        DispatcherPriority.Background,
                        new Action(() => SyncQuantityFromAtm(null)));
                }
            }

            private void SyncQuantityFromAtm(object candidateItem)
            {
                try
                {
                    if (atmSelector == null || qudSelector == null)
                        return;

                    string tplName = ExtractTemplateName(candidateItem);
                    if (string.IsNullOrWhiteSpace(tplName))
                        return;

                    if (string.Equals(tplName, lastSyncedAtmTemplate, StringComparison.OrdinalIgnoreCase))
                        return;

                    Match m = QtyFromTemplateRegex.Match(tplName);
                    if (!m.Success)
                        return;

                    int parsedQty;
                    if (int.TryParse(m.Groups[1].Value, out parsedQty) && parsedQty > 0)
                    {
                        lastSyncedAtmTemplate = tplName;
                        if (qudSelector.Value != parsedQty)
                        {
                            qudSelector.Value = parsedQty;
                            LogOutput(string.Format("[LayerSniper] 🎯 ATM '{0}' detectada -> Order qty ajustada automàticament a {1} contractes.", tplName, parsedQty));
                        }
                    }
                }
                catch
                {
                }
            }

            private string ExtractTemplateName(object candidateItem)
            {
                object[] candidates = new object[]
                {
                    candidateItem,
                    atmSelector != null ? atmSelector.SelectedAtmStrategy : null,
                    atmSelector != null ? atmSelector.SelectedItem : null
                };

                foreach (object obj in candidates)
                {
                    string s = ReadStringFromAtmObject(obj);
                    if (!string.IsNullOrWhiteSpace(s) && QtyFromTemplateRegex.IsMatch(s))
                        return s;
                }

                // Fallback visual directe: llegir el TextBlock renderitzat dins del desplegable ATM Strategy
                if (atmSelector != null)
                {
                    TextBlock tb = FindMatchingTextBlock(atmSelector);
                    if (tb != null && !string.IsNullOrWhiteSpace(tb.Text))
                        return tb.Text.Trim();
                }

                return string.Empty;
            }

            private static string ReadStringFromAtmObject(object obj)
            {
                if (obj == null)
                    return string.Empty;

                string asStr = obj as string;
                if (!string.IsNullOrWhiteSpace(asStr))
                    return asStr.Trim();

                Type t = obj.GetType();
                string[] propNames = new string[] { "Template", "DisplayName", "Name" };
                foreach (string pName in propNames)
                {
                    PropertyInfo prop = t.GetProperty(pName, BindingFlags.Public | BindingFlags.Instance);
                    if (prop != null && prop.PropertyType == typeof(string))
                    {
                        string val = prop.GetValue(obj, null) as string;
                        if (!string.IsNullOrWhiteSpace(val) && QtyFromTemplateRegex.IsMatch(val))
                            return val.Trim();
                    }
                }

                string raw = obj.ToString();
                return raw != null ? raw.Trim() : string.Empty;
            }

            private Account GetSelectedAccount()
            {
                if ((accountSelector == null || !accountSelector.IsLoaded) && ChartWindow != null)
                    accountSelector = ChartWindow.FindFirst("ChartTraderControlAccountSelector") as AccountSelector;

                return accountSelector != null ? accountSelector.SelectedAccount : null;
            }

            private Instrument GetActiveInstrument(Account fallbackAcct)
            {
                if (ctInstrumentSelector != null && ctInstrumentSelector.Instrument != null)
                    return ctInstrumentSelector.Instrument;

                if (windowInstrumentSelector != null && windowInstrumentSelector.Instrument != null)
                    return windowInstrumentSelector.Instrument;

                if (ChartWindow != null)
                {
                    InstrumentSelector anySel = FindVisualChild<InstrumentSelector>(ChartWindow);
                    if (anySel != null && anySel.Instrument != null)
                        return anySel.Instrument;
                }

                if (fallbackAcct != null)
                {
                    Position openPos = fallbackAcct.Positions.FirstOrDefault(p => p.MarketPosition != MarketPosition.Flat);
                    if (openPos != null)
                        return openPos.Instrument;
                }

                return null;
            }

            private void OnBePlusButtonClick(object sender, RoutedEventArgs e)
            {
                try
                {
                    Account acct = GetSelectedAccount();
                    if (acct == null)
                    {
                        FlashFeedback("⚠️ Tria Compte!", Color.FromRgb(180, 83, 9));
                        return;
                    }

                    Instrument inst = GetActiveInstrument(acct);
                    if (inst == null)
                    {
                        FlashFeedback("⚠️ Sense Instrument", Color.FromRgb(180, 83, 9));
                        return;
                    }

                    Position pos = acct.Positions.FirstOrDefault(p =>
                        p.Instrument != null &&
                        p.Instrument.FullName == inst.FullName &&
                        p.MarketPosition != MarketPosition.Flat);

                    if (pos == null)
                    {
                        FlashFeedback(string.Format("ℹ️ Flat ({0})", acct.Name), Color.FromRgb(30, 64, 175));
                        LogOutput(string.Format("[LayerSniper] El compte '{0}' no té cap posició oberta a {1}.", acct.Name, inst.FullName));
                        return;
                    }

                    double tick = inst.MasterInstrument.TickSize;
                    double rawTargetStop = pos.MarketPosition == MarketPosition.Long
                        ? pos.AveragePrice + (breakevenOffsetTicks * tick)
                        : pos.AveragePrice - (breakevenOffsetTicks * tick);
                    double targetStop = inst.MasterInstrument.RoundToTickSize(rawTargetStop);

                    List<Order> workingStops = acct.Orders
                        .Where(o =>
                            o.Instrument != null &&
                            o.Instrument.FullName == inst.FullName &&
                            (o.OrderState == OrderState.Working || o.OrderState == OrderState.Accepted) &&
                            (o.OrderType == OrderType.StopMarket || o.OrderType == OrderType.StopLimit))
                        .ToList();

                    if (workingStops.Count == 0)
                    {
                        FlashFeedback("⚠️ Sense Stop actiu!", Color.FromRgb(180, 83, 9));
                        LogOutput(string.Format("[LayerSniper] ATENCIÓ: Cap ordre Stop activa trobada a '{0}' per a {1}!", acct.Name, inst.FullName));
                        return;
                    }

                    foreach (Order stopOrd in workingStops)
                    {
                        stopOrd.StopPriceChanged = targetStop;
                        if (stopOrd.OrderType == OrderType.StopLimit)
                            stopOrd.LimitPriceChanged = targetStop;
                    }

                    acct.Change(workingStops);
                    FlashFeedback(string.Format("✅ BE +{0}t @ {1:F2}", breakevenOffsetTicks, targetStop), Color.FromRgb(21, 128, 61));
                    LogOutput(string.Format(
                        "[LayerSniper] ✅ Stop Loss de '{0}' ({1}) mogut manualment a BE +{2}t ({3:F2}).",
                        acct.Name, inst.FullName, breakevenOffsetTicks, targetStop));
                }
                catch (Exception ex)
                {
                    FlashFeedback("❌ Error BE", Color.FromRgb(185, 28, 28));
                    LogOutput("[LayerSniper] ❌ Error modificant Stop a BE: " + ex.Message);
                }
            }

            private void OnPanicFlattenClick(object sender, RoutedEventArgs e)
            {
                try
                {
                    Account acct = GetSelectedAccount();
                    if (acct == null)
                        return;

                    Instrument inst = GetActiveInstrument(acct);
                    if (inst == null)
                        return;

                    acct.Flatten(new[] { inst });
                    FlashFeedback("🛑 FLATTEN ENVIAT", Color.FromRgb(185, 28, 28));
                    LogOutput(string.Format("[LayerSniper] 🛑 Flatten manual executat a '{0}' per a {1}.", acct.Name, inst.FullName));
                }
                catch (Exception ex)
                {
                    LogOutput("[LayerSniper] ❌ Error en Flatten manual: " + ex.Message);
                }
            }

            private void FlashFeedback(string text, Color bgColor)
            {
                SolidColorBrush brush = new SolidColorBrush(bgColor);
                if (ctBeButton != null)
                {
                    ctBeButton.Content = text;
                    ctBeButton.Background = brush;
                }
                if (topBeButton != null)
                {
                    topBeButton.Content = text;
                    topBeButton.Background = brush;
                }

                if (feedbackResetTimer == null && ChartWindow != null)
                {
                    feedbackResetTimer = new DispatcherTimer(DispatcherPriority.Background, ChartWindow.Dispatcher)
                    {
                        Interval = TimeSpan.FromSeconds(2.2)
                    };
                    feedbackResetTimer.Tick += (s, args) =>
                    {
                        feedbackResetTimer.Stop();
                        ResetButtonLabels();
                    };
                }

                if (feedbackResetTimer != null)
                {
                    feedbackResetTimer.Stop();
                    feedbackResetTimer.Start();
                }
            }

            private void ResetButtonLabels()
            {
                SolidColorBrush defaultGreen = new SolidColorBrush(Color.FromRgb(16, 124, 65));
                if (ctBeButton != null)
                {
                    ctBeButton.Content = string.Format("🛡️ BE +{0}t (+0.50p)", breakevenOffsetTicks);
                    ctBeButton.Background = defaultGreen;
                }
                if (topBeButton != null)
                {
                    topBeButton.Content = string.Format("🛡️ BE +{0}t", breakevenOffsetTicks);
                    topBeButton.Background = defaultGreen;
                }
            }

            public void Detach()
            {
                try
                {
                    if (retryTimer != null)
                    {
                        retryTimer.Stop();
                        retryTimer.Tick -= OnRetryTimerTick;
                        retryTimer = null;
                    }
                    if (feedbackResetTimer != null)
                    {
                        feedbackResetTimer.Stop();
                        feedbackResetTimer = null;
                    }
                    if (ChartWindow != null)
                        ChartWindow.LayoutUpdated -= OnChartWindowLayoutUpdated;

                    if (atmSelector != null)
                        atmSelector.SelectionChanged -= OnAtmSelectionChanged;

                    if (ctBeButton != null)
                        ctBeButton.Click -= OnBePlusButtonClick;
                    if (ctFlatButton != null)
                        ctFlatButton.Click -= OnPanicFlattenClick;
                    if (topBeButton != null)
                        topBeButton.Click -= OnBePlusButtonClick;
                    if (topFlatButton != null)
                        topFlatButton.Click -= OnPanicFlattenClick;

                    if (chartTraderParentGrid != null && customBarGrid != null)
                    {
                        if (chartTraderParentGrid.Children.Contains(customBarGrid))
                            chartTraderParentGrid.Children.Remove(customBarGrid);

                        if (addedRowDef != null && chartTraderParentGrid.RowDefinitions.Contains(addedRowDef))
                        {
                            int removedIdx = chartTraderParentGrid.RowDefinitions.IndexOf(addedRowDef);
                            chartTraderParentGrid.RowDefinitions.Remove(addedRowDef);
                            if (insertedStarIndex >= 0 && removedIdx >= 0)
                            {
                                foreach (UIElement child in chartTraderParentGrid.Children)
                                {
                                    if (child != null && Grid.GetRow(child) > removedIdx)
                                        Grid.SetRow(child, Grid.GetRow(child) - 1);
                                }
                            }
                        }
                    }

                    if (ChartWindow != null && ChartWindow.MainMenu != null && topToolbarMenu != null)
                    {
                        if (ChartWindow.MainMenu.Contains(topToolbarMenu))
                            ChartWindow.MainMenu.Remove(topToolbarMenu);
                    }
                }
                catch
                {
                }
            }

            private static T FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
            {
                if (parent == null)
                    return null;

                int count = VisualTreeHelper.GetChildrenCount(parent);
                for (int i = 0; i < count; i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(parent, i);
                    T typed = child as T;
                    if (typed != null)
                        return typed;

                    T nested = FindVisualChild<T>(child);
                    if (nested != null)
                        return nested;
                }
                return null;
            }

            private static Grid FindMultiRowGrid(DependencyObject parent)
            {
                if (parent == null)
                    return null;

                int count = VisualTreeHelper.GetChildrenCount(parent);
                for (int i = 0; i < count; i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(parent, i);
                    Grid g = child as Grid;
                    if (g != null && g.RowDefinitions != null && g.RowDefinitions.Count >= 5)
                        return g;

                    Grid nested = FindMultiRowGrid(child);
                    if (nested != null)
                        return nested;
                }
                return null;
            }

            private static TextBlock FindMatchingTextBlock(DependencyObject parent)
            {
                if (parent == null)
                    return null;

                int count = VisualTreeHelper.GetChildrenCount(parent);
                for (int i = 0; i < count; i++)
                {
                    DependencyObject child = VisualTreeHelper.GetChild(parent, i);
                    TextBlock tb = child as TextBlock;
                    if (tb != null && !string.IsNullOrWhiteSpace(tb.Text) && QtyFromTemplateRegex.IsMatch(tb.Text))
                        return tb;

                    TextBlock nested = FindMatchingTextBlock(child);
                    if (nested != null)
                        return nested;
                }
                return null;
            }

            private static void LogOutput(string message)
            {
                try
                {
                    Output.Process(message, PrintTo.OutputTab1);
                }
                catch
                {
                }
            }
        }
    }
}
